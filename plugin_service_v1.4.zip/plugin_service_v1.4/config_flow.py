"""Config flow for Plugin Service.

The user enters project_id, mac and api_key from the UI.
Server and WebSocket URLs are hardcoded in const.py.
"""

import voluptuous as vol
from homeassistant import config_entries

from .const import (
    CONF_API_KEY,
    CONF_MAC,
    CONF_PROJECT_ID,
    DOMAIN,
    INTEGRATION_NAME,
)


class PluginServiceConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Config flow for Plugin Service."""

    VERSION = 1

    async def async_step_user(self, user_input=None):
        errors = {}

        if user_input is not None:
            await self.async_set_unique_id(user_input[CONF_MAC])
            self._abort_if_unique_id_configured()

            return self.async_create_entry(
                title=f"{INTEGRATION_NAME} [{user_input[CONF_MAC]}]",
                data={
                    CONF_PROJECT_ID: user_input[CONF_PROJECT_ID],
                    CONF_MAC: user_input[CONF_MAC],
                    CONF_API_KEY: user_input[CONF_API_KEY],
                },
            )

        schema = vol.Schema(
            {
                vol.Required(CONF_PROJECT_ID): str,
                vol.Required(CONF_MAC): str,
                vol.Required(CONF_API_KEY): str,
            }
        )

        return self.async_show_form(
            step_id="user",
            data_schema=schema,
            errors=errors,
        )

    @staticmethod
    def async_get_options_flow(config_entry):
        """Allows editing project_id / api_key without removing the integration."""
        return PluginServiceOptionsFlow()


class PluginServiceOptionsFlow(config_entries.OptionsFlow):
    """Options flow: allows changing project_id or api_key after installation."""

    async def async_step_init(self, user_input=None):
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        schema = vol.Schema(
            {
                vol.Required(
                    CONF_PROJECT_ID,
                    default=self.config_entry.data.get(CONF_PROJECT_ID, ""),
                ): str,
                vol.Required(
                    CONF_API_KEY,
                    default=self.config_entry.data.get(CONF_API_KEY, ""),
                ): str,
            }
        )

        return self.async_show_form(step_id="init", data_schema=schema)
