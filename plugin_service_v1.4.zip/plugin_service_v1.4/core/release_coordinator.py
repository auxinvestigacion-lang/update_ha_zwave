"""Polls GitHub Releases and installs a selected Plugin Service version."""

import logging
from dataclasses import dataclass, replace
from datetime import timedelta
from pathlib import Path

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from ..api.github_releases import (
    GithubRelease,
    GithubReleasesError,
    download_release_zipball,
    fetch_published_releases,
)
from ..const import (
    CUSTOM_COMPONENTS_DIR,
    DOMAIN,
    GITHUB_RELEASES_POLL_INTERVAL_SECONDS,
    INTEGRATION_NAME,
    LOG_PREFIX,
    PROGRESS_DONE,
    PROGRESS_EXTRACT,
)
from .installed_version import normalize_version_tag, read_installed_version_tag
from .plugin_installer import PluginInstallError, install_release_zip

_LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class ReleaseCatalog:
    """Installed version plus the newest published GitHub releases."""

    releases: tuple[GithubRelease, ...]
    installed_version: str

    @property
    def latest(self) -> GithubRelease | None:
        """Returns the newest published release when GitHub returned any."""
        return self.releases[0] if self.releases else None

    @property
    def tags(self) -> list[str]:
        """Returns selectable release tags, newest first."""
        return [release.tag_name for release in self.releases]


class PluginReleaseCoordinator(DataUpdateCoordinator[ReleaseCatalog]):
    """Keeps GitHub release metadata and the user's selected tag in memory."""

    def __init__(self, hass: HomeAssistant) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name=f"{LOG_PREFIX} releases",
            update_interval=timedelta(seconds=GITHUB_RELEASES_POLL_INTERVAL_SECONDS),
        )
        self.selected_tag: str | None = None
        self.is_installing = False
        self.install_percentage: int | None = None

    async def _async_update_data(self) -> ReleaseCatalog:
        """Fetches published releases and keeps the selected tag in the list."""
        try:
            releases = await fetch_published_releases(self.hass)
        except GithubReleasesError as err:
            raise UpdateFailed(str(err)) from err
        catalog = ReleaseCatalog(
            releases=tuple(
                replace(release, tag_name=normalize_version_tag(release.tag_name))
                for release in releases
            ),
            installed_version=read_installed_version_tag(),
        )
        self._sync_selected_tag(catalog)
        return catalog

    def _sync_selected_tag(self, catalog: ReleaseCatalog) -> None:
        """Defaults the selector to the installed tag when it is in the list."""
        if self.selected_tag in catalog.tags:
            return
        if catalog.installed_version in catalog.tags:
            self.selected_tag = catalog.installed_version
            return
        self.selected_tag = catalog.tags[0] if catalog.tags else catalog.installed_version

    def find_release(self, tag_name: str) -> GithubRelease | None:
        """Returns a cached release by normalized tag."""
        if not self.data:
            return None
        expected = normalize_version_tag(tag_name)
        for release in self.data.releases:
            if release.tag_name == expected:
                return release
        return None

    def set_progress(self, percentage: int) -> None:
        """Publishes install progress to listening update entities."""
        self.install_percentage = percentage
        self.async_update_listeners()

    async def async_install_tag(self, tag_name: str | None) -> None:
        """Downloads the selected or latest tag and replaces local integration files."""
        if self.is_installing:
            raise PluginInstallError("async_install_tag: install already running")
        release = self._resolve_install_release(tag_name)
        if release.tag_name == (self.data.installed_version if self.data else None):
            _LOGGER.info("%s already installed [%s]", LOG_PREFIX, release.tag_name)
            return
        await self._async_run_install(release)

    def _resolve_install_release(self, tag_name: str | None) -> GithubRelease:
        """Resolves latest vs a specific tag from the cached catalog."""
        if not self.data or not self.data.releases:
            raise PluginInstallError("async_install_tag: no GitHub releases cached")
        if tag_name:
            release = self.find_release(tag_name)
        else:
            release = self.data.latest
        if not release:
            raise PluginInstallError(f"async_install_tag: unknown tag={tag_name}")
        return release

    async def _async_run_install(self, release: GithubRelease) -> None:
        """Downloads, extracts and replaces files for one GitHub release tag."""
        self.is_installing = True
        self.set_progress(0)
        try:
            zip_bytes = await download_release_zipball(
                self.hass, release.zipball_url, self.set_progress
            )
            self.set_progress(PROGRESS_EXTRACT)
            dest_dir = Path(self.hass.config.path(CUSTOM_COMPONENTS_DIR, DOMAIN))
            installed_tag = await self.hass.async_add_executor_job(
                install_release_zip, zip_bytes, dest_dir, release.tag_name
            )
            self._mark_installed(installed_tag)
            self.set_progress(PROGRESS_DONE)
            await self._async_notify_restart_required(installed_tag)
            _LOGGER.info("%s installed GitHub release [%s]", LOG_PREFIX, installed_tag)
        except (GithubReleasesError, PluginInstallError) as err:
            _LOGGER.error(
                "%s install failed tag=%s err=%s", LOG_PREFIX, release.tag_name, err
            )
            raise
        finally:
            self.is_installing = False
            self.install_percentage = None
            self.async_update_listeners()

    def _mark_installed(self, installed_tag: str) -> None:
        """Updates cached catalog so the UI shows the version written to disk."""
        if not self.data:
            return
        self.selected_tag = installed_tag
        self.async_set_updated_data(
            ReleaseCatalog(releases=self.data.releases, installed_version=installed_tag)
        )

    async def _async_notify_restart_required(self, version: str) -> None:
        """Tells the user to restart HA; new Python modules are not hot-reloaded."""
        language = (self.hass.config.language or "en").lower()
        message = (
            f"Se instaló Plugin Service {version}. Reinicia Home Assistant para aplicarla."
            if language.startswith("es")
            else (
                f"Plugin Service {version} was installed. "
                "Restart Home Assistant to apply it."
            )
        )
        await self.hass.services.async_call(
            "persistent_notification",
            "create",
            {
                "title": INTEGRATION_NAME,
                "message": message,
                "notification_id": f"{DOMAIN}_restart_required",
            },
        )
