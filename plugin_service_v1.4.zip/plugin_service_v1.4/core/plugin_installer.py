"""Installs a GitHub release zipball over the local custom component files."""

import json
import shutil
import tempfile
import zipfile
from io import BytesIO
from pathlib import Path

from ..const import DOMAIN, MANIFEST_FILE_NAME
from .installed_version import normalize_version_tag


_SKIP_COPY_DIR_NAMES = frozenset({".git", ".github", "__pycache__"})


class PluginInstallError(Exception):
    """Raised when a GitHub release cannot replace the local integration files."""


def install_release_zip(zip_bytes: bytes, dest_dir: Path, expected_tag: str) -> str:
    """Replaces dest_dir with the zipball contents after validating the manifest."""
    staging_dir = Path(tempfile.mkdtemp(prefix=f"{DOMAIN}_install_"))
    try:
        _extract_zipball(zip_bytes, staging_dir)
        source_dir = _find_integration_root(staging_dir)
        installed_tag = _validate_manifest(source_dir, expected_tag)
        _copy_integration_files(source_dir, dest_dir)
        _clear_bytecode_cache(dest_dir)
        return installed_tag
    finally:
        shutil.rmtree(staging_dir, ignore_errors=True)


def _extract_zipball(zip_bytes: bytes, staging_dir: Path) -> None:
    """Extracts a GitHub zipball into staging_dir, rejecting path traversal."""
    with zipfile.ZipFile(BytesIO(zip_bytes)) as archive:
        _assert_zip_is_safe(archive, staging_dir)
        archive.extractall(staging_dir)


def _assert_zip_is_safe(archive: zipfile.ZipFile, staging_dir: Path) -> None:
    """Rejects zip members that would extract outside staging_dir."""
    resolved_staging = staging_dir.resolve()
    for member in archive.infolist():
        target = (staging_dir / member.filename).resolve()
        try:
            target.relative_to(resolved_staging)
        except ValueError as err:
            raise PluginInstallError(
                f"install_release_zip unsafe path={member.filename}"
            ) from err


def _find_integration_root(staging_dir: Path) -> Path:
    """Returns the inner GitHub zipball directory that contains manifest.json."""
    manifest_matches = list(staging_dir.rglob(MANIFEST_FILE_NAME))
    if len(manifest_matches) != 1:
        raise PluginInstallError(
            f"install_release_zip manifest_count={len(manifest_matches)}"
        )
    return manifest_matches[0].parent


def _validate_manifest(source_dir: Path, expected_tag: str) -> str:
    """Ensures the zip belongs to this integration and matches the selected tag."""
    manifest_path = source_dir / MANIFEST_FILE_NAME
    with manifest_path.open(encoding="utf-8") as manifest_file:
        manifest = json.load(manifest_file)
    if manifest.get("domain") != DOMAIN:
        raise PluginInstallError(
            f"install_release_zip domain={manifest.get('domain')}"
        )
    found_tag = normalize_version_tag(str(manifest.get("version", "")))
    expected = normalize_version_tag(expected_tag)
    if found_tag != expected:
        raise PluginInstallError(
            f"install_release_zip expected={expected} manifest={found_tag}"
        )
    return found_tag


def _copy_integration_files(source_dir: Path, dest_dir: Path) -> None:
    """Overwrites dest_dir with the extracted integration files."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    for source_file in source_dir.rglob("*"):
        if not source_file.is_file():
            continue
        if any(part in _SKIP_COPY_DIR_NAMES for part in source_file.parts):
            continue
        relative_path = source_file.relative_to(source_dir)
        target_file = dest_dir / relative_path
        target_file.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_file, target_file)


def _clear_bytecode_cache(dest_dir: Path) -> None:
    """Removes stale __pycache__ so HA loads the newly copied modules after restart."""
    for cache_dir in dest_dir.rglob("__pycache__"):
        if cache_dir.is_dir():
            shutil.rmtree(cache_dir, ignore_errors=True)
