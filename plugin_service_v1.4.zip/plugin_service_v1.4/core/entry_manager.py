"""Runtime config and WebSocket lifecycle management for config entries."""

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from ..api.onboarding import run_onboarding
from ..api.websocket_client import WSClient
from ..const import (
    CONF_API_KEY,
    CONF_MAC,
    CONF_PROJECT_ID,
    DATA_CLIENT,
    DATA_CONFIG,
    DOMAIN,
    LOG_PREFIX,
    RESP_PROJECT_ID,
)

_LOGGER = logging.getLogger(__name__)


def build_entry_config(entry: ConfigEntry) -> dict:
    """Builds the runtime config from the config entry and its options."""
    entry_config = {
        CONF_PROJECT_ID: entry.data[CONF_PROJECT_ID],
        CONF_MAC: entry.data[CONF_MAC],
        CONF_API_KEY: entry.data[CONF_API_KEY],
    }

    if entry.options:
        entry_config[CONF_PROJECT_ID] = entry.options.get(
            CONF_PROJECT_ID, entry_config[CONF_PROJECT_ID]
        )
        entry_config[CONF_API_KEY] = entry.options.get(
            CONF_API_KEY, entry_config[CONF_API_KEY]
        )

    return entry_config


def apply_server_response(entry_config: dict, server_response: dict) -> None:
    """Updates local config with values confirmed by the server."""
    confirmed_project_id = server_response.get(RESP_PROJECT_ID)
    if confirmed_project_id:
        entry_config[CONF_PROJECT_ID] = confirmed_project_id


async def register_and_start_client(
    hass: HomeAssistant,
    entry_id: str,
    entry_config: dict,
) -> bool:
    """Waits for Z-Wave readiness, registers with the server, then starts WS."""
    if hass.is_stopping or entry_id not in hass.data.get(DOMAIN, {}):
        return False

    server_response = await run_onboarding(hass, entry_config)
    if not server_response:
        _LOGGER.error(
            "%s registration failed — WebSocket will not start until "
            "registration succeeds (use the Synchronize devices button)",
            LOG_PREFIX,
        )
        return False

    if hass.is_stopping or entry_id not in hass.data.get(DOMAIN, {}):
        return False

    apply_server_response(entry_config, server_response)
    await start_ws_client(hass, entry_id, entry_config)
    return True


async def start_ws_client(
    hass: HomeAssistant,
    entry_id: str,
    entry_config: dict,
) -> None:
    """Creates or refreshes the WebSocket client for a config entry."""
    entry_data = hass.data[DOMAIN][entry_id]
    existing_client: WSClient | None = entry_data.get(DATA_CLIENT)

    if existing_client:
        if existing_client.is_running:
            await existing_client.refresh_tracked_entities()
            return
        await existing_client.stop()

    client = WSClient(hass, entry_config)
    await client.start()
    entry_data[DATA_CLIENT] = client


async def stop_ws_client(hass: HomeAssistant, entry_id: str) -> None:
    """Stops the WebSocket client for a config entry."""
    entry_data = hass.data[DOMAIN].pop(entry_id, {})
    client: WSClient | None = entry_data.get(DATA_CLIENT)
    if client:
        await client.stop()
