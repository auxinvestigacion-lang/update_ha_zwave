"""Reads and normalizes the locally installed Plugin Service version."""

import json
from pathlib import Path

from ..const import MANIFEST_FILE_NAME


def get_integration_root() -> Path:
    """Returns the integration directory on disk."""
    return Path(__file__).resolve().parent.parent


def normalize_version_tag(version: str) -> str:
    """Returns a comparable tag like v1.3.1 from manifest or GitHub values."""
    stripped = version.strip()
    if stripped.lower().startswith("v"):
        stripped = stripped[1:]
    return f"v{stripped}"


def read_installed_version_tag() -> str:
    """Reads manifest.json and returns the installed version as a v-prefixed tag."""
    manifest_path = get_integration_root() / MANIFEST_FILE_NAME
    with manifest_path.open(encoding="utf-8") as manifest_file:
        manifest = json.load(manifest_file)
    return normalize_version_tag(str(manifest["version"]))
