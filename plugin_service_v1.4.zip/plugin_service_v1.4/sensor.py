"""Platform sensor for Plugin Service.

Home Assistant requires a sensor.py file at the integration root when "sensor"
is declared in PLATFORMS.
"""

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CONF_MAC, DATA_CONFIG, DATA_RELEASE_COORDINATOR, DOMAIN
from .entity.installed_version_sensor import InstalledVersionSensor


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Registers the installed-version diagnostic sensor for this config entry."""
    entry_data = hass.data[DOMAIN][entry.entry_id]
    mac = entry_data[DATA_CONFIG][CONF_MAC]
    coordinator = entry_data[DATA_RELEASE_COORDINATOR]
    async_add_entities([InstalledVersionSensor(coordinator, mac)])
