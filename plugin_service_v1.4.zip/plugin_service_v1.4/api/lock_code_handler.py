"""Handles lock user-code management requests from the external server."""

import logging
import re

from homeassistant.core import HomeAssistant

from ..const import (
    LOCK_CODE_CREDENTIAL_RULES,
    LOCK_CODE_MAX_SLOT,
    LOCK_CODE_MIN_PIN_LENGTH,
    LOCK_CODE_MIN_SLOT,
    LOCK_CODE_USER_TYPES,
    LOG_PREFIX,
    ZWAVE_JS_DOMAIN,
)
from ..registry.lock_code_capabilities import (
    LOCK_CODE_API_CREDENTIAL,
    LOCK_CODE_API_USERCODE,
    fetch_lock_code_slots,
)
from ..registry.lock_user_mapper import fetch_lock_user_slots, resolve_code_slot_for_user
from .lock_code_access_control import (
    LockAccessControlError,
    add_user_with_pin,
    clear_user_code_slot,
    disable_user_code_schedule,
    enable_user_code_schedule,
)
from .messages import build_call_service_result_message, build_lock_code_result_message
from .service_executor import ServiceExecutionError, execute_ha_service

_LOGGER = logging.getLogger(__name__)

ZWAVE_JS_SERVICE_SET_LOCK_USERCODE = "set_lock_usercode"
ZWAVE_JS_SERVICE_CLEAR_LOCK_USERCODE = "clear_lock_usercode"
ZWAVE_JS_SERVICE_GET_LOCK_USERCODE = "get_lock_usercode"
ZWAVE_JS_SERVICE_GET_CREDENTIAL_CAPABILITIES = "get_credential_capabilities"
ZWAVE_JS_SERVICE_SET_USER = "set_user"
ZWAVE_JS_SERVICE_DELETE_USER = "delete_user"
ZWAVE_JS_SERVICE_DELETE_CREDENTIAL = "delete_credential"
ZWAVE_JS_SERVICE_DELETE_ALL_CREDENTIALS = "delete_all_credentials"
ZWAVE_JS_SERVICE_SET_CREDENTIAL = "set_credential"
ZWAVE_JS_SERVICE_GET_USERS = "get_users"

LOCK_CODE_ACTION_SET = "set"
LOCK_CODE_ACTION_CLEAR = "clear"
LOCK_CODE_ACTION_UPDATE = "update"
LOCK_CODE_ACTION_LIST = "list"
LOCK_CODE_ACTION_GET_CAPABILITIES = "get_capabilities"

_PIN_DIGITS_PATTERN = re.compile(r"^\d+$")


class LockCodeHandler:
    """Executes semantic lock-code commands against zwave_js lock entities."""

    def __init__(
        self,
        hass: HomeAssistant,
        project_id: str,
        serial: str,
        send_message,
        get_lock_device_map,
    ) -> None:
        self._hass = hass
        self._project_id = project_id
        self._serial = serial
        self._send_message = send_message
        self._get_lock_device_map = get_lock_device_map

    async def handle_set(self, message: dict) -> None:
        """Creates or updates a lock user code in a slot."""
        await self._handle_action(LOCK_CODE_ACTION_SET, message, self._set_lock_code)

    async def handle_clear(self, message: dict) -> None:
        """Clears a lock user code from a slot."""
        await self._handle_action(LOCK_CODE_ACTION_CLEAR, message, self._clear_lock_code)

    async def handle_update(self, message: dict) -> None:
        """Updates access-control restrictions for an existing lock user."""
        await self._handle_action(LOCK_CODE_ACTION_UPDATE, message, self._update_lock_code)

    async def handle_list(self, message: dict) -> None:
        """Lists lock user-code slots and optional credential metadata."""
        await self._handle_action(LOCK_CODE_ACTION_LIST, message, self._list_lock_codes)

    async def handle_get_capabilities(self, message: dict) -> None:
        """Refreshes lock user-code capabilities from Home Assistant."""
        await self._handle_action(
            LOCK_CODE_ACTION_GET_CAPABILITIES,
            message,
            self._get_lock_capabilities,
        )

    async def _handle_action(self, action: str, message: dict, handler) -> None:
        """Runs a lock-code handler and publishes a lock_code_result message."""
        request_data = message.get("data", message)
        request_id = request_data.get("request_id")

        try:
            action_result = await handler(request_data)
            await self._send_result(
                request_id=request_id,
                action=action,
                success=True,
                action_result=action_result,
            )
        except LockCodeRequestError as err:
            await self._send_result(
                request_id=request_id,
                action=action,
                success=False,
                error=str(err),
                action_result=err.action_result,
            )
        except (ServiceExecutionError, LockAccessControlError) as err:
            await self._send_result(
                request_id=request_id,
                action=action,
                success=False,
                error=str(err),
            )
        except Exception as err:
            _LOGGER.exception("%s lock_code %s failed: %s", LOG_PREFIX, action, err)
            await self._send_result(
                request_id=request_id,
                action=action,
                success=False,
                error=f"lock_code {action} failed: {err}",
            )

    async def _set_lock_code(self, request_data: dict) -> dict:
        """Validates and programs a user code into a lock slot."""
        device_id, lock_profile, entity_id = self._resolve_lock_target(request_data)
        code_slot = self._parse_code_slot(request_data.get("code_slot"))
        usercode = self._parse_usercode(
            request_data.get("usercode"),
            lock_profile.get("max_pin_length"),
        )
        restrictions = self._parse_restrictions(request_data, lock_profile)

        if lock_profile.get("api") == LOCK_CODE_API_CREDENTIAL:
            await self._set_lock_code_credential(
                entity_id=entity_id,
                code_slot=code_slot,
                usercode=usercode,
                request_data=request_data,
                restrictions=restrictions,
            )
        else:
            if restrictions:
                raise LockCodeRequestError(
                    "user restrictions require credential API locks",
                    action_result={
                        "device_id": device_id,
                        "entity_id": entity_id,
                        "code_slot": code_slot,
                    },
                )
            await self._set_lock_code_usercode(
                entity_id=entity_id,
                code_slot=code_slot,
                usercode=usercode,
            )

        resolved_user_id = await _resolve_user_id_for_slot(
            self._hass,
            entity_id,
            code_slot,
            lock_profile.get("api", LOCK_CODE_API_USERCODE),
        )

        if resolved_user_id is not None:
            from ..registry.lock_user_slot_registry import get_lock_user_slot_registry

            get_lock_user_slot_registry(self._hass).store(
                device_id,
                resolved_user_id,
                code_slot,
            )

        _LOGGER.info(
            "%s lock_code set [device: %s | slot: %d | user_id: %s | restrictions: %s]",
            LOG_PREFIX,
            device_id,
            code_slot,
            resolved_user_id,
            restrictions,
        )
        return {
            "device_id": device_id,
            "entity_id": entity_id,
            "code_slot": code_slot,
            "user_id": resolved_user_id,
            **restrictions,
        }

    async def _set_lock_code_usercode(
        self,
        *,
        entity_id: str,
        code_slot: int,
        usercode: str,
    ) -> None:
        """Programs a legacy usercode PIN and enables Schedule Entry Lock for that slot."""
        await execute_ha_service(
            self._hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_SET_LOCK_USERCODE,
            service_data={
                "entity_id": entity_id,
                "code_slot": code_slot,
                "usercode": usercode,
            },
        )
        try:
            await enable_user_code_schedule(self._hass, entity_id, code_slot)
        except LockAccessControlError as err:
            raise LockCodeRequestError(
                f"PIN programmed but could not enable schedule for slot {code_slot}: {err}",
                action_result={
                    "entity_id": entity_id,
                    "code_slot": code_slot,
                },
            ) from err

    async def _set_lock_code_credential(
        self,
        entity_id: str,
        code_slot: int,
        usercode: str,
        request_data: dict,
        restrictions: dict | None = None,
    ) -> None:
        """Programs a credential lock using the API required by the device."""
        user_name = request_data.get("user_name")
        restrictions = dict(restrictions or {})
        existing_users = await fetch_lock_user_slots(self._hass, entity_id)
        has_existing_user = any(
            user_entry.get("code_slot") == code_slot for user_entry in existing_users
        )

        if has_existing_user:
            await self._set_credential_pin(
                entity_id=entity_id,
                user_id=code_slot,
                usercode=usercode,
                credential_slot=code_slot,
            )
            enable_restrictions = self._ensure_credential_user_enabled(restrictions)
            await self._apply_user_restrictions_if_supported(
                entity_id=entity_id,
                user_id=code_slot,
                user_name=user_name,
                restrictions=enable_restrictions,
            )
            return

        create_restrictions = self._ensure_credential_user_enabled(restrictions)

        try:
            await add_user_with_pin(
                self._hass,
                entity_id,
                code_slot,
                usercode,
                user_name=user_name,
            )
        except LockAccessControlError as unified_error:
            _LOGGER.debug(
                "%s unified add_user_with_pin failed for %s: %s",
                LOG_PREFIX,
                entity_id,
                unified_error,
            )
        else:
            # User Code CC already wrote an enabled PIN; set_user alone (active/etc.)
            # fails with ZW0322 on locks that require user+credential together.
            optional_restrictions = self._restrictions_beyond_default_active(
                create_restrictions
            )
            if optional_restrictions or user_name is not None:
                await self._apply_user_restrictions_if_supported(
                    entity_id=entity_id,
                    user_id=code_slot,
                    user_name=user_name,
                    restrictions=optional_restrictions,
                )
            return

        await self._create_credential_user_with_pin(
            entity_id=entity_id,
            code_slot=code_slot,
            usercode=usercode,
            user_name=user_name,
            restrictions=create_restrictions,
        )

    async def _create_credential_user_with_pin(
        self,
        *,
        entity_id: str,
        code_slot: int,
        usercode: str,
        user_name: str | None,
        restrictions: dict,
    ) -> None:
        """Creates a credential user and PIN, preferring HA's coupled addUser path."""
        coupled_data: dict = {
            "entity_id": entity_id,
            "user_name": user_name or f"User {code_slot}",
            "credential_type": "pin_code",
            "credential_data": usercode,
            "credential_slot": code_slot,
        }
        coupled_data.update(restrictions)

        try:
            # Omitting user_id triggers access_control.addUser with credential (ZW0322-safe).
            await execute_ha_service(
                self._hass,
                domain=ZWAVE_JS_DOMAIN,
                service=ZWAVE_JS_SERVICE_SET_USER,
                service_data=coupled_data,
                return_response=True,
            )
            return
        except ServiceExecutionError as coupled_error:
            _LOGGER.debug(
                "%s coupled set_user+credential failed for %s: %s",
                LOG_PREFIX,
                entity_id,
                coupled_error,
            )

        set_user_data: dict = {
            "entity_id": entity_id,
            "user_id": code_slot,
            "user_name": user_name or f"User {code_slot}",
            "credential_type": "pin_code",
            "credential_data": usercode,
            "credential_slot": code_slot,
        }
        set_user_data.update(restrictions)

        try:
            await execute_ha_service(
                self._hass,
                domain=ZWAVE_JS_DOMAIN,
                service=ZWAVE_JS_SERVICE_SET_USER,
                service_data=set_user_data,
                return_response=True,
            )
            return
        except ServiceExecutionError as set_user_error:
            if not self._is_coupled_user_credential_error(set_user_error):
                raise
            _LOGGER.debug(
                "%s set_user with user_id rejected as coupled-only for %s: %s",
                LOG_PREFIX,
                entity_id,
                set_user_error,
            )

        await execute_ha_service(
            self._hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_SET_USER,
            service_data={
                "entity_id": entity_id,
                "user_id": code_slot,
                "user_name": user_name or f"User {code_slot}",
                **restrictions,
            },
            return_response=True,
        )
        await self._set_credential_pin(
            entity_id=entity_id,
            user_id=code_slot,
            usercode=usercode,
            credential_slot=code_slot,
        )

    async def _set_credential_pin(
        self,
        *,
        entity_id: str,
        user_id: int,
        usercode: str,
        credential_slot: int | None = None,
    ) -> None:
        """Writes a PIN credential using the HA credential_data field name."""
        service_data: dict = {
            "entity_id": entity_id,
            "user_id": user_id,
            "credential_type": "pin_code",
            "credential_data": usercode,
        }
        if credential_slot is not None:
            service_data["credential_slot"] = credential_slot

        await execute_ha_service(
            self._hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_SET_CREDENTIAL,
            service_data=service_data,
            return_response=True,
        )

    async def _apply_user_restrictions_if_supported(
        self,
        *,
        entity_id: str,
        user_id: int,
        user_name: str | None,
        restrictions: dict,
    ) -> None:
        """Applies set_user options when the lock allows standalone user updates."""
        if not restrictions and user_name is None:
            return

        try:
            await self._apply_user_restrictions(
                entity_id=entity_id,
                user_id=user_id,
                user_name=user_name,
                restrictions=restrictions,
            )
        except ServiceExecutionError as err:
            if self._is_coupled_user_credential_error(err):
                _LOGGER.warning(
                    "%s skipping set_user restrictions for %s user %s: %s",
                    LOG_PREFIX,
                    entity_id,
                    user_id,
                    err,
                )
                return
            raise

    def _ensure_credential_user_enabled(self, restrictions: dict) -> dict:
        """Defaults credential users to active=true unless the request overrides it."""
        enabled_restrictions = dict(restrictions)
        if "active" not in enabled_restrictions:
            enabled_restrictions["active"] = True
        return enabled_restrictions

    def _restrictions_beyond_default_active(self, restrictions: dict) -> dict:
        """Returns restrictions excluding the default active=true we inject on create."""
        return {
            key: value
            for key, value in restrictions.items()
            if not (key == "active" and value is True)
        }

    def _is_coupled_user_credential_error(self, err: Exception) -> bool:
        """Returns True for ZW0322 errors requiring user+credential in one call."""
        message = str(err)
        return (
            "ZW0322" in message
            or "must be stored together" in message
            or "Use setCredential() first" in message
            or "addUser()" in message
        )
    async def _update_lock_code(self, request_data: dict) -> dict:
        """Updates access-control restrictions for an existing lock user/slot."""
        device_id, lock_profile, entity_id = self._resolve_lock_target(request_data)
        code_slot = self._parse_code_slot(request_data.get("code_slot"))

        if lock_profile.get("api") != LOCK_CODE_API_CREDENTIAL:
            raise LockCodeRequestError(
                "user restrictions require credential API locks",
                action_result={
                    "device_id": device_id,
                    "entity_id": entity_id,
                    "code_slot": code_slot,
                },
            )

        restrictions = self._parse_restrictions(request_data, lock_profile)
        user_name = request_data.get("user_name")
        if not restrictions and user_name is None:
            raise LockCodeRequestError(
                "at least one of user_type, credential_rule, active or user_name is required",
                action_result={
                    "device_id": device_id,
                    "entity_id": entity_id,
                    "code_slot": code_slot,
                },
            )

        credential_user_id = await _resolve_user_id_for_slot(
            self._hass,
            entity_id,
            code_slot,
            LOCK_CODE_API_CREDENTIAL,
        )
        if credential_user_id is None:
            raise LockCodeRequestError(
                f"No user found for code_slot {code_slot}",
                action_result={
                    "device_id": device_id,
                    "entity_id": entity_id,
                    "code_slot": code_slot,
                },
            )

        await self._apply_user_restrictions(
            entity_id=entity_id,
            user_id=credential_user_id,
            user_name=user_name,
            restrictions=restrictions,
        )

        _LOGGER.info(
            "%s lock_code update [device: %s | slot: %d | user_id: %s | restrictions: %s]",
            LOG_PREFIX,
            device_id,
            code_slot,
            credential_user_id,
            restrictions,
        )
        return {
            "device_id": device_id,
            "entity_id": entity_id,
            "code_slot": code_slot,
            "user_id": credential_user_id,
            "user_name": user_name,
            **restrictions,
        }

    async def _apply_user_restrictions(
        self,
        *,
        entity_id: str,
        user_id: int,
        user_name: str | None,
        restrictions: dict,
    ) -> None:
        """Applies user_type/active/credential_rule/user_name via zwave_js.set_user."""
        service_data: dict = {
            "entity_id": entity_id,
            "user_id": user_id,
        }
        if user_name is not None:
            service_data["user_name"] = user_name
        service_data.update(restrictions)

        await execute_ha_service(
            self._hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_SET_USER,
            service_data=service_data,
            return_response=True,
        )

    async def _clear_lock_code_credential(self, entity_id: str, code_slot: int) -> None:
        """Clears a PIN from a credential lock using the API supported by the device."""
        credential_target = await _resolve_credential_for_slot(
            self._hass,
            entity_id,
            code_slot,
        )
        if credential_target is None:
            raise LockCodeRequestError(
                f"No credential found for code_slot {code_slot}",
                action_result={"entity_id": entity_id, "code_slot": code_slot},
            )

        credential_user_id, credential_slot = credential_target
        clear_errors: list[str] = []

        try:
            await execute_ha_service(
                self._hass,
                domain=ZWAVE_JS_DOMAIN,
                service=ZWAVE_JS_SERVICE_DELETE_CREDENTIAL,
                service_data={
                    "entity_id": entity_id,
                    "user_id": credential_user_id,
                    "credential_type": "pin_code",
                    "credential_slot": credential_slot,
                },
            )
            return
        except ServiceExecutionError as err:
            clear_errors.append(f"delete_credential: {err}")
            _LOGGER.warning(
                "%s delete_credential failed for %s slot %s, trying fallbacks: %s",
                LOG_PREFIX,
                entity_id,
                code_slot,
                err,
            )

        try:
            await execute_ha_service(
                self._hass,
                domain=ZWAVE_JS_DOMAIN,
                service=ZWAVE_JS_SERVICE_DELETE_ALL_CREDENTIALS,
                service_data={
                    "entity_id": entity_id,
                    "user_id": credential_user_id,
                },
            )
            return
        except ServiceExecutionError as err:
            clear_errors.append(f"delete_all_credentials: {err}")
            _LOGGER.warning(
                "%s delete_all_credentials failed for %s user %s: %s",
                LOG_PREFIX,
                entity_id,
                credential_user_id,
                err,
            )

        try:
            await execute_ha_service(
                self._hass,
                domain=ZWAVE_JS_DOMAIN,
                service=ZWAVE_JS_SERVICE_CLEAR_LOCK_USERCODE,
                service_data={
                    "entity_id": entity_id,
                    "code_slot": code_slot,
                },
            )
            return
        except ServiceExecutionError as err:
            clear_errors.append(f"clear_lock_usercode: {err}")
            _LOGGER.warning(
                "%s clear_lock_usercode failed for %s slot %s: %s",
                LOG_PREFIX,
                entity_id,
                code_slot,
                err,
            )

        try:
            await execute_ha_service(
                self._hass,
                domain=ZWAVE_JS_DOMAIN,
                service=ZWAVE_JS_SERVICE_DELETE_USER,
                service_data={
                    "entity_id": entity_id,
                    "user_id": credential_user_id,
                },
            )
            return
        except ServiceExecutionError as err:
            clear_errors.append(f"delete_user: {err}")

        raise LockCodeRequestError(
            f"Could not clear code_slot {code_slot}: {' | '.join(clear_errors)}",
            action_result={
                "entity_id": entity_id,
                "code_slot": code_slot,
                "user_id": credential_user_id,
            },
        )

    async def _clear_lock_code(self, request_data: dict) -> dict:
        """Validates and clears a user code from a lock slot."""
        device_id, lock_profile, entity_id = self._resolve_lock_target(request_data)
        code_slot = self._parse_code_slot(request_data.get("code_slot"))

        if lock_profile.get("api") == LOCK_CODE_API_CREDENTIAL:
            await self._clear_lock_code_credential(entity_id, code_slot)
        else:
            await self._clear_lock_code_usercode(
                entity_id=entity_id,
                code_slot=code_slot,
            )

        _LOGGER.info(
            "%s lock_code clear [device: %s | slot: %d]",
            LOG_PREFIX,
            device_id,
            code_slot,
        )
        return {
            "device_id": device_id,
            "entity_id": entity_id,
            "code_slot": code_slot,
        }

    async def _clear_lock_code_usercode(
        self,
        *,
        entity_id: str,
        code_slot: int,
    ) -> None:
        """Clears a legacy usercode PIN and disables Schedule Entry Lock for that slot."""
        clear_errors: list[str] = []
        has_cleared_slot = False

        try:
            await execute_ha_service(
                self._hass,
                domain=ZWAVE_JS_DOMAIN,
                service=ZWAVE_JS_SERVICE_CLEAR_LOCK_USERCODE,
                service_data={
                    "entity_id": entity_id,
                    "code_slot": code_slot,
                },
            )
            has_cleared_slot = True
        except ServiceExecutionError as err:
            clear_errors.append(f"clear_lock_usercode: {err}")

        try:
            await clear_user_code_slot(self._hass, entity_id, code_slot)
            has_cleared_slot = True
        except LockAccessControlError as err:
            clear_errors.append(str(err))
            if not has_cleared_slot:
                raise LockCodeRequestError(
                    f"Could not clear code_slot {code_slot}: {' | '.join(clear_errors)}",
                    action_result={
                        "entity_id": entity_id,
                        "code_slot": code_slot,
                    },
                ) from err
            _LOGGER.warning(
                "%s reinforced User Code clear failed for %s slot %s: %s",
                LOG_PREFIX,
                entity_id,
                code_slot,
                err,
            )

        try:
            await disable_user_code_schedule(self._hass, entity_id, code_slot)
        except LockAccessControlError as err:
            raise LockCodeRequestError(
                f"PIN cleared but could not disable schedule for slot {code_slot}: {err}",
                action_result={
                    "entity_id": entity_id,
                    "code_slot": code_slot,
                },
            ) from err

    async def _list_lock_codes(self, request_data: dict) -> dict:
        """Returns slot occupancy and optional credential metadata from the lock."""
        device_id, lock_profile, entity_id = self._resolve_lock_target(request_data)
        include_pins = bool(request_data.get("include_pins", False))

        if lock_profile.get("api") == LOCK_CODE_API_CREDENTIAL:
            slots = await fetch_lock_code_slots(
                self._hass,
                entity_id,
                LOCK_CODE_API_CREDENTIAL,
                include_pins=include_pins,
            )
            return {
                "device_id": device_id,
                "entity_id": entity_id,
                "slots": slots,
            }

        code_slot_filter = request_data.get("code_slot")
        parsed_code_slot = (
            self._parse_code_slot(code_slot_filter) if code_slot_filter is not None else None
        )
        slots = await fetch_lock_code_slots(
            self._hass,
            entity_id,
            LOCK_CODE_API_USERCODE,
            include_pins=include_pins,
            code_slot=parsed_code_slot,
        )
        return {
            "device_id": device_id,
            "entity_id": entity_id,
            "slots": slots,
        }

    async def _get_lock_capabilities(self, request_data: dict) -> dict:
        """Refreshes and returns lock user-code capabilities."""
        device_id, _lock_profile, entity_id = self._resolve_lock_target(request_data)

        from ..registry.lock_code_capabilities import fetch_lock_code_capabilities

        refreshed_profile = await fetch_lock_code_capabilities(self._hass, entity_id)
        lock_device_map = self._get_lock_device_map()
        lock_device_map[device_id] = refreshed_profile

        return {
            "device_id": device_id,
            "entity_id": entity_id,
            "capabilities": refreshed_profile,
        }

    def _resolve_lock_target(self, request_data: dict) -> tuple[str, dict, str]:
        """Resolves device_id to a known lock profile and entity_id."""
        device_id = request_data.get("device_id")
        if not device_id:
            raise LockCodeRequestError("device_id is required")

        lock_profile = self._get_lock_device_map().get(device_id)
        if lock_profile is None:
            raise LockCodeRequestError(f"device_id {device_id} is not a supported lock")

        entity_id = request_data.get("entity_id") or lock_profile.get("entity_id")
        if not entity_id:
            raise LockCodeRequestError(f"device_id {device_id} has no lock entity_id")

        if not lock_profile.get("supported", True):
            raise LockCodeRequestError(f"device_id {device_id} does not support lock codes")

        return device_id, lock_profile, entity_id

    def _parse_code_slot(self, code_slot) -> int:
        """Validates a lock code slot number."""
        if code_slot is None:
            raise LockCodeRequestError("code_slot is required")

        try:
            parsed_slot = int(code_slot)
        except (TypeError, ValueError) as err:
            raise LockCodeRequestError("code_slot must be an integer") from err

        if parsed_slot < LOCK_CODE_MIN_SLOT or parsed_slot > LOCK_CODE_MAX_SLOT:
            raise LockCodeRequestError(
                f"code_slot must be between {LOCK_CODE_MIN_SLOT} and {LOCK_CODE_MAX_SLOT}"
            )

        return parsed_slot

    def _parse_restrictions(self, request_data: dict, lock_profile: dict) -> dict:
        """Validates optional access-control restriction fields from the request."""
        restrictions: dict = {}

        user_type = request_data.get("user_type")
        if user_type is not None:
            normalized_user_type = str(user_type).strip().lower()
            if normalized_user_type not in LOCK_CODE_USER_TYPES:
                raise LockCodeRequestError(
                    f"user_type must be one of: {', '.join(sorted(LOCK_CODE_USER_TYPES))}"
                )
            supported_user_types = lock_profile.get("supported_user_types") or []
            if supported_user_types and normalized_user_type not in supported_user_types:
                raise LockCodeRequestError(
                    f"user_type '{normalized_user_type}' is not supported by this lock"
                )
            restrictions["user_type"] = normalized_user_type

        credential_rule = request_data.get("credential_rule")
        if credential_rule is not None:
            normalized_rule = str(credential_rule).strip().lower()
            if normalized_rule not in LOCK_CODE_CREDENTIAL_RULES:
                raise LockCodeRequestError(
                    "credential_rule must be one of: "
                    f"{', '.join(sorted(LOCK_CODE_CREDENTIAL_RULES))}"
                )
            supported_rules = lock_profile.get("supported_credential_rules") or []
            if supported_rules and normalized_rule not in supported_rules:
                raise LockCodeRequestError(
                    f"credential_rule '{normalized_rule}' is not supported by this lock"
                )
            restrictions["credential_rule"] = normalized_rule

        if "active" in request_data:
            active_value = request_data.get("active")
            if not isinstance(active_value, bool):
                raise LockCodeRequestError("active must be a boolean")
            restrictions["active"] = active_value

        return restrictions

    def _parse_usercode(self, usercode, max_pin_length: int | None) -> str:
        """Validates a PIN before sending it to the lock."""
        if usercode is None or str(usercode).strip() == "":
            raise LockCodeRequestError("usercode is required")

        normalized_usercode = str(usercode).strip()
        if not _PIN_DIGITS_PATTERN.match(normalized_usercode):
            raise LockCodeRequestError("usercode must contain digits only")

        if len(normalized_usercode) < LOCK_CODE_MIN_PIN_LENGTH:
            raise LockCodeRequestError(
                f"usercode must be at least {LOCK_CODE_MIN_PIN_LENGTH} digits"
            )

        if max_pin_length is not None and len(normalized_usercode) > max_pin_length:
            raise LockCodeRequestError(
                f"usercode must be at most {max_pin_length} digits"
            )

        return normalized_usercode

    async def _send_result(
        self,
        request_id: str | None,
        action: str,
        success: bool,
        error: str | None = None,
        action_result: dict | None = None,
    ) -> None:
        """Publishes a lock_code_result response to the external server."""
        action_result = action_result or {}
        payload = build_lock_code_result_message(
            project_id=self._project_id,
            serial=self._serial,
            request_id=request_id,
            action=action,
            success=success,
            error=error,
            device_id=action_result.get("device_id"),
            entity_id=action_result.get("entity_id"),
            code_slot=action_result.get("code_slot"),
            user_id=action_result.get("user_id"),
            slots=action_result.get("slots"),
            capabilities=action_result.get("capabilities"),
            user_name=action_result.get("user_name"),
            user_type=action_result.get("user_type"),
            credential_rule=action_result.get("credential_rule"),
            active=action_result.get("active"),
        )
        await self._send_message(payload)


async def execute_call_service_with_result(
    hass: HomeAssistant,
    project_id: str,
    serial: str,
    send_message,
    message: dict,
) -> None:
    """Executes a generic call_service message and returns call_service_result."""
    request_data = message.get("data", message)
    request_id = request_data.get("request_id")
    domain = request_data.get("domain")
    service = request_data.get("service")
    call_data = request_data.get("service_data", request_data.get("data", {}))

    if not domain or not service:
        if request_id:
            await send_message(
                build_call_service_result_message(
                    project_id=project_id,
                    serial=serial,
                    request_id=request_id,
                    success=False,
                    error="domain and service are required",
                )
            )
        return

    return_response = bool(request_data.get("return_response", False))

    try:
        response = await execute_ha_service(
            hass,
            domain=domain,
            service=service,
            service_data=call_data,
            return_response=return_response,
        )
        if request_id:
            await send_message(
                build_call_service_result_message(
                    project_id=project_id,
                    serial=serial,
                    request_id=request_id,
                    success=True,
                    response=response if return_response else None,
                )
            )
    except ServiceExecutionError as err:
        _LOGGER.error("%s call_service failed: %s", LOG_PREFIX, err)
        if request_id:
            await send_message(
                build_call_service_result_message(
                    project_id=project_id,
                    serial=serial,
                    request_id=request_id,
                    success=False,
                    error=str(err),
                )
            )


async def _resolve_user_id_for_slot(
    hass: HomeAssistant,
    entity_id: str,
    code_slot: int,
    lock_api: str,
) -> int | None:
    """Returns the lock user_id associated with a programmed code slot."""
    if lock_api != LOCK_CODE_API_CREDENTIAL:
        return code_slot

    user_slots = await fetch_lock_user_slots(hass, entity_id)
    for user_entry in user_slots:
        if user_entry.get("code_slot") == code_slot:
            user_id = user_entry.get("user_id")
            if user_id is not None:
                return int(user_id)

    return None


async def _resolve_credential_for_slot(
    hass: HomeAssistant,
    entity_id: str,
    code_slot: int,
) -> tuple[int, int] | None:
    """Returns the credential user_id and credential slot for a logical code slot."""
    user_slots = await fetch_lock_user_slots(hass, entity_id)
    for user_entry in user_slots:
        if user_entry.get("code_slot") != code_slot:
            continue

        credential_user_id = user_entry.get("user_id")
        credential_slots = user_entry.get("credential_slots") or []
        if credential_user_id is None or not credential_slots:
            continue

        return int(credential_user_id), int(credential_slots[0])

    return None


class LockCodeRequestError(Exception):
    """Raised when a lock-code request fails validation or lookup."""

    def __init__(self, message: str, action_result: dict | None = None) -> None:
        super().__init__(message)
        self.action_result = action_result or {}
