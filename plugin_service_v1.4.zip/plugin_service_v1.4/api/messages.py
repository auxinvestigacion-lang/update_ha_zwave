"""Standard message envelope builders for REST and WebSocket communication."""

from homeassistant.util import dt as dt_util

from ..const import (
    MESSAGE_VERSION,
    MSG_TYPE_AREA_REMOVED,
    MSG_TYPE_AREA_UPDATED,
    MSG_TYPE_CALL_SERVICE_RESULT,
    MSG_TYPE_DEVICE_REMOVED,
    MSG_TYPE_DEVICE_UPDATED,
    MSG_TYPE_LOCK_CODE_RESULT,
    MSG_TYPE_LOCK_NOTIFICATION,
    MSG_TYPE_STATE_SYNC,
)

# Attribute keys that never represent a user-facing device change.
IGNORED_CHANGE_ATTRIBUTES = frozenset(
    {
        "friendly_name",
        "icon",
        "entity_picture",
        "supported_features",
    }
)


def build_envelope(
    message_type: str,
    project_id: str,
    serial: str,
    data: dict,
) -> dict:
    """Wraps a payload in the standard message envelope."""
    return {
        "type": message_type,
        "version": MESSAGE_VERSION,
        "project_id": project_id,
        "serial": serial,
        "timestamp": dt_util.utcnow().isoformat(),
        "data": data,
    }


def build_register_message(
    project_id: str,
    serial: str,
    areas: list[dict],
    devices: list[dict],
) -> dict:
    """Builds the registration message sent to the REST endpoint."""
    return build_envelope(
        message_type="register",
        project_id=project_id,
        serial=serial,
        data={
            "areas": areas,
            "devices": devices,
        },
    )


def build_state_sync_message(
    project_id: str,
    serial: str,
    areas: list[dict],
    devices: list[dict],
) -> dict:
    """Builds a WebSocket snapshot with current device and entity states."""
    return build_envelope(
        message_type=MSG_TYPE_STATE_SYNC,
        project_id=project_id,
        serial=serial,
        data={
            "areas": areas,
            "devices": devices,
        },
    )


def build_auth_message(
    project_id: str,
    serial: str,
    api_key: str,
) -> dict:
    """Builds the WebSocket authentication message."""
    return build_envelope(
        message_type="auth",
        project_id=project_id,
        serial=serial,
        data={"api_key": api_key},
    )


def build_device_removed_message(
    project_id: str,
    serial: str,
    device_id: str,
) -> dict:
    """Builds a WebSocket message when an actionable device is removed."""
    return build_envelope(
        message_type=MSG_TYPE_DEVICE_REMOVED,
        project_id=project_id,
        serial=serial,
        data={"device_id": device_id},
    )


def build_device_updated_message(
    project_id: str,
    serial: str,
    device_id: str,
    changes: dict,
    entity_id: str | None = None,
) -> dict:
    """Builds a WebSocket message when device or entity registry metadata changes."""
    data: dict = {
        "device_id": device_id,
        "changes": changes,
    }
    if entity_id is not None:
        data["entity_id"] = entity_id

    return build_envelope(
        message_type=MSG_TYPE_DEVICE_UPDATED,
        project_id=project_id,
        serial=serial,
        data=data,
    )


def build_area_updated_message(
    project_id: str,
    serial: str,
    area_id: str,
    name: str,
) -> dict:
    """Builds a WebSocket message with the current area name from the HA registry."""
    return build_envelope(
        message_type=MSG_TYPE_AREA_UPDATED,
        project_id=project_id,
        serial=serial,
        data={
            "area_id": area_id,
            "name": name,
        },
    )


def build_area_removed_message(
    project_id: str,
    serial: str,
    area_id: str,
) -> dict:
    """Builds a WebSocket message when an area is removed."""
    return build_envelope(
        message_type=MSG_TYPE_AREA_REMOVED,
        project_id=project_id,
        serial=serial,
        data={"area_id": area_id},
    )


def build_state_changed_message(
    project_id: str,
    serial: str,
    device_id: str,
    entity_id: str,
    domain: str,
    device_class: str | None,
    old_state: str | None,
    new_state: str | None,
    changes: dict,
) -> dict:
    """Builds a debounced state_changed message for the WebSocket."""
    return build_envelope(
        message_type="state_changed",
        project_id=project_id,
        serial=serial,
        data={
            "device_id": device_id,
            "entity_id": entity_id,
            "domain": domain,
            "device_class": device_class,
            "state": {"old": old_state, "new": new_state},
            "changes": changes,
        },
    )


def extract_meaningful_changes(
    old_attributes: dict,
    new_attributes: dict,
    old_state: str | None,
    new_state: str | None,
    *,
    old_state_last_changed=None,
    new_state_last_changed=None,
) -> dict:
    """Returns attribute changes excluding metadata-only keys.

    When state and attributes are unchanged but Home Assistant updated
    last_changed (common for momentary switches on covers), the timestamp
    is included so the event is still forwarded.
    """
    changes: dict = {}

    if old_state != new_state:
        changes["state"] = {"old": old_state, "new": new_state}

    attribute_keys = set(old_attributes) | set(new_attributes)
    for attribute_key in attribute_keys:
        if attribute_key in IGNORED_CHANGE_ATTRIBUTES:
            continue

        old_value = old_attributes.get(attribute_key)
        new_value = new_attributes.get(attribute_key)
        if old_value != new_value:
            changes[attribute_key] = {"old": old_value, "new": new_value}

    if (
        not changes
        and old_state_last_changed is not None
        and new_state_last_changed is not None
        and old_state_last_changed != new_state_last_changed
    ):
        changes["last_changed"] = {
            "old": old_state_last_changed.isoformat(),
            "new": new_state_last_changed.isoformat(),
        }

    return changes


def build_call_service_result_message(
    project_id: str,
    serial: str,
    request_id: str,
    success: bool,
    error: str | None = None,
    response: dict | None = None,
) -> dict:
    """Builds a WebSocket response for a call_service request with request_id."""
    data: dict = {
        "request_id": request_id,
        "success": success,
    }
    if error is not None:
        data["error"] = error
    if response is not None:
        data["response"] = response

    return build_envelope(
        message_type=MSG_TYPE_CALL_SERVICE_RESULT,
        project_id=project_id,
        serial=serial,
        data=data,
    )


def build_lock_code_result_message(
    project_id: str,
    serial: str,
    request_id: str | None,
    action: str,
    success: bool,
    error: str | None = None,
    device_id: str | None = None,
    entity_id: str | None = None,
    code_slot: int | None = None,
    user_id: int | None = None,
    slots: list[dict] | None = None,
    capabilities: dict | None = None,
    user_name: str | None = None,
    user_type: str | None = None,
    credential_rule: str | None = None,
    active: bool | None = None,
) -> dict:
    """Builds a WebSocket response for a lock-code management request."""
    data: dict = {
        "action": action,
        "success": success,
    }
    if request_id is not None:
        data["request_id"] = request_id
    if error is not None:
        data["error"] = error
    if device_id is not None:
        data["device_id"] = device_id
    if entity_id is not None:
        data["entity_id"] = entity_id
    if code_slot is not None:
        data["code_slot"] = code_slot
    if user_id is not None:
        data["user_id"] = user_id
    if slots is not None:
        data["slots"] = slots
    if capabilities is not None:
        data["capabilities"] = capabilities
    if user_name is not None:
        data["user_name"] = user_name
    if user_type is not None:
        data["user_type"] = user_type
    if credential_rule is not None:
        data["credential_rule"] = credential_rule
    if active is not None:
        data["active"] = active

    return build_envelope(
        message_type=MSG_TYPE_LOCK_CODE_RESULT,
        project_id=project_id,
        serial=serial,
        data=data,
    )


def build_lock_notification_message(
    project_id: str,
    serial: str,
    device_id: str,
    entity_id: str | None,
    event: str | None,
    event_label: str | None,
    notification_type: str | None,
    user_id: int | None,
    code_slot: int | None,
    parameters: dict,
    source: str | None = None,
) -> dict:
    """Builds a WebSocket message for a lock unlock event with user identification."""
    data: dict = {
        "device_id": device_id,
        "event": event,
        "event_label": event_label,
        "notification_type": notification_type,
        "user_id": user_id,
        "code_slot": code_slot,
        "parameters": parameters,
    }
    if entity_id is not None:
        data["entity_id"] = entity_id
    if source is not None:
        data["source"] = source

    return build_envelope(
        message_type=MSG_TYPE_LOCK_NOTIFICATION,
        project_id=project_id,
        serial=serial,
        data=data,
    )


def merge_changes(existing_changes: dict, incoming_changes: dict) -> dict:
    """Merges two change maps keeping the original old and the latest new."""
    merged = dict(existing_changes)

    for change_key, change_values in incoming_changes.items():
        if change_key not in merged:
            merged[change_key] = dict(change_values)
            continue

        merged[change_key]["new"] = change_values["new"]

    return merged
