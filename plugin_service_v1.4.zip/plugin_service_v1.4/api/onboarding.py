"""Onboarding: registers areas, devices and entities with the external server via REST."""

import json
import logging

import aiohttp

from homeassistant.core import HomeAssistant

from ..const import (
    CONF_API_KEY,
    CONF_MAC,
    CONF_PROJECT_ID,
    LOG_PREFIX,
    ONBOARDING_ENDPOINT,
    RESP_PROJECT_ID,
    SERVER_URL,
)
from ..registry.data_collector import build_registration_payload
from ..registry.payload_serialization import dumps_payload_bytes
from ..registry.zwave_readiness import wait_for_zwave_inventory_ready

_LOGGER = logging.getLogger(__name__)


async def run_onboarding(hass: HomeAssistant, config: dict) -> dict | None:
    """Collects HA data and registers it with the external server.

    Returns the parsed server response on success, or None on failure.
    The server may confirm or override the project_id in its response.
    """
    await wait_for_zwave_inventory_ready(hass)
    payload = await build_registration_payload(hass, config)
    return await _post_to_server(config, payload)


async def _post_to_server(config: dict, payload: dict) -> dict | None:
    """Sends the registration payload and returns the server response body."""
    url = SERVER_URL.rstrip("/") + ONBOARDING_ENDPOINT
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": config[CONF_API_KEY],
    }

    _LOGGER.info(
        "%s registration POST to %s [project: %s | serial: %s]",
        LOG_PREFIX,
        url,
        config[CONF_PROJECT_ID],
        config[CONF_MAC],
    )

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                data=dumps_payload_bytes(payload),
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                body_text = await resp.text()

                if resp.status not in (200, 201):
                    _LOGGER.error(
                        "%s registration failed: HTTP %d — %s",
                        LOG_PREFIX,
                        resp.status,
                        body_text[:200],
                    )
                    return None

                response_body = _parse_response_body(body_text)
                _LOGGER.info(
                    "%s registration successful (HTTP %d) — project_id: %s",
                    LOG_PREFIX,
                    resp.status,
                    response_body.get(RESP_PROJECT_ID, config[CONF_PROJECT_ID]),
                )
                return response_body

    except aiohttp.ClientError as err:
        _LOGGER.error("%s registration connection error: %s", LOG_PREFIX, err)
        return None
    except Exception as err:
        _LOGGER.exception("%s registration unexpected error: %s", LOG_PREFIX, err)
        return None


def _parse_response_body(body_text: str) -> dict:
    """Parses the server response body, falling back to an empty dict."""
    if not body_text.strip():
        return {}

    try:
        parsed = json.loads(body_text)
        if isinstance(parsed, dict):
            return parsed
    except ValueError:
        _LOGGER.warning("%s registration response is not valid JSON", LOG_PREFIX)

    return {}
