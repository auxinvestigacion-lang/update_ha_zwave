"""Captures Door Lock Logging audit records from Z-Wave JS driver logs."""

import logging
import re
from collections.abc import Callable

from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import device_registry as dr
from zwave_js_server.const import CommandClass

from ..const import LOG_PREFIX
from .lock_unlock_identity_cache import LockUnlockIdentity, LockUnlockIdentityCache

_LOGGER = logging.getLogger(__name__)

ZWAVE_JS_DOMAIN = "zwave_js"
DOOR_LOCK_LOGGING_LOG_SOURCE = "zwave_driver_log"
USER_ID_LOG_PATTERN = re.compile(r"user\s*id\s*:\s*(\d+)", re.IGNORECASE)
UNLOCK_CODE_LABEL_MARKERS = (
    "unlocked via access code",
    "unlock via access code",
    "keypad unlock",
)


class ZwaveDriverLogListener:
    """Parses Door Lock Logging lines from Z-Wave JS driver log events."""

    def __init__(
        self,
        hass: HomeAssistant,
        identity_cache: LockUnlockIdentityCache,
        get_lock_device_map: Callable[[], dict[str, dict]],
    ) -> None:
        self._hass = hass
        self._identity_cache = identity_cache
        self._get_lock_device_map = get_lock_device_map
        self._driver_unsub = None
        self._log_listener_started = False

    def subscribe(self) -> None:
        """Subscribes to Z-Wave JS driver logging events."""
        if self._driver_unsub is not None:
            return

        client = _get_zwave_client(self._hass)
        if client is None or client.driver is None:
            _LOGGER.warning("%s zwave_js client unavailable for driver log listener", LOG_PREFIX)
            return

        self._ensure_log_stream(client)

        @callback
        def _on_driver_log(event: dict) -> None:
            self._handle_driver_log(client.driver, event)

        self._driver_unsub = client.driver.on("logging", _on_driver_log)
        _LOGGER.info("%s subscribed to Z-Wave driver logs for lock audit records", LOG_PREFIX)

    def unsubscribe(self) -> None:
        """Unsubscribes from Z-Wave JS driver logging events."""
        if self._driver_unsub:
            self._driver_unsub()
            self._driver_unsub = None

    def _ensure_log_stream(self, client) -> None:
        """Starts the Z-Wave JS log stream once for this HA session."""
        if self._log_listener_started:
            return

        async def _start_logs() -> None:
            try:
                await client.async_start_listening_logs()
                self._log_listener_started = True
            except Exception as err:
                _LOGGER.warning("%s failed to start Z-Wave log stream: %s", LOG_PREFIX, err)

        self._hass.async_create_task(_start_logs())

    def _handle_driver_log(self, driver, event: dict) -> None:
        """Parses a driver log event and stores unlock identities for tracked locks."""
        log_message = event.get("log_message")
        if log_message is None:
            return

        context = getattr(log_message, "context", None)
        node_id = getattr(context, "node_id", None) if context is not None else None
        command_class = getattr(context, "command_class", None) if context is not None else None

        formatted_lines = getattr(log_message, "formatted_message", None) or []
        message_blob = "\n".join(str(line) for line in formatted_lines)
        if not message_blob:
            return

        if not _is_door_lock_logging_message(command_class, message_blob):
            return

        if node_id is None:
            node_id = _extract_node_id_from_tags(
                getattr(log_message, "primary_tags", None),
                message_blob,
            )
        if node_id is None:
            return

        device_id = _resolve_device_id_for_node(self._hass, driver, node_id)
        if device_id is None or device_id not in self._get_lock_device_map():
            return

        user_id = _extract_user_id_from_log(message_blob)
        if user_id is None:
            return

        event_label = _extract_event_label_from_log(message_blob)
        self._identity_cache.store(
            device_id,
            LockUnlockIdentity(
                user_id=user_id,
                source=DOOR_LOCK_LOGGING_LOG_SOURCE,
                event_label=event_label,
                parameters={"userId": user_id},
            ),
        )
        _LOGGER.info(
            "%s captured unlock user from Z-Wave log [device: %s | node: %s | user_id: %s]",
            LOG_PREFIX,
            device_id,
            node_id,
            user_id,
        )


def _get_zwave_client(hass: HomeAssistant):
    """Returns the first loaded zwave_js client, when available."""
    from homeassistant.components.zwave_js import DOMAIN
    from homeassistant.config_entries import ConfigEntryState

    for entry in hass.config_entries.async_entries(DOMAIN):
        if entry.state is not ConfigEntryState.LOADED:
            continue
        runtime_data = entry.runtime_data
        client = getattr(runtime_data, "client", None)
        if client is not None:
            return client

    return None


def _resolve_device_id_for_node(hass: HomeAssistant, driver, node_id: int) -> str | None:
    """Maps a Z-Wave node ID to a Home Assistant device_id."""
    from homeassistant.components.zwave_js.helpers import get_device_id

    node = driver.controller.nodes.get(node_id)
    if node is None:
        return None

    device_registry = dr.async_get(hass)
    device = device_registry.async_get_device(identifiers={get_device_id(driver, node)})
    return device.id if device is not None else None


def _is_door_lock_logging_message(command_class, message_blob: str) -> bool:
    """Returns True when a log message looks like a Door Lock Logging audit record."""
    if command_class == CommandClass.DOOR_LOCK_LOGGING:
        return True

    normalized_blob = message_blob.casefold()
    if "doorlocklogging" in normalized_blob:
        return True

    return any(marker in normalized_blob for marker in UNLOCK_CODE_LABEL_MARKERS)


def _extract_user_id_from_log(message_blob: str) -> int | None:
    """Extracts the numeric user ID from a Door Lock Logging log block."""
    match = USER_ID_LOG_PATTERN.search(message_blob)
    if match is None:
        return None

    try:
        return int(match.group(1))
    except ValueError:
        return None


def _extract_event_label_from_log(message_blob: str) -> str | None:
    """Extracts the human-readable unlock label from a log block."""
    for line in message_blob.splitlines():
        normalized_line = line.strip()
        if normalized_line.lower().startswith("event type:"):
            return normalized_line.split(":", 1)[1].strip()
    return None


def _extract_node_id_from_tags(primary_tags: str | None, message_blob: str) -> int | None:
    """Extracts node ID from Z-Wave log tags when context metadata is missing."""
    tag_blob = " ".join(filter(None, [primary_tags, message_blob]))
    match = re.search(r"Node\s+(\d+)", tag_blob, re.IGNORECASE)
    if match is None:
        return None

    try:
        return int(match.group(1))
    except ValueError:
        return None
