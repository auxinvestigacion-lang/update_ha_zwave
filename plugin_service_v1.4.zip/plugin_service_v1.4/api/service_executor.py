"""Executes Home Assistant service calls with optional response data."""

from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError


class ServiceExecutionError(Exception):
    """Raised when a Home Assistant service call fails."""


async def execute_ha_service(
    hass: HomeAssistant,
    domain: str,
    service: str,
    service_data: dict,
    *,
    return_response: bool = False,
) -> dict | None:
    """Calls a Home Assistant service and optionally returns the service response."""
    try:
        return await hass.services.async_call(
            domain,
            service,
            service_data,
            blocking=True,
            return_response=return_response,
        )
    except HomeAssistantError as err:
        raise ServiceExecutionError(
            f"execute_ha_service {domain}.{service}: {err}"
        ) from err
    except Exception as err:
        raise ServiceExecutionError(
            f"execute_ha_service {domain}.{service}: {err}"
        ) from err
