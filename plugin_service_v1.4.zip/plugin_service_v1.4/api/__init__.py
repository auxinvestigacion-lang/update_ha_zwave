"""External server communication: REST registration, WebSocket and message protocol."""
