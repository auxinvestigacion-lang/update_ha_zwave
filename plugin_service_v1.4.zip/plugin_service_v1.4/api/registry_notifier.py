"""Forwards actionable registry changes to the external server over WebSocket."""

import asyncio
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import Enum

from homeassistant.core import Event, HomeAssistant
from homeassistant.helpers import area_registry as ar
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

from ..const import LOG_PREFIX, TRACKED_ENTITIES_REFRESH_DEBOUNCE_SECONDS
from ..registry.registry_change_normalizer import (
    build_device_current_values,
    build_entity_current_values,
    build_virtual_name_change_from_entity,
    build_virtual_name_change_from_ha_device,
    normalize_device_registry_changes,
    normalize_entity_registry_changes,
)
from ..registry.registry_event_filter import (
    is_known_actionable_device,
    should_notify_entity_registry_update,
)
from ..registry.standalone_filter import parse_logical_device_id
from ..registry.virtual_collector import get_virtual_logical_ids_for_ha_device
from .messages import (
    build_area_removed_message,
    build_area_updated_message,
    build_device_removed_message,
    build_device_updated_message,
    merge_changes,
)

_LOGGER = logging.getLogger(__name__)

REGISTRY_ACTION_CREATE = "create"
REGISTRY_ACTION_UPDATE = "update"
REGISTRY_ACTION_REMOVE = "remove"
REGISTRY_ACTION_REORDER = "reorder"


class _PendingKind(str, Enum):
    """Kinds of debounced registry notifications."""

    DEVICE_UPDATED = "device_updated"
    DEVICE_REMOVED = "device_removed"
    AREA_UPDATED = "area_updated"
    AREA_REMOVED = "area_removed"


@dataclass
class _PendingRegistryNotification:
    """Debounced registry payload waiting to be sent."""

    kind: _PendingKind
    resource_id: str
    changes: dict = field(default_factory=dict)
    entity_id: str | None = None
    area_name: str | None = None


class RegistryNotifier:
    """Listens to HA registry events and publishes debounced WebSocket messages."""

    def __init__(
        self,
        hass: HomeAssistant,
        project_id: str,
        serial: str,
        send_message: Callable[[dict], Awaitable[None]],
        get_known_device_ids: Callable[[], set[str]],
        schedule_tracked_entities_refresh: Callable[[], Awaitable[None]],
    ) -> None:
        self._hass = hass
        self._project_id = project_id
        self._serial = serial
        self._send_message = send_message
        self._get_known_device_ids = get_known_device_ids
        self._schedule_tracked_entities_refresh = schedule_tracked_entities_refresh
        self._unsubs: list[Callable[[], None]] = []
        self._pending: dict[str, _PendingRegistryNotification] = {}
        self._debounce_tasks: dict[str, asyncio.Task] = {}

    def subscribe(self) -> None:
        """Subscribes to device, entity and area registry update events."""
        if self._unsubs:
            return

        async def _on_device_registry_updated(event: Event) -> None:
            await self._handle_device_registry_event(event)
            await self._schedule_tracked_entities_refresh()

        async def _on_entity_registry_updated(event: Event) -> None:
            await self._handle_entity_registry_event(event)
            await self._schedule_tracked_entities_refresh()

        async def _on_area_registry_updated(event: Event) -> None:
            await self._handle_area_registry_event(event)
            await self._schedule_tracked_entities_refresh()

        self._unsubs = [
            self._hass.bus.async_listen(
                "device_registry_updated",
                _on_device_registry_updated,
            ),
            self._hass.bus.async_listen(
                "entity_registry_updated",
                _on_entity_registry_updated,
            ),
            self._hass.bus.async_listen(
                "area_registry_updated",
                _on_area_registry_updated,
            ),
        ]

    def unsubscribe(self) -> None:
        """Unsubscribes from registry events and cancels pending notifications."""
        for unsub in self._unsubs:
            unsub()

        self._unsubs = []
        self._cancel_pending_notifications()

    async def _handle_device_registry_event(self, event: Event) -> None:
        """Processes device registry create, update and remove actions."""
        action = event.data.get("action")
        device_id = event.data.get("device_id")

        if action == REGISTRY_ACTION_CREATE or not device_id:
            return

        if action == REGISTRY_ACTION_REMOVE:
            await self._handle_device_removed(device_id)
            return

        if action != REGISTRY_ACTION_UPDATE:
            return

        if await self._queue_virtual_ha_device_name_update(device_id, event):
            return

        await self._handle_physical_device_updated(device_id, event)

    async def _handle_device_removed(self, device_id: str) -> None:
        """Queues device_removed when an actionable physical device disappears."""
        if not is_known_actionable_device(
            self._hass, device_id, self._get_known_device_ids()
        ):
            return

        self._cancel_pending_for_device(device_id)
        await self._queue_notification(
            pending_key=f"device:{device_id}:remove",
            notification=_PendingRegistryNotification(
                kind=_PendingKind.DEVICE_REMOVED,
                resource_id=device_id,
            ),
        )

    async def _handle_physical_device_updated(self, device_id: str, event: Event) -> None:
        """Queues device_updated for an actionable physical device registry change."""
        if not is_known_actionable_device(
            self._hass, device_id, self._get_known_device_ids()
        ):
            return

        device_reg = dr.async_get(self._hass)
        device = device_reg.async_get(device_id)
        if device is None:
            return

        changes = normalize_device_registry_changes(
            event.data.get("changes", {}),
            build_device_current_values(device),
        )
        if not changes:
            return

        await self._queue_device_updated(device_id=device_id, changes=changes)

    async def _queue_virtual_ha_device_name_update(
        self,
        ha_device_id: str,
        event: Event,
    ) -> bool:
        """Forwards a template-only HA device rename as virtual device_updated.

        Returns True when the HA device belongs to virtual helpers, even if the
        change is not a name update, so it is not treated as physical hardware.
        """
        logical_ids = get_virtual_logical_ids_for_ha_device(self._hass, ha_device_id)
        if not logical_ids:
            return False

        device_reg = dr.async_get(self._hass)
        device = device_reg.async_get(ha_device_id)
        if device is None:
            return True

        name_changes = build_virtual_name_change_from_ha_device(
            event.data.get("changes", {}),
            device,
        )
        if not name_changes:
            return True

        for logical_id in logical_ids:
            await self._queue_device_updated(device_id=logical_id, changes=name_changes)

        return True

    async def _handle_entity_registry_event(self, event: Event) -> None:
        """Processes entity registry update actions for actionable devices."""
        action = event.data.get("action")
        entity_id = event.data.get("entity_id")

        if action != REGISTRY_ACTION_UPDATE or not entity_id:
            return

        should_notify, device_id = should_notify_entity_registry_update(
            self._hass,
            entity_id,
            self._get_known_device_ids(),
        )
        if not should_notify or device_id is None:
            return

        entity_reg = er.async_get(self._hass)
        entry = entity_reg.async_get(entity_id)
        if entry is None:
            return

        if parse_logical_device_id(device_id) is not None:
            await self._queue_virtual_entity_registry_update(
                device_id, entity_id, entry, event
            )
            return

        changes = normalize_entity_registry_changes(
            event.data.get("changes", {}),
            build_entity_current_values(entry),
        )
        if not changes:
            return

        await self._queue_device_updated(
            device_id=device_id,
            changes=changes,
            entity_id=entity_id,
        )

    async def _queue_virtual_entity_registry_update(
        self,
        device_id: str,
        entity_id: str,
        entry: er.RegistryEntry,
        event: Event,
    ) -> None:
        """Forwards virtual helper renames as device-level name updates."""
        ha_changes = event.data.get("changes", {})
        name_changes = build_virtual_name_change_from_entity(ha_changes, entry)
        if name_changes:
            await self._queue_device_updated(device_id=device_id, changes=name_changes)

        entity_changes = normalize_entity_registry_changes(
            ha_changes,
            build_entity_current_values(entry),
        )
        entity_changes.pop("name", None)
        entity_changes.pop("name_by_user", None)
        if not entity_changes:
            return

        await self._queue_device_updated(
            device_id=device_id,
            changes=entity_changes,
            entity_id=entity_id,
        )

    async def _handle_area_registry_event(self, event: Event) -> None:
        """Processes area registry update and remove actions."""
        action = event.data.get("action")
        area_id = event.data.get("area_id")

        if action == REGISTRY_ACTION_CREATE or action == REGISTRY_ACTION_REORDER:
            return

        if not area_id:
            return

        if action == REGISTRY_ACTION_REMOVE:
            self._cancel_pending_for_area(area_id)
            await self._queue_notification(
                pending_key=f"area:{area_id}:remove",
                notification=_PendingRegistryNotification(
                    kind=_PendingKind.AREA_REMOVED,
                    resource_id=area_id,
                ),
            )
            return

        if action != REGISTRY_ACTION_UPDATE:
            return

        area_reg = ar.async_get(self._hass)
        area = area_reg.async_get_area(area_id)
        if area is None:
            return

        pending_key = f"area:{area_id}:update"
        existing = self._pending.get(pending_key)
        if existing is None:
            notification = _PendingRegistryNotification(
                kind=_PendingKind.AREA_UPDATED,
                resource_id=area_id,
                area_name=area.name,
            )
        else:
            existing.area_name = area.name
            notification = existing

        await self._queue_notification(pending_key=pending_key, notification=notification)

    async def _queue_device_updated(
        self,
        device_id: str,
        changes: dict,
        entity_id: str | None = None,
    ) -> None:
        """Queues a debounced device_updated notification."""
        pending_key = (
            f"device:{device_id}:entity:{entity_id}"
            if entity_id
            else f"device:{device_id}:update"
        )
        existing = self._pending.get(pending_key)

        if existing is None:
            notification = _PendingRegistryNotification(
                kind=_PendingKind.DEVICE_UPDATED,
                resource_id=device_id,
                changes=dict(changes),
                entity_id=entity_id,
            )
        else:
            existing.changes = merge_changes(existing.changes, changes)
            notification = existing

        await self._queue_notification(pending_key=pending_key, notification=notification)

    async def _queue_notification(
        self,
        pending_key: str,
        notification: _PendingRegistryNotification,
    ) -> None:
        """Stores a pending notification and schedules its debounced flush."""
        self._pending[pending_key] = notification

        existing_task = self._debounce_tasks.pop(pending_key, None)
        if existing_task:
            existing_task.cancel()

        self._debounce_tasks[pending_key] = asyncio.create_task(
            self._flush_notification(pending_key)
        )

    async def _flush_notification(self, pending_key: str) -> None:
        """Sends a debounced registry notification after the debounce window."""
        try:
            await asyncio.sleep(TRACKED_ENTITIES_REFRESH_DEBOUNCE_SECONDS)
            notification = self._pending.pop(pending_key, None)
            self._debounce_tasks.pop(pending_key, None)

            if notification is None:
                return

            payload = self._build_payload(notification)
            _LOGGER.info(
                "%s registry %s | %s",
                LOG_PREFIX,
                payload["type"],
                _describe_registry_payload(payload),
            )
            await self._send_message(payload)
        except asyncio.CancelledError:
            return

    def _build_payload(self, notification: _PendingRegistryNotification) -> dict:
        """Builds the WebSocket payload for a pending registry notification."""
        if notification.kind == _PendingKind.DEVICE_REMOVED:
            return build_device_removed_message(
                project_id=self._project_id,
                serial=self._serial,
                device_id=notification.resource_id,
            )

        if notification.kind == _PendingKind.DEVICE_UPDATED:
            return build_device_updated_message(
                project_id=self._project_id,
                serial=self._serial,
                device_id=notification.resource_id,
                entity_id=notification.entity_id,
                changes=notification.changes,
            )

        if notification.kind == _PendingKind.AREA_REMOVED:
            return build_area_removed_message(
                project_id=self._project_id,
                serial=self._serial,
                area_id=notification.resource_id,
            )

        return build_area_updated_message(
            project_id=self._project_id,
            serial=self._serial,
            area_id=notification.resource_id,
            name=notification.area_name or "",
        )

    def _cancel_pending_for_device(self, device_id: str) -> None:
        """Drops pending device updates when the device is removed."""
        keys_to_cancel = [
            pending_key
            for pending_key in self._pending
            if pending_key.startswith(f"device:{device_id}:")
            and not pending_key.endswith(":remove")
        ]
        for pending_key in keys_to_cancel:
            self._cancel_pending_key(pending_key)

    def _cancel_pending_for_area(self, area_id: str) -> None:
        """Drops pending area updates when the area is removed."""
        keys_to_cancel = [
            pending_key
            for pending_key in self._pending
            if pending_key.startswith(f"area:{area_id}:")
            and not pending_key.endswith(":remove")
        ]
        for pending_key in keys_to_cancel:
            self._cancel_pending_key(pending_key)

    def _cancel_pending_key(self, pending_key: str) -> None:
        """Cancels one pending registry notification."""
        self._pending.pop(pending_key, None)
        pending_task = self._debounce_tasks.pop(pending_key, None)
        if pending_task:
            pending_task.cancel()

    def _cancel_pending_notifications(self) -> None:
        """Cancels all pending registry notifications."""
        for pending_task in self._debounce_tasks.values():
            pending_task.cancel()

        self._debounce_tasks.clear()
        self._pending.clear()


def _describe_registry_payload(payload: dict) -> str:
    """Builds a short log summary for a registry notification."""
    data = payload.get("data", {})
    resource_id = data.get("device_id") or data.get("area_id") or "unknown"
    entity_id = data.get("entity_id")
    area_name = data.get("name")
    changes = data.get("changes", {})
    change_keys = sorted(changes.keys())

    if entity_id:
        return f"{resource_id} / {entity_id} | changes: {change_keys}"

    if area_name is not None:
        return f"{resource_id} | name: {area_name}"

    return f"{resource_id} | changes: {change_keys}"
