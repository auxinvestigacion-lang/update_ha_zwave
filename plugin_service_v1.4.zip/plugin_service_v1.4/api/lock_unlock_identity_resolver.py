"""Resolves lock unlock identity from multiple Z-Wave data sources."""

import asyncio
import logging

from homeassistant.core import HomeAssistant

from ..const import (
    LOCK_IDENTITY_CACHE_MAX_AGE_SECONDS,
    LOCK_IDENTITY_RESOLVE_WAIT_SECONDS,
    LOCK_IDENTITY_RETRY_INTERVAL_SECONDS,
    LOG_PREFIX,
)
from .door_lock_logging_resolver import fetch_latest_code_unlock_record
from .lock_unlock_identity_cache import LockUnlockIdentity, LockUnlockIdentityCache

_LOGGER = logging.getLogger(__name__)

DOOR_LOCK_LOGGING_API_SOURCE = "door_lock_logging"


async def resolve_lock_unlock_identity(
    hass: HomeAssistant,
    device_id: str,
    entity_id: str,
    identity_cache: LockUnlockIdentityCache,
) -> LockUnlockIdentity | None:
    """Resolves unlock identity using cache, polling, and short retries."""
    cached_identity = identity_cache.get_recent(device_id)
    if cached_identity is not None:
        return cached_identity

    unlock_record = await fetch_latest_code_unlock_record(hass, device_id, entity_id)
    if unlock_record is not None:
        identity = LockUnlockIdentity(
            user_id=unlock_record.user_id,
            source=DOOR_LOCK_LOGGING_API_SOURCE,
            event_label=unlock_record.event_label,
            event_type=unlock_record.event_type,
            parameters={
                "userId": unlock_record.user_id,
                "eventType": unlock_record.event_type,
                "recordNumber": unlock_record.record_number,
                "timestamp": unlock_record.timestamp,
            },
        )
        identity_cache.store(device_id, identity)
        return identity

    retry_deadline = asyncio.get_running_loop().time() + LOCK_IDENTITY_RESOLVE_WAIT_SECONDS
    while asyncio.get_running_loop().time() < retry_deadline:
        await asyncio.sleep(LOCK_IDENTITY_RETRY_INTERVAL_SECONDS)
        cached_identity = identity_cache.get_recent(device_id)
        if cached_identity is not None:
            return cached_identity

    _LOGGER.warning(
        "%s could not resolve unlock identity [device: %s | entity: %s]",
        LOG_PREFIX,
        device_id,
        entity_id,
    )
    return None


def create_lock_unlock_identity_cache() -> LockUnlockIdentityCache:
    """Creates the shared unlock identity cache."""
    return LockUnlockIdentityCache(LOCK_IDENTITY_CACHE_MAX_AGE_SECONDS)
