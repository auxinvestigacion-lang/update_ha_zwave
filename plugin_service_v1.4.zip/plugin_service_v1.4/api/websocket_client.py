"""WebSocket client to the external server.

Responsibilities:
- Persistent connection with automatic reconnection (exponential backoff).
- Publish debounced state_changed events for actionable devices to the server.
- Receive call_service commands from the server and execute them in HA.

Keepalive is handled at the WebSocket protocol level: the server sends ws.ping()
and aiohttp responds with pong automatically (autoping=True).
"""

import asyncio
import json
import logging

import aiohttp
from homeassistant.core import Event, HomeAssistant

from ..const import (
    CONF_API_KEY,
    CONF_MAC,
    CONF_PROJECT_ID,
    EVENT_DEBOUNCE_SECONDS,
    LOG_PREFIX,
    MSG_TYPE_AUTH_OK,
    MSG_TYPE_CALL_SERVICE,
    MSG_TYPE_LOCK_CODE_CLEAR,
    MSG_TYPE_LOCK_CODE_GET_CAPABILITIES,
    MSG_TYPE_LOCK_CODE_LIST,
    MSG_TYPE_LOCK_CODE_SET,
    MSG_TYPE_LOCK_CODE_UPDATE,
    TRACKED_ENTITIES_REFRESH_DEBOUNCE_SECONDS,
    WS_RECONNECT_BACKOFF_FACTOR,
    WS_RECONNECT_DELAY_INITIAL,
    WS_RECONNECT_DELAY_MAX,
    WS_URL,
)
from ..registry.data_collector import (
    build_state_sync_payload,
    build_tracked_entity_map,
    collect_inventory_with_lock_codes,
)
from ..registry.lock_code_capabilities import build_lock_device_map
from ..registry.payload_serialization import dumps_payload
from ..registry.zwave_readiness import wait_for_zwave_inventory_ready
from .lock_code_handler import LockCodeHandler, execute_call_service_with_result
from .lock_notification_forwarder import LockNotificationForwarder
from .lock_unlock_identity_resolver import create_lock_unlock_identity_cache
from .registry_notifier import RegistryNotifier
from .messages import (
    build_auth_message,
    build_state_changed_message,
    extract_meaningful_changes,
    merge_changes,
)

_LOGGER = logging.getLogger(__name__)


class WSClient:
    """WebSocket client to the external server."""

    def __init__(self, hass: HomeAssistant, config: dict) -> None:
        self.hass = hass
        self._api_key: str = config[CONF_API_KEY]
        self._project_id: str = config[CONF_PROJECT_ID]
        self._serial: str = config[CONF_MAC]

        self._session: aiohttp.ClientSession | None = None
        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._reconnect_task: asyncio.Task | None = None
        self._state_unsub = None
        self._registry_notifier: RegistryNotifier | None = None
        self._registry_refresh_task: asyncio.Task | None = None
        self._send_lock: asyncio.Lock | None = None
        self._stop: bool = False
        self._tracked_entities: dict[str, str] = {}
        self._lock_devices: dict[str, dict] = {}
        self._lock_identity_cache = create_lock_unlock_identity_cache()
        self._lock_code_handler: LockCodeHandler | None = None
        self._lock_notification_forwarder: LockNotificationForwarder | None = None
        self._pending_events: dict[str, dict] = {}
        self._debounce_tasks: dict[str, asyncio.Task] = {}

    @property
    def is_running(self) -> bool:
        """Returns True if the reconnection loop is active."""
        return self._reconnect_task is not None and not self._reconnect_task.done()

    async def start(self) -> None:
        """Starts the client and the reconnection loop."""
        if self.is_running:
            return

        self._stop = False
        self._send_lock = asyncio.Lock()
        self._session = aiohttp.ClientSession()
        self._refresh_tracked_entities()
        self._subscribe_lock_notifications()
        self._reconnect_task = asyncio.create_task(self._connection_loop())
        asyncio.create_task(self._refresh_lock_devices_from_inventory())
        _LOGGER.info("%s client started → %s", LOG_PREFIX, WS_URL)

    async def refresh_tracked_entities(self) -> None:
        """Refreshes the entity map after a new registration sync."""
        self._refresh_tracked_entities()

    async def stop(self) -> None:
        """Stops the client cleanly."""
        self._stop = True
        self._unsubscribe_state_changes()
        self._unsubscribe_registry_updates()
        self._unsubscribe_lock_notifications()
        await self._cancel_all_debounce_tasks()

        if self._reconnect_task:
            self._reconnect_task.cancel()
            try:
                await self._reconnect_task
            except asyncio.CancelledError:
                pass
            self._reconnect_task = None

        await self._close_connection()
        _LOGGER.info("%s client stopped", LOG_PREFIX)

    def _refresh_tracked_entities(self) -> None:
        """Reloads the tracked entity map from actionable devices."""
        previous_ids = set(self._tracked_entities)
        self._tracked_entities = build_tracked_entity_map(self.hass)
        added_ids = sorted(set(self._tracked_entities) - previous_ids)

        _LOGGER.info(
            "%s tracking %d primary entities across actionable devices",
            LOG_PREFIX,
            len(self._tracked_entities),
        )
        if added_ids:
            preview = ", ".join(added_ids[:8])
            suffix = "..." if len(added_ids) > 8 else ""
            _LOGGER.info(
                "%s added %d trackable entities: %s%s",
                LOG_PREFIX,
                len(added_ids),
                preview,
                suffix,
            )

    def _build_runtime_config(self) -> dict:
        """Builds the runtime config dict used for inventory payloads."""
        return {
            CONF_PROJECT_ID: self._project_id,
            CONF_MAC: self._serial,
            CONF_API_KEY: self._api_key,
        }

    async def _connection_loop(self) -> None:
        """Keeps the connection active with exponential backoff on failure."""
        delay = WS_RECONNECT_DELAY_INITIAL

        while not self._stop:
            try:
                connection_duration = await self._connect_and_listen()
                if connection_duration >= 60:
                    delay = WS_RECONNECT_DELAY_INITIAL

                if not self._stop:
                    _LOGGER.warning(
                        "%s connection closed after %.1fs — reconnecting in %ds…",
                        LOG_PREFIX,
                        connection_duration,
                        delay,
                    )
            except asyncio.CancelledError:
                return
            except Exception as err:
                _LOGGER.warning(
                    "%s connection error: %s — reconnecting in %ds…",
                    LOG_PREFIX,
                    err,
                    delay,
                )

            if self._stop:
                return

            self._unsubscribe_state_changes()
            self._unsubscribe_registry_updates()
            await self._cancel_all_debounce_tasks()
            await asyncio.sleep(delay)
            delay = min(delay * WS_RECONNECT_BACKOFF_FACTOR, WS_RECONNECT_DELAY_MAX)

    async def _connect_and_listen(self) -> float:
        """Opens the WS connection and listens until it closes. Returns session duration."""
        loop = asyncio.get_running_loop()
        connected_at = loop.time()

        if not self._session or self._session.closed:
            self._session = aiohttp.ClientSession()

        try:
            self._ws = await self._session.ws_connect(
                WS_URL,
                autoping=True,
                heartbeat=None,
                timeout=aiohttp.ClientWSTimeout(ws_close=10),
            )

            await self._send_json(
                build_auth_message(
                    project_id=self._project_id,
                    serial=self._serial,
                    api_key=self._api_key,
                )
            )

            self._subscribe_state_changes()
            self._subscribe_registry_updates()
            _LOGGER.info("%s connected to %s — streaming state changes", LOG_PREFIX, WS_URL)

            async for msg in self._ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    await self._handle_message(msg.data)
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    _LOGGER.error("%s frame error: %s", LOG_PREFIX, self._ws.exception())
                    break
                elif msg.type in (
                    aiohttp.WSMsgType.CLOSE,
                    aiohttp.WSMsgType.CLOSING,
                    aiohttp.WSMsgType.CLOSED,
                ):
                    close_code = self._ws.close_code if self._ws else None
                    _LOGGER.warning(
                        "%s connection closed [code=%s exception=%s]",
                        LOG_PREFIX,
                        close_code,
                        self._ws.exception() if self._ws else None,
                    )
                    break

        finally:
            self._unsubscribe_state_changes()
            self._unsubscribe_registry_updates()
            await self._cancel_all_debounce_tasks()
            if self._ws and not self._ws.closed:
                await self._ws.close()
            self._ws = None

        return loop.time() - connected_at

    async def _close_connection(self) -> None:
        """Closes the WS and session safely."""
        await self._cancel_all_debounce_tasks()

        if self._ws and not self._ws.closed:
            await self._ws.close()
        if self._session and not self._session.closed:
            await self._session.close()

        self._ws = None
        self._session = None
        self._send_lock = None

    async def _send_json(self, payload: dict) -> None:
        """Sends a JSON payload through the active WebSocket connection."""
        if not self._ws or self._ws.closed or not self._send_lock:
            return

        async with self._send_lock:
            await self._ws.send_str(dumps_payload(payload))

    async def _handle_message(self, raw: str) -> None:
        """Processes a text message received from the server."""
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            _LOGGER.warning("%s non-JSON message received: %s", LOG_PREFIX, raw[:100])
            return

        msg_type = message.get("type")

        if msg_type == MSG_TYPE_AUTH_OK:
            _LOGGER.info("%s server acknowledged auth_ok", LOG_PREFIX)
            await self._send_state_snapshot()
            return

        if msg_type == MSG_TYPE_CALL_SERVICE:
            await self._execute_service(message)
            return

        if self._lock_code_handler is not None:
            lock_code_handlers = {
                MSG_TYPE_LOCK_CODE_SET: self._lock_code_handler.handle_set,
                MSG_TYPE_LOCK_CODE_CLEAR: self._lock_code_handler.handle_clear,
                MSG_TYPE_LOCK_CODE_UPDATE: self._lock_code_handler.handle_update,
                MSG_TYPE_LOCK_CODE_LIST: self._lock_code_handler.handle_list,
                MSG_TYPE_LOCK_CODE_GET_CAPABILITIES: (
                    self._lock_code_handler.handle_get_capabilities
                ),
            }
            handler = lock_code_handlers.get(msg_type)
            if handler is not None:
                await handler(message)
                return

        _LOGGER.debug("%s unknown message: %s", LOG_PREFIX, msg_type)

    async def _send_state_snapshot(self) -> None:
        """Pushes the full inventory with current states after authentication."""
        await wait_for_zwave_inventory_ready(self.hass)
        self._refresh_tracked_entities()
        payload = await build_state_sync_payload(self.hass, self._build_runtime_config())
        self._refresh_lock_devices(payload["data"]["devices"])
        await self._send_json(payload)

    async def _execute_service(self, message: dict) -> None:
        """Executes a service call received from the server."""
        service_data = message.get("data", message)
        request_id = service_data.get("request_id")

        if request_id:
            await execute_call_service_with_result(
                hass=self.hass,
                project_id=self._project_id,
                serial=self._serial,
                send_message=self._send_json,
                message=message,
            )
            return

        domain = service_data.get("domain")
        service = service_data.get("service")
        call_data = service_data.get("service_data", service_data.get("data", {}))

        if not domain or not service:
            _LOGGER.warning("%s call_service invalid: %s", LOG_PREFIX, message)
            return

        _LOGGER.info(
            "%s executing service: %s.%s with %s",
            LOG_PREFIX,
            domain,
            service,
            call_data,
        )

        try:
            await self.hass.services.async_call(
                domain,
                service,
                call_data,
                blocking=False,
            )
        except Exception as err:
            _LOGGER.error(
                "%s error executing service %s.%s: %s",
                LOG_PREFIX,
                domain,
                service,
                err,
            )

    def _refresh_lock_devices(self, devices: list[dict]) -> None:
        """Reloads the lock device map from the latest inventory snapshot."""
        self._lock_devices = build_lock_device_map(devices)

    def _get_lock_device_map(self) -> dict[str, dict]:
        """Returns the current lock device_id → lock_codes profile map."""
        return self._lock_devices

    async def _refresh_lock_devices_from_inventory(self) -> None:
        """Reloads lock metadata after registry changes without a full state_sync."""
        _areas, devices = await collect_inventory_with_lock_codes(self.hass)
        self._refresh_lock_devices(devices)

    def _subscribe_lock_notifications(self) -> None:
        """Subscribes to lock notification handling and lock-code commands."""
        if self._lock_notification_forwarder is not None:
            return

        self._lock_code_handler = LockCodeHandler(
            hass=self.hass,
            project_id=self._project_id,
            serial=self._serial,
            send_message=self._send_json,
            get_lock_device_map=self._get_lock_device_map,
        )
        self._lock_notification_forwarder = LockNotificationForwarder(
            hass=self.hass,
            project_id=self._project_id,
            serial=self._serial,
            send_message=self._send_json,
            get_lock_device_map=self._get_lock_device_map,
            identity_cache=self._lock_identity_cache,
        )
        self._lock_notification_forwarder.subscribe()

    def _unsubscribe_lock_notifications(self) -> None:
        """Unsubscribes from lock notification listeners."""
        if self._lock_notification_forwarder:
            self._lock_notification_forwarder.unsubscribe()
            self._lock_notification_forwarder = None

        self._lock_code_handler = None

    def _subscribe_state_changes(self) -> None:
        """Subscribes to HA state_changed events once the WS connection is open."""
        if self._state_unsub is not None:
            return

        async def _on_state_changed(event: Event) -> None:
            await self._queue_state_event(event)

        self._state_unsub = self.hass.bus.async_listen("state_changed", _on_state_changed)

    def _unsubscribe_state_changes(self) -> None:
        """Unsubscribes from HA state_changed events."""
        if self._state_unsub:
            self._state_unsub()
            self._state_unsub = None

    def _subscribe_registry_updates(self) -> None:
        """Forwards registry metadata changes and refreshes tracked entities."""
        if self._registry_notifier is not None:
            return

        self._registry_notifier = RegistryNotifier(
            hass=self.hass,
            project_id=self._project_id,
            serial=self._serial,
            send_message=self._send_json,
            get_known_device_ids=self._get_known_device_ids,
            schedule_tracked_entities_refresh=self._schedule_tracked_entities_refresh,
        )
        self._registry_notifier.subscribe()

    def _unsubscribe_registry_updates(self) -> None:
        """Unsubscribes from registry listeners and cancels pending notifications."""
        if self._registry_notifier:
            self._registry_notifier.unsubscribe()
            self._registry_notifier = None

        if self._registry_refresh_task:
            self._registry_refresh_task.cancel()
            self._registry_refresh_task = None

    def _get_known_device_ids(self) -> set[str]:
        """Returns device ids currently tracked for state_changed events."""
        return set(self._tracked_entities.values())

    async def _schedule_tracked_entities_refresh(self) -> None:
        """Debounces registry-driven refreshes after pairing new devices."""
        if self._registry_refresh_task:
            self._registry_refresh_task.cancel()

        self._registry_refresh_task = asyncio.create_task(
            self._refresh_tracked_entities_debounced()
        )

    async def _refresh_tracked_entities_debounced(self) -> None:
        """Reloads tracked entities after registry changes settle."""
        try:
            await asyncio.sleep(TRACKED_ENTITIES_REFRESH_DEBOUNCE_SECONDS)
            self._refresh_tracked_entities()
            await self._refresh_lock_devices_from_inventory()
        except asyncio.CancelledError:
            return
        finally:
            self._registry_refresh_task = None

    async def _queue_state_event(self, event: Event) -> None:
        """Queues a state change and debounces rapid updates for the same entity."""
        entity_id = event.data.get("entity_id")
        new_state = event.data.get("new_state")
        old_state = event.data.get("old_state")

        if not entity_id or entity_id not in self._tracked_entities:
            return

        device_id = self._tracked_entities[entity_id]
        domain = entity_id.split(".", 1)[0]
        old_state_value = old_state.state if old_state else None
        new_state_value = new_state.state if new_state else None
        old_attributes = dict(old_state.attributes) if old_state else {}
        new_attributes = dict(new_state.attributes) if new_state else {}
        incoming_changes = extract_meaningful_changes(
            old_attributes,
            new_attributes,
            old_state_value,
            new_state_value,
            old_state_last_changed=old_state.last_changed if old_state else None,
            new_state_last_changed=new_state.last_changed if new_state else None,
        )

        if not incoming_changes:
            _LOGGER.debug(
                "%s ignored state_changed for %s (no meaningful diff)",
                LOG_PREFIX,
                entity_id,
            )
            return

        pending_event = self._pending_events.get(entity_id)
        if pending_event is None:
            self._pending_events[entity_id] = build_state_changed_message(
                project_id=self._project_id,
                serial=self._serial,
                device_id=device_id,
                entity_id=entity_id,
                domain=domain,
                device_class=new_attributes.get("device_class"),
                old_state=old_state_value,
                new_state=new_state_value,
                changes=incoming_changes,
            )
        else:
            pending_data = pending_event["data"]
            pending_data["state"]["new"] = new_state_value
            pending_data["device_class"] = new_attributes.get("device_class")
            pending_data["changes"] = merge_changes(
                pending_data["changes"],
                incoming_changes,
            )

        await self._schedule_debounce_flush(entity_id)

    async def _schedule_debounce_flush(self, entity_id: str) -> None:
        """Schedules a debounced flush for a pending entity event."""
        existing_task = self._debounce_tasks.pop(entity_id, None)
        if existing_task:
            existing_task.cancel()

        self._debounce_tasks[entity_id] = asyncio.create_task(
            self._flush_entity_event(entity_id)
        )

    async def _flush_entity_event(self, entity_id: str) -> None:
        """Sends the merged state_changed message after the debounce window."""
        try:
            await asyncio.sleep(EVENT_DEBOUNCE_SECONDS)
            payload = self._pending_events.pop(entity_id, None)
            self._debounce_tasks.pop(entity_id, None)

            if not payload or not self._ws or self._ws.closed:
                return

            changes = payload["data"]["changes"]
            _LOGGER.info(
                "%s event [device: %s] %s | changes: %s",
                LOG_PREFIX,
                payload["data"]["device_id"],
                entity_id,
                list(changes.keys()),
            )
            await self._send_json(payload)
            await self._maybe_notify_lock_unlock(payload, entity_id)
        except asyncio.CancelledError:
            return

    async def _maybe_notify_lock_unlock(self, payload: dict, entity_id: str) -> None:
        """Publishes lock_notification when a tracked lock entity transitions to unlocked."""
        if self._lock_notification_forwarder is None:
            return

        payload_data = payload.get("data") or {}
        if payload_data.get("domain") != "lock":
            return

        state_transition = payload_data.get("state") or {}
        if state_transition.get("old") != "locked" or state_transition.get("new") != "unlocked":
            return

        await self._lock_notification_forwarder.notify_lock_unlocked(
            device_id=payload_data["device_id"],
            entity_id=entity_id,
        )

    async def _cancel_all_debounce_tasks(self) -> None:
        """Cancels all pending debounce tasks and clears queued events."""
        for task in self._debounce_tasks.values():
            task.cancel()

        if self._debounce_tasks:
            await asyncio.gather(*self._debounce_tasks.values(), return_exceptions=True)

        self._debounce_tasks.clear()
        self._pending_events.clear()
