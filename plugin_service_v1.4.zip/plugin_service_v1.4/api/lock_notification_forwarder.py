"""Forwards Z-Wave lock unlock events with user identification to the external server."""

import logging
from collections.abc import Awaitable, Callable

from homeassistant.core import Event, HomeAssistant

from ..const import LOG_PREFIX
from .lock_unlock_identity_cache import LockUnlockIdentityCache
from .lock_unlock_identity_resolver import resolve_lock_unlock_identity
from .messages import build_lock_notification_message
from ..registry.lock_user_mapper import resolve_code_slot_for_user
from .zwave_driver_log_listener import ZwaveDriverLogListener

_LOGGER = logging.getLogger(__name__)

ZWAVE_JS_NOTIFICATION_EVENT = "zwave_js_notification"
KEYPAD_UNLOCK_EVENT_LABEL = "keypad unlock operation"
LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION = "zwave_js_notification"
LOCK_NOTIFICATION_SOURCE_LOCK_STATE_CHANGED = "lock_state_changed"


class LockNotificationForwarder:
    """Publishes lock_notification messages when a tracked lock unlocks."""

    def __init__(
        self,
        hass: HomeAssistant,
        project_id: str,
        serial: str,
        send_message: Callable[[dict], Awaitable[None]],
        get_lock_device_map: Callable[[], dict[str, dict]],
        identity_cache: LockUnlockIdentityCache,
    ) -> None:
        self._hass = hass
        self._project_id = project_id
        self._serial = serial
        self._send_message = send_message
        self._get_lock_device_map = get_lock_device_map
        self._identity_cache = identity_cache
        self._notification_unsub = None
        self._driver_log_listener = ZwaveDriverLogListener(
            hass=hass,
            identity_cache=identity_cache,
            get_lock_device_map=get_lock_device_map,
        )

    def subscribe(self) -> None:
        """Subscribes to Z-Wave unlock identity sources."""
        if self._notification_unsub is not None:
            return

        async def _on_zwave_notification(event: Event) -> None:
            await self._handle_zwave_notification(event)

        self._notification_unsub = self._hass.bus.async_listen(
            ZWAVE_JS_NOTIFICATION_EVENT,
            _on_zwave_notification,
        )
        self._driver_log_listener.subscribe()

    def unsubscribe(self) -> None:
        """Unsubscribes from Z-Wave unlock identity listeners."""
        if self._notification_unsub:
            self._notification_unsub()
            self._notification_unsub = None

        self._driver_log_listener.unsubscribe()

    async def notify_lock_unlocked(self, device_id: str, entity_id: str) -> None:
        """Resolves unlock identity and publishes lock_notification to the server."""
        lock_profile = self._get_lock_device_map().get(device_id)
        if lock_profile is None:
            return

        unlock_identity = await resolve_lock_unlock_identity(
            self._hass,
            device_id,
            entity_id,
            self._identity_cache,
        )
        if unlock_identity is not None:
            code_slot = await resolve_code_slot_for_user(
                self._hass,
                entity_id,
                unlock_identity.user_id,
                lock_profile.get("api", "usercode"),
                device_id=device_id,
            )
            parameters = dict(unlock_identity.parameters or {})
            parameters.setdefault("userId", unlock_identity.user_id)
            await self._publish_notification(
                device_id=device_id,
                entity_id=entity_id,
                user_id=unlock_identity.user_id,
                code_slot=code_slot,
                event_label=unlock_identity.event_label,
                event_type=unlock_identity.event_type,
                source=unlock_identity.source,
                parameters=parameters,
            )
            return

        await self._publish_notification(
            device_id=device_id,
            entity_id=entity_id,
            user_id=None,
            code_slot=None,
            event_label=KEYPAD_UNLOCK_EVENT_LABEL,
            event_type=None,
            source=LOCK_NOTIFICATION_SOURCE_LOCK_STATE_CHANGED,
            parameters={},
        )

    async def _handle_zwave_notification(self, event: Event) -> None:
        """Caches keypad unlock notifications when zwave_js exposes userId."""
        event_data = event.data
        device_id = event_data.get("device_id")
        if not device_id:
            return

        lock_profile = self._get_lock_device_map().get(device_id)
        if lock_profile is None:
            return

        parameters = event_data.get("parameters") or {}
        user_id = parameters.get("userId")
        if user_id is None:
            return

        try:
            parsed_user_id = int(user_id)
        except (TypeError, ValueError):
            return

        from .lock_unlock_identity_cache import LockUnlockIdentity

        self._identity_cache.store(
            device_id,
            LockUnlockIdentity(
                user_id=parsed_user_id,
                source=LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION,
                event_label=event_data.get("event_label"),
                event_type=event_data.get("event"),
                parameters=parameters,
            ),
        )

        entity_id = lock_profile.get("entity_id")
        code_slot = await resolve_code_slot_for_user(
            self._hass,
            entity_id,
            parsed_user_id,
            lock_profile.get("api", "usercode"),
            device_id=device_id,
        )

        await self._publish_notification(
            device_id=device_id,
            entity_id=entity_id,
            user_id=parsed_user_id,
            code_slot=code_slot,
            event_label=event_data.get("event_label"),
            event_type=event_data.get("event"),
            source=LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION,
            parameters=parameters,
        )

    async def _publish_notification(
        self,
        *,
        device_id: str,
        entity_id: str | None,
        user_id: int | None,
        code_slot: int | None,
        event_label: str | None,
        event_type,
        source: str,
        parameters: dict,
    ) -> None:
        """Builds and sends a lock_notification envelope."""
        payload = build_lock_notification_message(
            project_id=self._project_id,
            serial=self._serial,
            device_id=device_id,
            entity_id=entity_id,
            event=str(event_type) if event_type is not None else None,
            event_label=event_label,
            notification_type=source,
            user_id=user_id,
            code_slot=code_slot,
            parameters=parameters,
            source=source,
        )
        _LOGGER.info(
            "%s lock_notification [device: %s | user_id: %s | code_slot: %s | source: %s]",
            LOG_PREFIX,
            device_id,
            user_id,
            code_slot,
            source,
        )
        await self._send_message(payload)
