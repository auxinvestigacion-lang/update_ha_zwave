"""Direct Z-Wave lock user-code operations not exposed as dedicated HA services."""

import logging

from homeassistant.core import HomeAssistant

from ..const import LOG_PREFIX, ZWAVE_JS_DOMAIN
from .service_executor import ServiceExecutionError, execute_ha_service

_LOGGER = logging.getLogger(__name__)

USER_CODE_COMMAND_CLASS = 99
SCHEDULE_ENTRY_LOCK_COMMAND_CLASS = 78
USER_CODE_STATUS_AVAILABLE = 0
USER_CODE_STATUS_ENABLED = 1
ZWAVE_JS_SERVICE_INVOKE_CC_API = "invoke_cc_api"


class LockAccessControlError(Exception):
    """Raised when a direct access-control operation fails."""


async def add_user_with_pin(
    hass: HomeAssistant,
    entity_id: str,
    user_id: int,
    usercode: str,
    *,
    user_name: str | None = None,
) -> None:
    """Creates a lock user and PIN in one User Code CC call when required by hardware."""
    invoke_data = {
        "entity_id": entity_id,
        "command_class": USER_CODE_COMMAND_CLASS,
        "method_name": "set",
        "parameters": [
            user_id,
            USER_CODE_STATUS_ENABLED,
            usercode,
            user_name or f"User {user_id}",
        ],
    }

    try:
        await execute_ha_service(
            hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_INVOKE_CC_API,
            service_data=invoke_data,
        )
    except ServiceExecutionError as err:
        raise LockAccessControlError(str(err)) from err

    _LOGGER.info(
        "%s programmed user code via User Code CC [entity: %s | user_id: %s]",
        LOG_PREFIX,
        entity_id,
        user_id,
    )


async def clear_user_code_slot(
    hass: HomeAssistant,
    entity_id: str,
    user_id: int,
) -> None:
    """Clears a User Code slot by marking it Available via User Code CC."""
    invoke_data = {
        "entity_id": entity_id,
        "command_class": USER_CODE_COMMAND_CLASS,
        "method_name": "set",
        "parameters": [user_id, USER_CODE_STATUS_AVAILABLE],
    }

    try:
        await execute_ha_service(
            hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_INVOKE_CC_API,
            service_data=invoke_data,
        )
    except ServiceExecutionError as err:
        raise LockAccessControlError(
            f"clear user code slot {user_id} on {entity_id}: {err}"
        ) from err

    _LOGGER.info(
        "%s cleared User Code slot [entity: %s | user_id: %s]",
        LOG_PREFIX,
        entity_id,
        user_id,
    )


async def set_user_code_schedule_enabled(
    hass: HomeAssistant,
    entity_id: str,
    user_id: int,
    *,
    is_enabled: bool,
) -> None:
    """Enables or disables Schedule Entry Lock for a User Code slot."""
    invoke_data = {
        "entity_id": entity_id,
        "command_class": SCHEDULE_ENTRY_LOCK_COMMAND_CLASS,
        "method_name": "setEnabled",
        "parameters": [is_enabled, user_id],
    }

    try:
        await execute_ha_service(
            hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_INVOKE_CC_API,
            service_data=invoke_data,
        )
    except ServiceExecutionError as err:
        action_name = "enable" if is_enabled else "disable"
        raise LockAccessControlError(
            f"{action_name} schedule for user {user_id} on {entity_id}: {err}"
        ) from err

    _LOGGER.info(
        "%s %s Schedule Entry Lock [entity: %s | user_id: %s]",
        LOG_PREFIX,
        "enabled" if is_enabled else "disabled",
        entity_id,
        user_id,
    )


async def enable_user_code_schedule(
    hass: HomeAssistant,
    entity_id: str,
    user_id: int,
) -> None:
    """Enables Schedule Entry Lock for a user so a programmed PIN can unlock."""
    await set_user_code_schedule_enabled(
        hass,
        entity_id,
        user_id,
        is_enabled=True,
    )


async def disable_user_code_schedule(
    hass: HomeAssistant,
    entity_id: str,
    user_id: int,
) -> None:
    """Disables Schedule Entry Lock for a user after clearing a PIN."""
    await set_user_code_schedule_enabled(
        hass,
        entity_id,
        user_id,
        is_enabled=False,
    )
