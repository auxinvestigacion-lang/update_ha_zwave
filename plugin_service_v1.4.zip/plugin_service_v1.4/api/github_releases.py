"""GitHub Releases client for published Plugin Service versions."""

from collections.abc import Callable
from dataclasses import dataclass

from aiohttp import ClientError, ClientResponse, ClientSession, ClientTimeout
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from ..const import (
    GITHUB_API_URL,
    GITHUB_API_VERSION,
    GITHUB_DOWNLOAD_CHUNK_SIZE,
    GITHUB_DOWNLOAD_TIMEOUT_SECONDS,
    GITHUB_OWNER,
    GITHUB_RELEASES_FETCH_PAGE_SIZE,
    GITHUB_RELEASES_FETCH_TIMEOUT_SECONDS,
    GITHUB_RELEASES_LIMIT,
    GITHUB_REPO,
    GITHUB_TOKEN,
    HTTP_REDIRECT_STATUSES,
    INTEGRATION_NAME,
    PROGRESS_DOWNLOAD_MAX,
    PROGRESS_DOWNLOAD_MIN,
)


class GithubReleasesError(Exception):
    """Raised when GitHub Releases cannot be fetched or downloaded."""


@dataclass(frozen=True)
class GithubRelease:
    """A published GitHub release that can be installed."""

    tag_name: str
    name: str
    body: str
    html_url: str
    zipball_url: str


def _build_api_headers() -> dict[str, str]:
    """Builds GitHub REST headers. Never log the returned Authorization value."""
    return {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "X-GitHub-Api-Version": GITHUB_API_VERSION,
        "User-Agent": INTEGRATION_NAME,
    }


def _build_cdn_headers() -> dict[str, str]:
    """Builds headers for the GitHub archive CDN. Do not send the PAT here."""
    return {
        "Accept": "*/*",
        "User-Agent": INTEGRATION_NAME,
    }


def _parse_release(payload: dict) -> GithubRelease | None:
    """Returns a release when it is published and has the required fields."""
    tag_name = payload.get("tag_name")
    zipball_url = payload.get("zipball_url")
    html_url = payload.get("html_url")
    if payload.get("draft") or payload.get("prerelease"):
        return None
    if not tag_name or not zipball_url or not html_url:
        return None
    return GithubRelease(
        tag_name=str(tag_name),
        name=str(payload.get("name") or tag_name),
        body=str(payload.get("body") or ""),
        html_url=str(html_url),
        zipball_url=str(zipball_url),
    )


async def fetch_published_releases(hass: HomeAssistant) -> list[GithubRelease]:
    """Fetches up to three published releases, newest first."""
    if not GITHUB_TOKEN:
        raise GithubReleasesError("fetch_published_releases: GitHub token is missing")

    session = async_get_clientsession(hass)
    url = f"{GITHUB_API_URL}/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases"
    timeout = ClientTimeout(total=GITHUB_RELEASES_FETCH_TIMEOUT_SECONDS)

    try:
        async with session.get(
            url,
            headers=_build_api_headers(),
            params={"per_page": GITHUB_RELEASES_FETCH_PAGE_SIZE},
            timeout=timeout,
        ) as response:
            if response.status >= 400:
                raise GithubReleasesError(
                    f"fetch_published_releases status={response.status} "
                    f"repo={GITHUB_OWNER}/{GITHUB_REPO}"
                )
            payload = await response.json()
    except ClientError as err:
        raise GithubReleasesError(f"fetch_published_releases: {err}") from err

    if not isinstance(payload, list):
        raise GithubReleasesError("fetch_published_releases: unexpected GitHub payload")

    releases: list[GithubRelease] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        release = _parse_release(item)
        if release:
            releases.append(release)
        if len(releases) >= GITHUB_RELEASES_LIMIT:
            break
    return releases


async def download_release_zipball(
    hass: HomeAssistant,
    zipball_url: str,
    on_progress: Callable[[int], None],
) -> bytes:
    """Downloads a release zipball via GitHub's 302 to the archive CDN."""
    session = async_get_clientsession(hass)
    timeout = ClientTimeout(total=GITHUB_DOWNLOAD_TIMEOUT_SECONDS)
    try:
        return await _download_zipball_from_github(
            session, zipball_url, timeout, on_progress
        )
    except ClientError as err:
        raise GithubReleasesError(f"download_release_zipball: {err}") from err


async def _download_zipball_from_github(
    session: ClientSession,
    zipball_url: str,
    timeout: ClientTimeout,
    on_progress: Callable[[int], None],
) -> bytes:
    """Resolves the zipball API URL, then downloads from the CDN without the PAT."""
    redirect_url = None
    async with session.get(
        zipball_url,
        headers=_build_api_headers(),
        timeout=timeout,
        allow_redirects=False,
    ) as response:
        if response.status in HTTP_REDIRECT_STATUSES:
            redirect_url = response.headers.get("Location")
            if not redirect_url:
                raise GithubReleasesError("download_release_zipball: missing redirect")
        elif response.status >= 400:
            raise GithubReleasesError(
                f"download_release_zipball status={response.status}"
            )
        else:
            return await _read_zip_chunks(response, on_progress)
    return await _download_binary(
        session, redirect_url, timeout, on_progress, _build_cdn_headers()
    )


async def _download_binary(
    session: ClientSession,
    url: str,
    timeout: ClientTimeout,
    on_progress: Callable[[int], None],
    headers: dict[str, str],
) -> bytes:
    """Downloads a binary URL and reports progress."""
    async with session.get(
        url,
        headers=headers,
        timeout=timeout,
        allow_redirects=True,
    ) as response:
        if response.status >= 400:
            raise GithubReleasesError(
                f"download_release_zipball status={response.status}"
            )
        return await _read_zip_chunks(response, on_progress)


async def _read_zip_chunks(
    response: ClientResponse, on_progress: Callable[[int], None]
) -> bytes:
    """Reads the response body in chunks and reports download progress."""
    chunks: list[bytes] = []
    downloaded = 0
    total_size = int(response.headers.get("Content-Length") or 0)
    async for chunk in response.content.iter_chunked(GITHUB_DOWNLOAD_CHUNK_SIZE):
        chunks.append(chunk)
        downloaded += len(chunk)
        on_progress(_download_percentage(downloaded, total_size))
    return b"".join(chunks)


def _download_percentage(downloaded: int, total_size: int) -> int:
    """Maps downloaded bytes onto the install progress window."""
    if total_size <= 0:
        return PROGRESS_DOWNLOAD_MIN
    ratio = min(downloaded / total_size, 1.0)
    span = PROGRESS_DOWNLOAD_MAX - PROGRESS_DOWNLOAD_MIN
    return PROGRESS_DOWNLOAD_MIN + int(ratio * span)
