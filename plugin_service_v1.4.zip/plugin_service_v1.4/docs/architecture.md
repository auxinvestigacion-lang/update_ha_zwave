# Arquitectura — Plugin Service

## Visión general

Plugin Service actúa como **puente bidireccional** entre Home Assistant y un servidor remoto:

```
┌─────────────────┐         REST (register)         ┌─────────────────┐
│                 │ ──────────────────────────────► │                 │
│  Home Assistant │                                 │  Servidor remoto│
│                 │ ◄──────── WebSocket ──────────► │                 │
│ Plugin Service  │   auth, state_sync,             │   API + WS      │
│                 │   state_changed, call_service   │                 │
└─────────────────┘                                 └─────────────────┘
```

## Capas

### Root — Entry points de Home Assistant

Home Assistant exige ciertos archivos en la raíz de la integración. No mueven lógica de negocio.

| Archivo | Responsabilidad |
|---|---|
| `__init__.py` | Setup/unload de la integración; delega a `core/` |
| `manifest.json` | Metadatos, dependencias, versión |
| `config_flow.py` | Flujo de configuración UI |
| `const.py` | Constantes globales, URLs, tipos de mensaje |
| `button.py` | Entry point de la platform `button` |
| `strings.json` | Textos del config flow |

### `api/` — Comunicación externa

Todo lo que habla con el servidor remoto.

| Módulo | Responsabilidad |
|---|---|
| `messages.py` | Envelope estándar, builders de mensajes, diff de cambios |
| `onboarding.py` | POST de registro al endpoint REST |
| `websocket_client.py` | Conexión persistente, auth, eventos, call_service |

**Depende de:** `registry/` (para saber qué entidades trackear), `const.py`

### `registry/` — Datos de Home Assistant

Lee los registros oficiales de HA y aplica reglas de filtrado.

| Módulo | Responsabilidad |
|---|---|
| `device_filter.py` | Qué dispositivos/entidades son accionables vs excluidos |
| `device_enrichment.py` | Metadatos del dispositivo (manufacturer, model, availability) |
| `standalone_filter.py` | Reglas para entidades sin device_id (automation, script, helpers, virtuales) |
| `standalone_collector.py` | Recolecta plugins agrupados y dispositivos virtuales como lógicos |
| `virtual_collector.py` | Recolecta helpers template como dispositivos virtuales |
| `data_collector.py` | Construye payload de registro y mapa de entidades trackeadas |
| `zwave_readiness.py` | Espera a que zwave_js tenga entities/estados listos antes de sync |

**Depende de:** `api/messages.py` (para el envelope de registro), `const.py`

**APIs HA usadas:**
- `area_registry.async_list_areas()`
- `device_registry.devices`
- `entity_registry.async_entries_for_device()`

### `entity/` — Entidades del plugin

Entidades que Plugin Service expone dentro de Home Assistant.

| Módulo | Responsabilidad |
|---|---|
| `onboarding_button.py` | Botón "Synchronize devices" para re-registro manual |

**Depende de:** `core/entry_manager.py`, `api/onboarding.py`

### `core/` — Orquestación interna

Coordinación del ciclo de vida sin depender de plataformas HA específicas.

| Módulo | Responsabilidad |
|---|---|
| `entry_manager.py` | Config de entry, registro, start/stop del WebSocket |

**Depende de:** `api/onboarding.py`, `api/websocket_client.py`, `const.py`

## Flujo de datos

### Arranque (async_setup_entry)

```
__init__.py
  └─► core/entry_manager.build_entry_config()
  └─► button.py → entity/onboarding_button.OnboardingButton
  └─► (background task) core/entry_manager.register_and_start_client()
        ├─► registry/zwave_readiness.wait_for_zwave_inventory_ready()
        ├─► api/onboarding.run_onboarding()
        │     └─► registry/data_collector.build_registration_payload()
        │           └─► api/messages.build_register_message()
        └─► api/websocket_client.WSClient.start()
              └─► registry/data_collector.build_tracked_entity_map()
              └─► (on auth_ok) wait_for_zwave_inventory_ready()
                    └─► registry/data_collector.build_state_sync_payload()
```

`register` y `state_sync` esperan a que Z-Wave JS tenga el driver conectado y las
entidades presentes en el state machine (timeout 120s). Así se evita clasificar
motion sensors como switch cuando el nodo aún no restauró `device_class`.

Además, `device_class` usa fallback al entity registry (`device_class` /
`original_device_class`) si el state vivo llega vacío.

### Sincronización de estados (auth_ok → state_sync)

```
WebSocket auth → servidor responde auth_ok
  └─► api/websocket_client._send_state_snapshot()
        ├─► registry/zwave_readiness.wait_for_zwave_inventory_ready()
        └─► registry/data_collector.build_state_sync_payload()
              └─► api/messages.build_state_sync_message()
```

Se envía el inventario completo con estados actuales. El servidor actualiza sin requerir un nuevo POST REST en cada arranque.

### Cambio de estado (HA → Servidor)

```
HA event bus (state_changed)
  └─► api/websocket_client._queue_state_event()
        ├─► api/messages.extract_meaningful_changes()
        ├─► debounce (0.5s por entity_id)
        └─► api/messages.build_state_changed_message() → WebSocket
```

### Cambio de inventario (HA → Servidor)

```
HA event bus (device_registry_updated | entity_registry_updated | area_registry_updated)
  └─► api/registry_notifier.RegistryNotifier
        ├─► registry/registry_event_filter.py (solo dispositivos actionable)
        ├─► registry/registry_change_normalizer.py ({ old, new } para device/entity)
        ├─► debounce (2s por device_id / area_id)
        └─► device_removed | device_updated | area_updated | area_removed → WebSocket
```

`area_updated` lee `area_id` + `name` del area registry de HA al recibir el evento (HA no envía `changes` ni valor anterior).

Los `create` se ignoran; las altas las cubre `register` (REST) o `state_sync`.

### Comando (Servidor → HA)

```
WebSocket (call_service)
  └─► api/websocket_client._execute_service()
        └─► hass.services.async_call(domain, service, data)
              └─► HA event bus → state_changed → WebSocket (confirmación)
```

## Reglas de filtrado

### Dispositivos físicos (Z-Wave, etc.)

Definidas en `registry/device_filter.py`:

| Regla | Efecto |
|---|---|
| `is_integration_device()` | Excluye el propio dispositivo Plugin Service |
| `entry_type == "service"` | Excluye Sun, Backup, etc. |
| `EXCLUDED_DEVICE_PLATFORMS` | Excluye sun, backup, homeassistant, hassio, plugin_service |
| `entity_category != null` | Excluye diagnostic/config del tracking WebSocket (salvo medición y alertas de calor) |
| `_is_zwave_controller()` | Excluye controladores USB Z-Wave |
| `switch` / `cover` / `button` con `entity_category: config` | **Incluidos** como entidades de control (cortinas Z-Wave) |
| Sensores de medición (`power` / `energy` / `voltage` / `current` / `temperature`) y alertas (`problem` / `heat` / `cold` / `safety`), incluso `diagnostic` | **Incluidos** — emiten eventos WS (switches con medidor, p. ej. Heavy Duty) |
| Sufijos `_ping`, `_identify`, `_firmware`, `_estado_del_nodo` | Excluidos del tracking WebSocket |

### Entidades standalone (plugins, helpers y dispositivos virtuales)

Definidas en `registry/standalone_filter.py`, `registry/plugin_family.py`, `registry/plugin_grouper.py` y `registry/virtual_collector.py`.

Hay **dos familias lógicas**. El resto de automatizaciones, scripts, scenes e `input_*` huérfanos **no aparece** en el registro ni emite eventos WebSocket.

#### Qué entra al registro

| Tipo | Criterio | Ejemplo |
|---|---|---|
| Dispositivo físico | Pasa filtros de `device_filter.py` | `climate.aire`, `lock.cerradura` |
| Plugin agrupado | Familia de automatizaciones plugin + helpers `input_*` | `logical:plugin:bp_plugin_hotel_v1_3_2_8`, `logical:plugin:plugin_motel_main` |
| Dispositivo virtual | Helper `platform: template` con área, fuera de plugins | `logical:binary_sensor.sensor_mov_virtual` |

#### Cómo se detecta un plugin blueprint

Una automatización standalone se considera plugin si cumple **alguna** de estas condiciones (`is_plugin_automation`):

| Criterio | Ejemplo |
|---|---|
| `entity_id` contiene `bp_plugin` | `automation.bp_plugin_hotel_v1_3_2_8` |
| `entity_id` contiene `plugin_` | `automation.plugin_motel_main` |
| Nombre contiene `"plugin"` (case insensitive) | `"Bp-Plugin Hotel v1.3.2.8"` |

#### Familias y roles (ocupación vs motel)

Las automatizaciones se agrupan por **familia** (`plugin_family.py`), no una a una:

| Convención `entity_id` | Rol | ¿Crea device? |
|---|---|---|
| `plugin_<familia>[_N]_main` o sin sufijo de satélite | Primario | Sí — ancla del grupo |
| `plugin_<familia>[_N]_ext` / `_semaforo` | Satélite | No — se fusiona al primario |

Ejemplos:

| Escenario | Automatizaciones | Device lógico | `plugin_family` |
|---|---|---|---|
| Ocupación | `bp_plugin_hotel_v1_3_2_8` | `logical:plugin:bp_plugin_hotel_v1_3_2_8` | `occupancy` |
| Un motel | `plugin_motel_main` + `_ext` + `_semaforo` | `logical:plugin:plugin_motel_main` | `motel` |
| Dos moteles | `plugin_motel_1_*` y `plugin_motel_2_*` | Dos devices (`…_1_main`, `…_2_main`) | `motel` |

Helpers (`input_select.modo_motel`, etc.) se asignan por referencias HA, área (si hay una sola familia en el área) o coincidencia con la clave de familia.

#### Dispositivos virtuales (helpers template)

Un helper de tipo **Template** (p. ej. un `binary_sensor` de movimiento virtual) **no es un plugin**. Se registra como dispositivo lógico propio:

| Criterio | Efecto |
|---|---|
| `platform == "template"` | Distingue el helper virtual de `input_*` de ocupación/motel |
| Dominio en `VIRTUAL_DEVICE_DOMAINS` (`binary_sensor`, `sensor`, `switch`, …) | Solo entidades que representan un dispositivo |
| Área en la entidad o en el device template | Misma regla que el hardware: sin área no se registra |
| Sin `device_id`, o device solo-template | Camino virtual (`device_kind: "virtual"`) |
| Template colgado de un dispositivo físico accionable | Se queda en el hardware; no se duplica como virtual |

```json
{
  "id": "logical:binary_sensor.sensor_mov_virtual",
  "source": "standalone",
  "device_kind": "virtual",
  "primary_domain": "binary_sensor"
}
```

Los `state_changed` usan ese `device_id`:

```json
{
  "type": "state_changed",
  "data": {
    "device_id": "logical:binary_sensor.sensor_mov_virtual",
    "entity_id": "binary_sensor.sensor_mov_virtual",
    "changes": { "state": { "old": "off", "new": "on" } }
  }
}
```

Los devices de HA que solo tienen entidades `template` se excluyen del inventario físico para no enviarlos dos veces ni clasificarlos como hardware.

Un rename del helper se publica como `device_updated` **a nivel dispositivo** (sin `entity_id`), con `changes.name`. HA suele cambiar `original_name` o el nombre del device template; ambos se resuelven al mismo `name` del inventario.

```json
{
  "type": "device_updated",
  "data": {
    "device_id": "logical:binary_sensor.sensor_mov_virtual",
    "changes": {
      "name": { "old": "Sensor mov virtual", "new": "Movimiento suite" }
    }
  }
}
```

#### Qué se excluye explícitamente

| Entidad | Motivo |
|---|---|
| Automatizaciones nuevas sin marcador plugin | No son parte de un plugin blueprint |
| Scripts y scenes standalone | Fuera de alcance del bridge |
| Helpers `input_*` huérfanos (sin plugin detectado) | Evita ruido en el registro |
| Automatizaciones de sistema HA | Prefijos `automation.homeassistant_`, `script.homeassistant_` |
| Entidades con `device_id` en un dispositivo físico accionable | Ya van agrupadas como dispositivo físico |
| Entidades `diagnostic` / `config` | No emiten `state_changed` (excepto sensores de medición y alertas de calor) |

#### Identificadores del plugin agrupado

```json
{
  "id": "logical:plugin:plugin_motel_main",
  "source": "standalone",
  "device_kind": "plugin",
  "plugin_family": "motel",
  "primary_domain": "automation"
}
```

Las entidades del grupo (primario, satélites y helpers) comparten el mismo `device_id` en eventos WebSocket:

```json
{
  "type": "state_changed",
  "data": {
    "device_id": "logical:plugin:plugin_motel_main",
    "entity_id": "input_select.modo_motel",
    "changes": { "state": { "old": "Libre", "new": "Ocupado" } }
  }
}
```

#### Añadir otro plugin en el futuro

- **Ocupación:** una automatización `bp_plugin_*` / `plugin_occupancy_*` → un device.
- **Motel:** usar `plugin_motel[_N]_{main|ext|semaforo}`; solo `_main` genera el device.
- Con varias familias en el mismo área, nombrar helpers con el stem de la familia (`modo_motel_1`, `modo_motel_2`) para el matching por prefijo.

#### Serialización del payload

Los `attributes` de entidades se sanitizan con el encoder JSON de Home Assistant (`registry/payload_serialization.py`) para evitar fallos con `datetime` u otros tipos no serializables.

## Almacenamiento en runtime

```python
hass.data["plugin_service"][entry_id] = {
    "plugin_config": { project_id, mac, api_key },
    "plugin_client": WSClient instance,
}
```

## Disponibilidad (`is_reachable`)

Definida en `registry/device_enrichment.py`:

| Situación | `is_reachable` | `status` |
|---|---|---|
| Dispositivo deshabilitado en HA | `false` | `disabled` |
| Nodo Z-Wave `alive` / `awake` / `asleep` | `true` | `online` / `sleeping` |
| Nodo Z-Wave `dead` / `failed` | `false` | `offline` |
| Arranque: entidades aún `unknown` / `unavailable` | `true` | `unknown` |
| Sensor de nodo sin cargar aún | usa fallback por entidades | no asume offline |

El `state_sync` post-`auth_ok` y el `register` REST esperan a que Z-Wave JS esté listo
(`registry/zwave_readiness.py`). Si el timeout expira, el sync continúa con un warning
y `device_class` puede recuperarse desde el entity registry.

## Decisiones de diseño

| Decisión | Razón |
|---|---|
| URLs hardcodeadas en `const.py` | Despliegue controlado; evita config en `configuration.yaml` |
| Envelope de mensajes unificado | Consistencia entre REST y WebSocket |
| Debounce de eventos | HA emite cascadas de state_changed por un solo cambio de usuario |
| Registro antes de WebSocket | El servidor necesita inventario antes de recibir eventos |
| `button.py` en root | Requisito de Home Assistant para platforms |
| Sin `utils.py` | Un concepto por archivo, responsabilidades claras |

## Qué agregar y dónde

| Necesidad | Ubicación |
|---|---|
| Nuevo tipo de mensaje | `api/messages.py` + `const.py` |
| Cambios de metadata de inventario | `api/registry_notifier.py` + `registry/registry_event_filter.py` |
| Nuevo filtro de dispositivo | `registry/device_filter.py` |
| Nuevo dispositivo virtual / helper template | `registry/standalone_filter.py` + `registry/virtual_collector.py` |
| Nueva entidad HA (sensor, etc.) | `entity/` + platform en root |
| Nuevo endpoint REST | `api/` (nuevo módulo o extender `onboarding.py`) |
| Lógica de setup/unload | `core/entry_manager.py` |
| Constante global | `const.py` |
| Documentación de protocolo | `docs/` |

## Limitaciones conocidas

- Sin respuesta `call_service_result` al servidor
- Sin validación de entidades controlables al recibir comandos
- Sin autenticación de comandos WebSocket
- Sin tests automatizados (pendiente)
