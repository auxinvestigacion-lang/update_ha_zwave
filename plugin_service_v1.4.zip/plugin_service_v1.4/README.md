# Plugin Service

Integración personalizada de Home Assistant que conecta una instancia local con un servidor remoto. Registra áreas, dispositivos y entidades, transmite cambios de estado en tiempo real y ejecuta comandos recibidos desde el servidor.

## Instalación

Copia esta carpeta como `plugin_service` dentro de `custom_components/` de Home Assistant:

```
config/
└── custom_components/
    └── plugin_service/     ← contenido de este repositorio
        ├── __init__.py
        ├── manifest.json
        ├── api/
        ├── registry/
        └── ...
```

Reinicia Home Assistant y agrega la integración desde **Configuración → Dispositivos y servicios → Agregar integración → Plugin Service**.

> **Migración desde `ws_bridge`:** elimina la integración antigua, renombra la carpeta a `plugin_service`, reinicia HA y vuelve a configurar la integración.

## Configuración

### Desde la UI (config flow)

| Campo | Descripción |
|---|---|
| Project ID | Identificador del proyecto en el servidor |
| MAC / Serial | Identificador único del gateway |
| API Key | Clave de autenticación para el servidor |

### Desde código (`const.py`)

Las URLs del servidor se configuran directamente en el código:

```python
SERVER_URL = "http://192.168.1.36:3301"
WS_URL = "ws://192.168.1.36:7827"
```

## Flujo de operación

1. **Espera Z-Wave:** al iniciar, el plugin espera a que zwave_js tenga driver, nodos entrevistados y entidades en el state machine (máx. 120s).
2. **Registro (REST):** envía áreas, dispositivos y entidades al servidor.
3. **WebSocket:** tras registro exitoso, mantiene conexión persistente con el servidor.
4. **Sincronización (`state_sync`):** tras `auth_ok`, vuelve a comprobar Z-Wave y envía un snapshot con los estados actuales.
5. **Eventos:** publica `state_changed` cuando cambian dispositivos accionables, plugins blueprint o dispositivos virtuales.
6. **Inventario (WebSocket):** publica `device_updated`, `device_removed`, `area_updated` y `area_removed` cuando cambia metadata en HA (sin cache en memoria para áreas).
7. **Comandos:** recibe `call_service` del servidor y los ejecuta en Home Assistant.

### Filtrado

- **Dispositivos físicos:** excluye Sun, Backup, Plugin Service propio, controlador Z-Wave USB y entidades diagnostic/config del WebSocket.
- **Plugins:** registra **familias de plugin blueprint** (ocupación `bp_plugin_*`, motel `plugin_motel[_N]_{main|ext|semaforo}` + helpers `input_*`). Las satélites motel se agrupan bajo `_main`.
- **Dispositivos virtuales:** registra helpers `platform: template` (p. ej. `binary_sensor.sensor_mov_virtual`) como dispositivos lógicos propios (`device_kind: "virtual"`). No se mezclan con ocupación/motel.
- **Excluido:** otras automatizaciones, scripts, scenes e `input_*` sin plugin.

Detalle completo en [docs/architecture.md](docs/architecture.md#reglas-de-filtrado).

## Estructura del proyecto

```
plugin_service/
├── __init__.py              # Entry point de la integración HA
├── manifest.json            # Metadatos requeridos por HA
├── config_flow.py           # Configuración desde la UI
├── const.py                 # Constantes globales
├── button.py                # Platform entry (requerido por HA en root)
├── strings.json             # Textos del config flow
├── translations/            # Traducciones (en, es)
│
├── api/                     # Comunicación con el servidor externo
│   ├── messages.py          # Envelope y builders de mensajes
│   ├── onboarding.py        # Registro REST
│   ├── registry_notifier.py # Cambios de inventario (device/area)
│   └── websocket_client.py  # Cliente WebSocket
│
├── registry/                # Lectura de registros de Home Assistant
│   ├── data_collector.py    # Recolección de áreas/dispositivos/entidades
│   └── device_filter.py     # Filtrado de dispositivos accionables
│
├── entity/                  # Entidades expuestas por la integración
│   └── onboarding_button.py # Botón "Synchronize devices"
│
├── core/                    # Orquestación interna
│   └── entry_manager.py     # Ciclo de vida de config entries
│
└── docs/                    # Documentación
    ├── architecture.md      # Arquitectura y responsabilidades
    └── command-execution.md   # Protocolo de comandos
```

Ver [docs/architecture.md](docs/architecture.md) para detalle de cada módulo.

## Documentación

| Documento | Contenido |
|---|---|
| [architecture.md](docs/architecture.md) | Arquitectura, capas y responsabilidades |
| [command-execution.md](docs/command-execution.md) | Cómo enviar comandos a dispositivos |

## Desarrollo

### Requisitos

- Home Assistant 2024.x+
- Python 3.11+
- Dependencia: `aiohttp>=3.8.0` (declarada en `manifest.json`)

### Convenciones

- Archivos y carpetas: `kebab-case` o `snake_case` según contexto HA
- Constantes globales: `UPPER_SNAKE_CASE`
- Funciones: `snake_case` con verbo descriptivo
- Un concepto por archivo — sin módulos genéricos tipo `utils.py`
- Comentarios de funciones en inglés

### Despliegue en HA

Tras modificar el código, recarga la integración:

**Configuración → Dispositivos y servicios → Plugin Service → Recargar**

## Protocolo de mensajes

Todos los mensajes usan un envelope común:

```json
{
  "type": "register | auth | state_sync | state_changed | device_removed | device_updated | area_updated | area_removed | call_service",
  "version": 1,
  "project_id": "...",
  "serial": "...",
  "timestamp": "ISO-8601",
  "data": { }
}
```

## Licencia

Pendiente de definir.
