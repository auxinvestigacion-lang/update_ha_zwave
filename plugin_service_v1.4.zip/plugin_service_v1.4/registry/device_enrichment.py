"""Enriches device metadata and resolves reachability from Home Assistant registries."""

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from .device_filter import _is_user_facing_entity
from .payload_serialization import serialize_disabled_by

# HA bootstrap states that do not prove a device is offline.
BOOTSTRAP_ENTITY_STATES = frozenset({"unknown", "unavailable"})

# Z-Wave node status values considered reachable (device is on the network).
ZWAVE_NODE_STATUS_REACHABLE = frozenset({"alive", "awake", "asleep"})

# Z-Wave node status values indicating the device is not reachable.
ZWAVE_NODE_STATUS_UNREACHABLE = frozenset({"dead", "failed", "unknown"})

# Entity ID suffix used by zwave_js for the node status diagnostic sensor.
ZWAVE_NODE_STATUS_ENTITY_SUFFIX = "_estado_del_nodo"

# Translation key used by zwave_js for the node status sensor.
ZWAVE_NODE_STATUS_TRANSLATION_KEY = "node_status"


def resolve_manufacturer(device) -> str | None:
    """Returns the best available manufacturer for a device."""
    return device.manufacturer or None


def resolve_model(
    device,
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
) -> str | None:
    """Returns the best available model identifier for a device."""
    if device.model:
        return device.model

    if device.model_id:
        return device.model_id

    if device.sw_version:
        return device.sw_version

    return _get_firmware_version(hass, entity_entries)


def build_device_metadata(
    device,
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
) -> dict:
    """Builds supplementary metadata fields from the device registry entry."""
    return {
        "manufacturer": resolve_manufacturer(device),
        "model": resolve_model(device, hass, entity_entries),
        "model_id": device.model_id,
        "hw_version": device.hw_version,
        "sw_version": device.sw_version,
        "serial_number": device.serial_number,
        "entry_type": device.entry_type.value if device.entry_type else None,
        "labels": sorted(device.labels),
        "disabled_by": serialize_disabled_by(device.disabled_by),
    }


def build_device_availability(
    hass: HomeAssistant,
    device,
    entity_entries: list[er.RegistryEntry],
) -> dict:
    """Derives device reachability from node status and entity states.

    Home Assistant does not expose a single "device online" flag. For Z-Wave
    devices, the node status diagnostic sensor is the authoritative source.
    """
    if device.disabled_by is not None:
        return {
            "status": "disabled",
            "is_reachable": False,
            "node_status": None,
            "primary_entities_unavailable": _count_unavailable_primary_entities(
                hass, entity_entries
            ),
        }

    node_status = _get_zwave_node_status(hass, entity_entries)
    if node_status is not None:
        return _build_availability_from_node_status(
            node_status,
            entity_entries,
            hass,
        )

    return _build_fallback_availability(hass, entity_entries, None)


def _build_availability_from_node_status(
    node_status: str,
    entity_entries: list[er.RegistryEntry],
    hass: HomeAssistant,
) -> dict:
    """Maps a Z-Wave node status value to a normalized availability object."""
    unavailable_count = _count_unavailable_primary_entities(hass, entity_entries)

    if node_status in ZWAVE_NODE_STATUS_REACHABLE:
        status = "sleeping" if node_status == "asleep" else "online"
        return {
            "status": status,
            "is_reachable": True,
            "node_status": node_status,
            "primary_entities_unavailable": unavailable_count,
        }

    if node_status in ZWAVE_NODE_STATUS_UNREACHABLE:
        return {
            "status": "offline",
            "is_reachable": False,
            "node_status": node_status,
            "primary_entities_unavailable": unavailable_count,
        }

    return _build_fallback_availability(hass, entity_entries, node_status)


def _get_firmware_version(
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
) -> str | None:
    """Reads installed firmware version from an update entity when model is missing."""
    for entry in entity_entries:
        if entry.domain != "update" or entry.disabled_by is not None:
            continue

        state = hass.states.get(entry.entity_id)
        if state is None:
            continue

        installed_version = state.attributes.get("installed_version")
        if installed_version:
            return str(installed_version)

    return None


def _get_zwave_node_status(
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
) -> str | None:
    """Finds the Z-Wave node status sensor state for a device, if present."""
    for entry in entity_entries:
        if entry.disabled_by is not None:
            continue

        if not is_zwave_node_status_entity(entry):
            continue

        state = hass.states.get(entry.entity_id)
        if state is None or state.state in BOOTSTRAP_ENTITY_STATES:
            return None

        return state.state.lower()

    return None


def is_zwave_node_status_entity(entry: er.RegistryEntry) -> bool:
    """Returns True when the entity is the Z-Wave node status diagnostic sensor."""
    if entry.platform != "zwave_js":
        return False

    if entry.translation_key == ZWAVE_NODE_STATUS_TRANSLATION_KEY:
        return True

    return entry.entity_id.endswith(ZWAVE_NODE_STATUS_ENTITY_SUFFIX)


def _count_primary_entities(entity_entries: list[er.RegistryEntry]) -> int:
    """Counts enabled user-facing entities for a device."""
    return sum(
        1 for entry in entity_entries if _is_user_facing_entity(entry)
    )


def _count_unavailable_primary_entities(
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
) -> int:
    """Counts user-facing entities currently in unavailable state."""
    unavailable_count = 0

    for entry in entity_entries:
        if not _is_user_facing_entity(entry):
            continue

        state = hass.states.get(entry.entity_id)
        if state is None or state.state in BOOTSTRAP_ENTITY_STATES:
            unavailable_count += 1

    return unavailable_count


def _is_bootstrapping_availability(
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
) -> bool:
    """Returns True when all user-facing entities are still loading after startup."""
    user_facing_entries = [
        entry for entry in entity_entries if _is_user_facing_entity(entry)
    ]
    if not user_facing_entries:
        return False

    for entry in user_facing_entries:
        state = hass.states.get(entry.entity_id)
        if state is None:
            continue

        if state.state not in BOOTSTRAP_ENTITY_STATES:
            return False

    return True


def _build_fallback_availability(
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
    node_status: str | None,
) -> dict:
    """Builds availability when Z-Wave node status is inconclusive."""
    unavailable_count = _count_unavailable_primary_entities(hass, entity_entries)
    primary_count = _count_primary_entities(entity_entries)

    if primary_count > 0 and unavailable_count == primary_count:
        if _is_bootstrapping_availability(hass, entity_entries):
            return {
                "status": "unknown",
                "is_reachable": True,
                "node_status": node_status,
                "primary_entities_unavailable": unavailable_count,
            }

        return {
            "status": "offline",
            "is_reachable": False,
            "node_status": node_status,
            "primary_entities_unavailable": unavailable_count,
        }

    if unavailable_count > 0:
        return {
            "status": "partial",
            "is_reachable": True,
            "node_status": node_status,
            "primary_entities_unavailable": unavailable_count,
        }

    return {
        "status": "online",
        "is_reachable": True,
        "node_status": node_status,
        "primary_entities_unavailable": unavailable_count,
    }


def build_standalone_availability(
    hass: HomeAssistant,
    entry: er.RegistryEntry,
) -> dict:
    """Derives availability for a standalone entity (automation, script, helper)."""
    state = hass.states.get(entry.entity_id)

    if state is None:
        return {
            "status": "unknown",
            "is_reachable": True,
            "node_status": None,
            "primary_entities_unavailable": 1,
        }

    if state.state == "unavailable":
        return {
            "status": "offline",
            "is_reachable": False,
            "node_status": None,
            "primary_entities_unavailable": 1,
        }

    if entry.domain == "automation" and state.state == "off":
        return {
            "status": "disabled",
            "is_reachable": True,
            "node_status": None,
            "primary_entities_unavailable": 0,
        }

    return {
        "status": "online",
        "is_reachable": True,
        "node_status": None,
        "primary_entities_unavailable": 0,
    }
