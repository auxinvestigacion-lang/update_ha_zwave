"""Collects areas, devices and entities from Home Assistant registries."""

import logging

from homeassistant.core import HomeAssistant
from homeassistant.helpers import area_registry as ar
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

from ..api.messages import build_register_message, build_state_sync_message
from ..const import CONF_MAC, CONF_PROJECT_ID, LOG_PREFIX
from .device_enrichment import build_device_availability, build_device_metadata
from .device_filter import (
    get_primary_domain,
    is_actionable_device,
    is_trackable_entity_on_device,
    resolve_entity_device_class,
    serialize_entity_category,
)
from .lock_code_capabilities import enrich_devices_with_lock_codes
from .payload_serialization import serialize_state_attributes
from .plugin_grouper import build_plugin_entity_device_map
from .standalone_collector import collect_standalone_devices
from .virtual_collector import build_virtual_entity_device_map

_LOGGER = logging.getLogger(__name__)


def collect_inventory(hass: HomeAssistant) -> tuple[list[dict], list[dict]]:
    """Collects areas and devices with current entity states from HA registries."""
    area_reg = ar.async_get(hass)
    device_reg = dr.async_get(hass)
    entity_reg = er.async_get(hass)

    area_name_map = _build_area_name_map(area_reg)
    areas = _collect_areas(area_reg)
    physical_devices = _collect_devices(hass, device_reg, entity_reg, area_name_map)
    standalone_devices = collect_standalone_devices(hass, entity_reg, area_name_map)
    return areas, physical_devices + standalone_devices


async def collect_inventory_with_lock_codes(
    hass: HomeAssistant,
) -> tuple[list[dict], list[dict]]:
    """Collects inventory and enriches lock devices with user-code capabilities."""
    areas, devices = collect_inventory(hass)
    entity_reg = er.async_get(hass)
    await enrich_devices_with_lock_codes(hass, devices, entity_reg)
    return areas, devices


async def build_registration_payload(hass: HomeAssistant, config: dict) -> dict:
    """Builds the standardized registration message for the external server."""
    areas, devices = await collect_inventory_with_lock_codes(hass)

    payload = build_register_message(
        project_id=config[CONF_PROJECT_ID],
        serial=config[CONF_MAC],
        areas=areas,
        devices=devices,
    )

    entity_count = sum(len(device["entities"]) for device in devices)
    _LOGGER.debug(
        "%s registration payload: %d areas, %d devices, %d entities",
        LOG_PREFIX,
        len(areas),
        len(devices),
        entity_count,
    )

    return payload


async def build_state_sync_payload(hass: HomeAssistant, config: dict) -> dict:
    """Builds a WebSocket snapshot with the current inventory and entity states."""
    areas, devices = await collect_inventory_with_lock_codes(hass)

    payload = build_state_sync_message(
        project_id=config[CONF_PROJECT_ID],
        serial=config[CONF_MAC],
        areas=areas,
        devices=devices,
    )

    entity_count = sum(len(device["entities"]) for device in devices)
    _LOGGER.info(
        "%s state_sync payload: %d areas, %d devices, %d entities",
        LOG_PREFIX,
        len(areas),
        len(devices),
        entity_count,
    )

    return payload


def build_tracked_entity_map(hass: HomeAssistant) -> dict[str, str]:
    """Returns entity_id → device_id for physical, plugin and virtual entities."""
    device_reg = dr.async_get(hass)
    entity_reg = er.async_get(hass)
    tracked_map: dict[str, str] = {}
    plugin_tracking_map = build_plugin_entity_device_map(hass, entity_reg)

    for device in device_reg.devices.values():
        entity_entries = er.async_entries_for_device(entity_reg, device.id)
        if not is_actionable_device(device, entity_entries):
            continue

        for entry in entity_entries:
            if entry.device_id is None:
                continue
            if not is_trackable_entity_on_device(hass, entry, entity_entries):
                continue
            tracked_map[entry.entity_id] = entry.device_id

    for entity_id, plugin_device_id in plugin_tracking_map.items():
        entry = entity_reg.async_get(entity_id)
        if entry is None or entry.entity_category is not None:
            continue
        tracked_map[entity_id] = plugin_device_id

    virtual_tracking_map = build_virtual_entity_device_map(hass, entity_reg)
    for entity_id, virtual_device_id in virtual_tracking_map.items():
        tracked_map[entity_id] = virtual_device_id

    return tracked_map


def _build_area_name_map(area_reg: ar.AreaRegistry) -> dict[str, str]:
    """Builds area_id → area_name lookup."""
    return {area.id: area.name for area in area_reg.async_list_areas()}


def _collect_areas(area_reg: ar.AreaRegistry) -> list[dict]:
    """Collects all areas from the area registry."""
    return [
        {"id": area.id, "name": area.name}
        for area in area_reg.async_list_areas()
    ]


def _collect_devices(
    hass: HomeAssistant,
    device_reg: dr.DeviceRegistry,
    entity_reg: er.EntityRegistry,
    area_name_map: dict[str, str],
) -> list[dict]:
    """Collects actionable devices with their entities grouped by device."""
    devices: list[dict] = []

    for device in device_reg.devices.values():
        entity_entries = er.async_entries_for_device(entity_reg, device.id)
        if not is_actionable_device(device, entity_entries):
            continue

        entities = _collect_device_entities(hass, entity_entries)
        if not entities:
            continue

        area_id = device.area_id
        device_metadata = build_device_metadata(device, hass, entity_entries)
        availability = build_device_availability(hass, device, entity_entries)

        devices.append(
            {
                "id": device.id,
                "source": "physical",
                "name": device.name_by_user or device.name,
                **device_metadata,
                "primary_domain": get_primary_domain(entity_entries),
                "area_id": area_id,
                "area_name": area_name_map.get(area_id) if area_id else None,
                "availability": availability,
                "entities": entities,
            }
        )

    return devices


def _collect_device_entities(
    hass: HomeAssistant,
    entity_entries: list[er.RegistryEntry],
) -> list[dict]:
    """Collects enabled entities with state, domain and category metadata."""
    entities: list[dict] = []

    for entry in entity_entries:
        if entry.disabled_by is not None:
            continue

        state = hass.states.get(entry.entity_id)
        attributes = serialize_state_attributes(dict(state.attributes) if state else {})

        entities.append(
            {
                "entity_id": entry.entity_id,
                "domain": entry.domain,
                "name": entry.name or entry.original_name,
                "platform": entry.platform,
                "entity_category": serialize_entity_category(entry.entity_category),
                "device_class": resolve_entity_device_class(entry, attributes),
                "state": state.state if state else None,
                "attributes": attributes,
            }
        )

    return entities
