"""Resolves plugin automation families, roles, and logical primary selection."""

from __future__ import annotations

from typing import Protocol

# Known role suffixes stripped to obtain the family instance key (longest first).
PLUGIN_ROLE_SUFFIXES = ("_semaforo", "_ext", "_main")

# Role that marks the automation that owns the logical device id.
PLUGIN_PRIMARY_SUFFIX = "_main"

# Satellite roles that must never create their own logical device.
PLUGIN_SATELLITE_SUFFIXES = ("_semaforo", "_ext")

PLUGIN_FAMILY_OCCUPANCY = "occupancy"
PLUGIN_FAMILY_MOTEL = "motel"
PLUGIN_FAMILY_UNKNOWN = "unknown"

# Marker tokens inside the object_id → exported plugin_family value.
_PLUGIN_FAMILY_MARKERS: tuple[tuple[tuple[str, ...], str], ...] = (
    (("motel",), PLUGIN_FAMILY_MOTEL),
    (
        ("bp_plugin", "hotel", "occupancy", "ocupacion"),
        PLUGIN_FAMILY_OCCUPANCY,
    ),
)


class _HasEntityId(Protocol):
    """Minimal protocol for registry entries used in family selection."""

    entity_id: str


def get_plugin_object_id(entity_id: str) -> str:
    """Returns the object_id portion of a Home Assistant entity_id."""
    return entity_id.split(".", 1)[1]


def get_plugin_family_key(entity_id: str) -> str:
    """Returns the family instance key shared by primary and satellite automations.

    Examples:
        plugin_motel_main → plugin_motel
        plugin_motel_1_ext → plugin_motel_1
        bp_plugin_hotel_v1_3_2_8 → bp_plugin_hotel_v1_3_2_8
    """
    object_id = get_plugin_object_id(entity_id)
    for suffix in PLUGIN_ROLE_SUFFIXES:
        if object_id.endswith(suffix):
            return object_id[: -len(suffix)]
    return object_id


def resolve_plugin_family(entity_id: str) -> str:
    """Maps an automation entity_id to a stable plugin_family label for the payload."""
    object_id = get_plugin_object_id(entity_id).lower()
    for markers, family in _PLUGIN_FAMILY_MARKERS:
        if any(marker in object_id for marker in markers):
            return family
    return PLUGIN_FAMILY_UNKNOWN


def is_plugin_satellite_automation(entity_id: str) -> bool:
    """Returns True when the automation is a satellite role of a plugin family."""
    object_id = get_plugin_object_id(entity_id)
    return any(object_id.endswith(suffix) for suffix in PLUGIN_SATELLITE_SUFFIXES)


def is_plugin_primary_automation(entity_id: str) -> bool:
    """Returns True when the automation should own the logical plugin device id."""
    object_id = get_plugin_object_id(entity_id)
    if object_id.endswith(PLUGIN_PRIMARY_SUFFIX):
        return True
    return not is_plugin_satellite_automation(entity_id)


def select_primary_plugin_automation(
    family_automations: list[_HasEntityId],
) -> _HasEntityId:
    """Picks the primary automation that owns the logical device for a family."""
    if not family_automations:
        raise ValueError("family_automations must not be empty")

    sorted_automations = sorted(family_automations, key=lambda entry: entry.entity_id)

    for entry in sorted_automations:
        if get_plugin_object_id(entry.entity_id).endswith(PLUGIN_PRIMARY_SUFFIX):
            return entry

    for entry in sorted_automations:
        if is_plugin_primary_automation(entry.entity_id):
            return entry

    return sorted_automations[0]


def group_plugin_automations_by_family(
    plugin_automations: list[_HasEntityId],
) -> dict[str, list[_HasEntityId]]:
    """Groups plugin automations by family instance key."""
    families: dict[str, list[_HasEntityId]] = {}
    for entry in plugin_automations:
        family_key = get_plugin_family_key(entry.entity_id)
        families.setdefault(family_key, []).append(entry)
    return families


def get_plugin_family_stem(family_key: str) -> str:
    """Strips plugin_/bp_plugin_ prefixes so helpers can match by shared stem."""
    for prefix in ("bp_plugin_", "plugin_"):
        if family_key.startswith(prefix):
            return family_key[len(prefix) :]
    return family_key


def helper_matches_plugin_family(helper_entity_id: str, family_key: str) -> bool:
    """Returns True when a helper object_id is clearly tied to a plugin family key."""
    helper_object_id = get_plugin_object_id(helper_entity_id)
    if (
        helper_object_id.startswith(family_key)
        or family_key.startswith(helper_object_id)
        or family_key in helper_object_id
    ):
        return True

    family_stem = get_plugin_family_stem(family_key)
    if not family_stem:
        return False

    # Prefer exact stem boundaries so motel does not steal motel_1 helpers.
    return (
        helper_object_id == family_stem
        or helper_object_id.endswith(f"_{family_stem}")
    )
