"""Rules for standalone entities not linked to a physical device in HA."""

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er
from homeassistant.helpers.entity import EntityCategory

from ..const import DOMAIN

# Domains for entities that live outside the device registry (Automations UI, helpers).
STANDALONE_DOMAINS = frozenset(
    {
        "automation",
        "script",
        "scene",
        "input_boolean",
        "input_button",
        "input_select",
        "input_number",
        "input_text",
        "input_datetime",
    }
)

# Prefixes used to exclude Home Assistant system automations/scripts.
STANDALONE_ENTITY_ID_EXCLUDED_PREFIXES = (
    "automation.homeassistant_",
    "script.homeassistant_",
)

LOGICAL_DEVICE_ID_PREFIX = "logical:"
PLUGIN_DEVICE_ID_PREFIX = "logical:plugin:"
VIRTUAL_DEVICE_KIND = "virtual"
VIRTUAL_DEVICE_PLATFORM = "template"

# Template helper domains that represent virtual devices, not plugin input helpers.
VIRTUAL_DEVICE_DOMAINS = frozenset(
    {
        "alarm_control_panel",
        "binary_sensor",
        "button",
        "climate",
        "cover",
        "fan",
        "humidifier",
        "light",
        "lock",
        "media_player",
        "number",
        "select",
        "sensor",
        "switch",
        "vacuum",
        "water_heater",
    }
)

# Markers that identify blueprint plugin automations (occupancy, motel, etc.).
# Motel families use plugin_motel[_N]_{main|ext|semaforo}; satellites fold into main.
PLUGIN_AUTOMATION_ENTITY_ID_MARKERS = ("bp_plugin", "plugin_")
PLUGIN_AUTOMATION_NAME_KEYWORDS = ("plugin",)

# Helper domains typically created by blueprint plugins.
PLUGIN_HELPER_DOMAINS = frozenset(
    {
        "input_boolean",
        "input_button",
        "input_select",
        "input_number",
        "input_text",
        "input_datetime",
    }
)


def is_standalone_entity(entry: er.RegistryEntry) -> bool:
    """Returns True for enabled entities without device_id in standalone domains."""
    if entry.disabled_by is not None:
        return False

    if entry.device_id is not None:
        return False

    if entry.platform in {DOMAIN, "homeassistant", "hassio"}:
        return False

    if entry.domain not in STANDALONE_DOMAINS:
        return False

    if _is_excluded_standalone_entity_id(entry.entity_id):
        return False

    return True


def is_standalone_trackable_entity(
    hass: HomeAssistant,
    entry: er.RegistryEntry,
    entity_reg: er.EntityRegistry,
) -> bool:
    """Returns True when a plugin-group entity should emit WebSocket events."""
    if not is_plugin_group_entity(hass, entry, entity_reg):
        return False

    return entry.entity_category is None


def get_plugin_group_entity_ids(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
) -> set[str]:
    """Returns entity_ids that belong to a registrable blueprint plugin group."""
    from .plugin_group_resolver import build_plugin_group_assignments

    assignments = build_plugin_group_assignments(hass, entity_reg)
    plugin_entity_ids: set[str] = set()

    for plugin_entries in assignments.values():
        plugin_entity_ids.update(entry.entity_id for entry in plugin_entries)

    return plugin_entity_ids


def is_plugin_group_entity(
    hass: HomeAssistant,
    entry: er.RegistryEntry,
    entity_reg: er.EntityRegistry,
) -> bool:
    """Returns True only for entities inside a blueprint plugin group."""
    if not is_standalone_entity(entry):
        return False

    return entry.entity_id in get_plugin_group_entity_ids(hass, entity_reg)


def build_logical_device_id(entity_id: str) -> str:
    """Builds a stable synthetic device id for a standalone entity."""
    return f"{LOGICAL_DEVICE_ID_PREFIX}{entity_id}"


def build_plugin_device_id(automation_entity_id: str) -> str:
    """Builds a stable device id for a grouped plugin automation."""
    slug = automation_entity_id.removeprefix("automation.")
    return f"{PLUGIN_DEVICE_ID_PREFIX}{slug}"


def is_plugin_automation(entry: er.RegistryEntry) -> bool:
    """Returns True when the entity is a blueprint plugin automation."""
    if entry.domain != "automation":
        return False

    entity_id_lower = entry.entity_id.lower()
    if any(
        marker in entity_id_lower for marker in PLUGIN_AUTOMATION_ENTITY_ID_MARKERS
    ):
        return True

    entity_name = (entry.name or entry.original_name or "").lower()
    return any(keyword in entity_name for keyword in PLUGIN_AUTOMATION_NAME_KEYWORDS)


def is_plugin_helper(entry: er.RegistryEntry) -> bool:
    """Returns True when the entity is a helper typically used by plugins."""
    return entry.domain in PLUGIN_HELPER_DOMAINS


def is_virtual_device_entity(entry: er.RegistryEntry) -> bool:
    """Returns True for enabled template helpers that represent a virtual device.

    Input helpers used by occupancy/motel plugins are intentionally excluded.
    """
    if entry.disabled_by is not None:
        return False

    if entry.platform != VIRTUAL_DEVICE_PLATFORM:
        return False

    if entry.domain not in VIRTUAL_DEVICE_DOMAINS:
        return False

    if entry.entity_category is not None:
        return False

    return True


def resolve_virtual_device_name(entry: er.RegistryEntry) -> str:
    """Returns the display name used in the virtual device inventory payload."""
    return entry.name or entry.original_name or entry.entity_id


def parse_logical_device_id(device_id: str) -> str | None:
    """Extracts entity_id from a virtual logical device id, or None if not virtual."""
    if device_id.startswith(PLUGIN_DEVICE_ID_PREFIX):
        return None

    if not device_id.startswith(LOGICAL_DEVICE_ID_PREFIX):
        return None

    entity_id = device_id[len(LOGICAL_DEVICE_ID_PREFIX) :]
    if "." not in entity_id:
        return None

    return entity_id


def _is_excluded_standalone_entity_id(entity_id: str) -> bool:
    """Excludes built-in Home Assistant automations and scripts."""
    return entity_id.startswith(STANDALONE_ENTITY_ID_EXCLUDED_PREFIXES)
