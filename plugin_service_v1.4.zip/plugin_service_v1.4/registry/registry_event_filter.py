"""Filters Home Assistant registry events for physical, plugin and virtual devices."""

from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

from .device_filter import is_actionable_device
from .plugin_grouper import build_plugin_entity_device_map
from .plugin_family import is_plugin_primary_automation
from .standalone_filter import (
    PLUGIN_DEVICE_ID_PREFIX,
    is_plugin_automation,
    parse_logical_device_id,
)
from .virtual_collector import build_virtual_entity_device_map


def is_known_actionable_device(
    hass: HomeAssistant,
    device_id: str,
    known_device_ids: set[str],
) -> bool:
    """Returns True when a device should emit registry WebSocket messages."""
    if device_id in known_device_ids:
        return True

    if device_id.startswith(PLUGIN_DEVICE_ID_PREFIX):
        return _is_known_plugin_device(hass, device_id)

    if parse_logical_device_id(device_id) is not None:
        return _is_known_virtual_device(hass, device_id)

    return is_actionable_device_by_id(hass, device_id)


def is_actionable_device_by_id(hass: HomeAssistant, device_id: str) -> bool:
    """Returns True when the device registry entry is actionable."""
    device_reg = dr.async_get(hass)
    entity_reg = er.async_get(hass)
    device = device_reg.async_get(device_id)
    if device is None:
        return False

    entity_entries = er.async_entries_for_device(entity_reg, device.id)
    return is_actionable_device(device, entity_entries)


def resolve_entity_device_id(
    hass: HomeAssistant,
    entity_id: str,
) -> str | None:
    """Returns the external device_id for a registry entity, if trackable."""
    entity_reg = er.async_get(hass)
    entry = entity_reg.async_get(entity_id)
    if entry is None:
        return None

    if entry.device_id is not None:
        device_reg = dr.async_get(hass)
        device = device_reg.async_get(entry.device_id)
        if device is not None:
            device_entities = er.async_entries_for_device(entity_reg, device.id)
            if is_actionable_device(device, device_entities):
                return entry.device_id

    plugin_device_id = build_plugin_entity_device_map(hass, entity_reg).get(entity_id)
    if plugin_device_id is not None:
        return plugin_device_id

    virtual_device_id = build_virtual_entity_device_map(hass, entity_reg).get(entity_id)
    if virtual_device_id is not None:
        return virtual_device_id

    return entry.device_id


def should_notify_entity_registry_update(
    hass: HomeAssistant,
    entity_id: str,
    known_device_ids: set[str],
) -> tuple[bool, str | None]:
    """Returns whether an entity registry update should be forwarded."""
    entity_reg = er.async_get(hass)
    entry = entity_reg.async_get(entity_id)
    if entry is None:
        return False, None

    device_id = resolve_entity_device_id(hass, entity_id)
    if device_id is None:
        return False, None

    if device_id.startswith(PLUGIN_DEVICE_ID_PREFIX):
        plugin_tracking_map = build_plugin_entity_device_map(hass, entity_reg)
        if entry.entity_id not in plugin_tracking_map:
            return False, None
        return True, device_id

    if not is_known_actionable_device(hass, device_id, known_device_ids):
        return False, None

    return True, device_id


def _is_known_plugin_device(hass: HomeAssistant, device_id: str) -> bool:
    """Returns True when the logical plugin device still has a plugin automation."""
    entity_reg = er.async_get(hass)
    automation_slug = device_id.removeprefix(PLUGIN_DEVICE_ID_PREFIX)
    automation_entity_id = f"automation.{automation_slug}"
    entry = entity_reg.async_get(automation_entity_id)
    if entry is None:
        return False

    return is_plugin_automation(entry) and is_plugin_primary_automation(
        entry.entity_id
    )


def _is_known_virtual_device(hass: HomeAssistant, device_id: str) -> bool:
    """Returns True when the logical id still maps to a registrable template helper."""
    entity_id = parse_logical_device_id(device_id)
    if entity_id is None:
        return False

    entity_reg = er.async_get(hass)
    return entity_id in build_virtual_entity_device_map(hass, entity_reg)
