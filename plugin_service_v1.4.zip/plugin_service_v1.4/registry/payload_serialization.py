"""JSON-safe serialization for payloads sent to the external server."""

from enum import Enum

from homeassistant.helpers import json as ha_json
from homeassistant.util.json import json_loads_object


def serialize_disabled_by(disabled_by) -> str | None:
    """Converts a registry disabled_by value to a JSON-safe string."""
    if disabled_by is None:
        return None

    if isinstance(disabled_by, Enum):
        return disabled_by.value

    return str(disabled_by)


def serialize_state_attributes(attributes: dict) -> dict:
    """Returns entity attributes as a JSON-serializable dict."""
    if not attributes:
        return {}

    return json_loads_object(ha_json.json_dumps(attributes))


def dumps_payload(payload: dict) -> str:
    """Serializes a payload dict to a JSON string using Home Assistant encoding."""
    return ha_json.json_dumps(payload)


def dumps_payload_bytes(payload: dict) -> bytes:
    """Serializes a payload dict to UTF-8 JSON bytes for HTTP requests."""
    return ha_json.json_bytes(payload)
