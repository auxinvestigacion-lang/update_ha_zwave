"""Stores lock user_id to code_slot mappings learned from programming events."""

from homeassistant.core import HomeAssistant

from ..const import DATA_LOCK_USER_SLOT_REGISTRY, DOMAIN


class LockUserSlotRegistry:
    """Keeps device_id + user_id → code_slot mappings in memory."""

    def __init__(self) -> None:
        self._mappings: dict[str, dict[int, int]] = {}

    def store(self, device_id: str, user_id: int, code_slot: int) -> None:
        """Stores or updates the slot associated with a lock user_id."""
        device_mappings = self._mappings.setdefault(device_id, {})
        device_mappings[int(user_id)] = int(code_slot)

    def get_code_slot(self, device_id: str, user_id: int) -> int | None:
        """Returns a previously stored code_slot for a lock user_id."""
        return self._mappings.get(device_id, {}).get(int(user_id))


def get_lock_user_slot_registry(hass: HomeAssistant) -> LockUserSlotRegistry:
    """Returns the shared in-memory lock user/slot registry for this HA instance."""
    domain_data = hass.data.setdefault(DOMAIN, {})
    registry = domain_data.get(DATA_LOCK_USER_SLOT_REGISTRY)
    if registry is None:
        registry = LockUserSlotRegistry()
        domain_data[DATA_LOCK_USER_SLOT_REGISTRY] = registry
    return registry
