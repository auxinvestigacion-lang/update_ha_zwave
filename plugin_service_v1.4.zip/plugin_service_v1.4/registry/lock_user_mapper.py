"""Maps Z-Wave lock internal user IDs to credential slots."""

import asyncio
import logging

from homeassistant.core import HomeAssistant

from ..const import LOG_PREFIX, ZWAVE_JS_DOMAIN
from ..api.service_executor import execute_ha_service
from .lock_code_capabilities import LOCK_CODE_API_CREDENTIAL
from .lock_user_slot_registry import get_lock_user_slot_registry

_LOGGER = logging.getLogger(__name__)

ZWAVE_JS_SERVICE_GET_USERS = "get_users"
GET_USERS_RETRY_DELAY_SECONDS = 0.35


async def resolve_code_slot_for_user(
    hass: HomeAssistant,
    entity_id: str,
    user_id: int,
    lock_api: str,
    device_id: str | None = None,
) -> int | None:
    """Returns the credential slot associated with a lock user_id, when available."""
    if lock_api != LOCK_CODE_API_CREDENTIAL:
        if 1 <= user_id <= 254:
            return user_id
        return None

    for attempt_index in range(2):
        users_response = await _fetch_lock_users(hass, entity_id)
        code_slot = _resolve_code_slot_from_users_response(
            users_response,
            entity_id,
            user_id,
        )
        if code_slot is not None:
            if device_id is not None:
                get_lock_user_slot_registry(hass).store(device_id, user_id, code_slot)
            return code_slot

        if attempt_index == 0:
            await asyncio.sleep(GET_USERS_RETRY_DELAY_SECONDS)

    if device_id is not None:
        cached_slot = get_lock_user_slot_registry(hass).get_code_slot(device_id, user_id)
        if cached_slot is not None:
            _LOGGER.debug(
                "%s resolved code_slot from registry [device: %s | user_id: %s | slot: %s]",
                LOG_PREFIX,
                device_id,
                user_id,
                cached_slot,
            )
            return cached_slot

    _LOGGER.warning(
        "%s could not map user_id to code_slot [entity: %s | user_id: %s | device: %s]",
        LOG_PREFIX,
        entity_id,
        user_id,
        device_id,
    )
    return None


async def fetch_lock_user_slots(
    hass: HomeAssistant,
    entity_id: str,
    *,
    include_pins: bool = False,
) -> list[dict]:
    """Returns normalized user/slot entries from zwave_js.get_users."""
    users_response = await _fetch_lock_users(hass, entity_id)
    entity_data = _extract_entity_response(users_response, entity_id)
    if not isinstance(entity_data, dict):
        return []

    normalized_users: list[dict] = []
    for user_entry in entity_data.get("users", []):
        if not isinstance(user_entry, dict):
            continue

        credential_slots = _extract_credential_slots(user_entry)
        user_record = {
            "user_id": _coerce_int(user_entry.get("user_id")),
            "code_slot": credential_slots[0] if credential_slots else None,
            "credential_slots": credential_slots,
            "in_use": bool(credential_slots),
            "user_name": user_entry.get("user_name"),
            "active": user_entry.get("active"),
            "user_type": user_entry.get("user_type"),
            "credential_rule": user_entry.get("credential_rule"),
        }
        if include_pins:
            user_record["credentials"] = user_entry.get("credentials", [])

        normalized_users.append(user_record)

    normalized_users.sort(
        key=lambda item: (
            item["code_slot"] is None,
            item["code_slot"] if item["code_slot"] is not None else 0,
            item["user_id"] if item["user_id"] is not None else 0,
        )
    )
    return normalized_users


def _resolve_code_slot_from_users_response(
    response: dict | None,
    entity_id: str,
    user_id: int,
) -> int | None:
    """Extracts a code_slot for one user_id from a get_users response."""
    user_entry = _find_user_entry(response, entity_id, user_id)
    if user_entry is None:
        return None

    credential_slots = _extract_credential_slots(user_entry)
    if not credential_slots:
        return None

    return credential_slots[0]


async def _fetch_lock_users(hass: HomeAssistant, entity_id: str) -> dict | None:
    """Queries zwave_js.get_users for a lock entity."""
    try:
        return await execute_ha_service(
            hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_GET_USERS,
            service_data={"entity_id": entity_id},
            return_response=True,
        )
    except Exception as err:
        _LOGGER.debug(
            "%s get_users unavailable for %s: %s",
            LOG_PREFIX,
            entity_id,
            err,
        )
        return None


def _find_user_entry(
    response: dict | None,
    entity_id: str,
    user_id: int,
) -> dict | None:
    """Returns one user entry from a get_users response."""
    entity_data = _extract_entity_response(response, entity_id)
    if not isinstance(entity_data, dict):
        return None

    for user_entry in entity_data.get("users", []):
        if not isinstance(user_entry, dict):
            continue

        entry_user_id = _coerce_int(user_entry.get("user_id"))
        if entry_user_id == user_id:
            return user_entry

    return None


def _extract_credential_slots(user_entry: dict) -> list[int]:
    """Extracts numeric credential slot identifiers from a user entry."""
    credential_slots: list[int] = []

    for credential in user_entry.get("credentials", []):
        if not isinstance(credential, dict):
            continue

        credential_type = credential.get("credential_type", credential.get("credentialType"))
        if credential_type is not None and credential_type not in {
            "pin_code",
            "pinCode",
        }:
            continue

        slot_candidate = credential.get("credential_slot")
        if slot_candidate is None:
            slot_candidate = credential.get("credentialSlot")
        if slot_candidate is None:
            slot_candidate = credential.get("slot")

        parsed_slot = _coerce_int(slot_candidate)
        if parsed_slot is not None:
            credential_slots.append(parsed_slot)

    return sorted(set(credential_slots))


def _extract_entity_response(response: dict | None, entity_id: str) -> dict | None:
    """Extracts per-entity payload from a zwave_js service response."""
    if not isinstance(response, dict):
        return None

    entity_payload = response.get(entity_id)
    if isinstance(entity_payload, dict):
        return entity_payload

    if len(response) == 1:
        only_value = next(iter(response.values()))
        if isinstance(only_value, dict):
            return only_value

    return response


def _coerce_int(value) -> int | None:
    """Parses an integer value when possible."""
    if value is None:
        return None

    try:
        return int(value)
    except (TypeError, ValueError):
        return None
