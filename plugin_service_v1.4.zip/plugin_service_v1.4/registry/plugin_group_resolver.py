"""Resolves which standalone helpers belong to each plugin automation family."""

import logging

from homeassistant.components.automation import entities_in_automation
from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from ..const import LOG_PREFIX
from .plugin_family import (
    group_plugin_automations_by_family,
    helper_matches_plugin_family,
    select_primary_plugin_automation,
)
from .standalone_filter import is_plugin_automation, is_plugin_helper, is_standalone_entity

_LOGGER = logging.getLogger(__name__)


def build_plugin_group_assignments(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
) -> dict[str, list[er.RegistryEntry]]:
    """Maps each primary plugin automation entity_id to its full family group.

    Satellite automations (e.g. plugin_motel_ext) are folded into the primary
    (plugin_motel_main) instead of creating separate logical devices.
    """
    standalone_entries = [
        entry for entry in entity_reg.entities.values() if is_standalone_entity(entry)
    ]
    plugin_automations = [
        entry for entry in standalone_entries if is_plugin_automation(entry)
    ]
    if not plugin_automations:
        return {}

    helper_entries = [entry for entry in standalone_entries if is_plugin_helper(entry)]
    families = group_plugin_automations_by_family(plugin_automations)
    plugins_per_area = _count_plugin_families_per_area(families)
    assignments: dict[str, list[er.RegistryEntry]] = {}
    assigned_helper_ids: set[str] = set()

    for family_key in sorted(families):
        family_automations = sorted(
            families[family_key], key=lambda entry: entry.entity_id
        )
        primary = select_primary_plugin_automation(family_automations)
        matched_helpers = resolve_plugin_helpers(
            hass=hass,
            primary_automation=primary,
            family_automations=family_automations,
            family_key=family_key,
            helper_entries=helper_entries,
            assigned_helper_ids=assigned_helper_ids,
            plugins_per_area=plugins_per_area,
        )
        assigned_helper_ids.update(entry.entity_id for entry in matched_helpers)
        assignments[primary.entity_id] = [
            *family_automations,
            *matched_helpers,
        ]

    return assignments


def resolve_plugin_helpers(
    hass: HomeAssistant,
    primary_automation: er.RegistryEntry,
    family_automations: list[er.RegistryEntry],
    family_key: str,
    helper_entries: list[er.RegistryEntry],
    assigned_helper_ids: set[str],
    plugins_per_area: dict[str | None, int],
) -> list[er.RegistryEntry]:
    """Resolves helper entities for one plugin family using HA references and fallbacks."""
    available_helpers = [
        entry
        for entry in helper_entries
        if entry.entity_id not in assigned_helper_ids
    ]
    if not available_helpers:
        return []

    matched_helpers = _match_referenced_helpers(
        hass, family_automations, available_helpers
    )
    if matched_helpers:
        return matched_helpers

    matched_helpers = _match_helpers_by_area(
        primary_automation, available_helpers, plugins_per_area
    )
    if matched_helpers:
        return matched_helpers

    return _match_helpers_by_family_key(family_key, available_helpers)


def _count_plugin_families_per_area(
    families: dict[str, list[er.RegistryEntry]],
) -> dict[str | None, int]:
    """Counts plugin families assigned to each Home Assistant area via their primary."""
    plugins_per_area: dict[str | None, int] = {}
    for family_automations in families.values():
        primary = select_primary_plugin_automation(family_automations)
        area_id = primary.area_id
        plugins_per_area[area_id] = plugins_per_area.get(area_id, 0) + 1
    return plugins_per_area


def _match_referenced_helpers(
    hass: HomeAssistant,
    family_automations: list[er.RegistryEntry],
    helper_entries: list[er.RegistryEntry],
) -> list[er.RegistryEntry]:
    """Matches helpers referenced by any automation in the plugin family.

    Home Assistant can raise TypeError while building referenced_entities when an
    automation stores a nested list/dict as entity_id. Skip that automation and
    keep resolving helpers from the rest of the family (or later fallbacks).
    """
    referenced_entity_ids: set[str] = set()
    for automation in family_automations:
        try:
            referenced_ids = entities_in_automation(hass, automation.entity_id)
        except TypeError as err:
            _LOGGER.warning(
                "%s skipping referenced entities for %s: %s",
                LOG_PREFIX,
                automation.entity_id,
                err,
            )
            continue

        referenced_entity_ids.update(
            entity_id
            for entity_id in referenced_ids
            if isinstance(entity_id, str)
        )
    if not referenced_entity_ids:
        return []

    return [
        entry
        for entry in helper_entries
        if entry.entity_id in referenced_entity_ids
    ]


def _match_helpers_by_area(
    primary_automation: er.RegistryEntry,
    helper_entries: list[er.RegistryEntry],
    plugins_per_area: dict[str | None, int],
) -> list[er.RegistryEntry]:
    """Matches helpers by area when the family is the only plugin in that area."""
    area_id = primary_automation.area_id
    if area_id is None or plugins_per_area.get(area_id, 0) != 1:
        return []

    return [entry for entry in helper_entries if entry.area_id == area_id]


def _match_helpers_by_family_key(
    family_key: str,
    helper_entries: list[er.RegistryEntry],
) -> list[er.RegistryEntry]:
    """Matches helpers whose object_id is clearly tied to the plugin family key."""
    return [
        entry
        for entry in helper_entries
        if helper_matches_plugin_family(entry.entity_id, family_key)
    ]
