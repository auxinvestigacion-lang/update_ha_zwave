"""Normalizes Home Assistant registry change payloads for the external server."""

from enum import Enum

from .standalone_filter import resolve_virtual_device_name

# Device registry fields forwarded to the external server.
DEVICE_REGISTRY_CHANGE_FIELDS = frozenset(
    {
        "name",
        "name_by_user",
        "area_id",
        "disabled_by",
        "labels",
    }
)

# Entity registry fields forwarded when scoped to an actionable device.
ENTITY_REGISTRY_CHANGE_FIELDS = frozenset(
    {
        "name",
        "name_by_user",
        "area_id",
        "disabled_by",
    }
)

# Template helper titles live in original_name; user overrides live in name.
VIRTUAL_ENTITY_NAME_FIELDS = frozenset({"name", "original_name"})
VIRTUAL_HA_DEVICE_NAME_FIELDS = frozenset({"name", "name_by_user"})


def normalize_device_registry_changes(
    ha_changes: dict,
    current_values: dict,
) -> dict:
    """Maps HA device registry changes to {field: {old, new}} payloads."""
    return _normalize_registry_changes(
        ha_changes,
        current_values,
        DEVICE_REGISTRY_CHANGE_FIELDS,
    )


def normalize_entity_registry_changes(
    ha_changes: dict,
    current_values: dict,
) -> dict:
    """Maps HA entity registry changes to {field: {old, new}} payloads."""
    return _normalize_registry_changes(
        ha_changes,
        current_values,
        ENTITY_REGISTRY_CHANGE_FIELDS,
    )


def build_device_current_values(device) -> dict:
    """Extracts comparable device registry values for change normalization."""
    return {
        "name": device.name,
        "name_by_user": device.name_by_user,
        "area_id": device.area_id,
        "disabled_by": device.disabled_by,
        "labels": device.labels,
    }


def build_entity_current_values(entry) -> dict:
    """Extracts comparable entity registry values for change normalization."""
    return {
        "name": entry.name,
        "name_by_user": getattr(entry, "name_by_user", None),
        "area_id": entry.area_id,
        "disabled_by": entry.disabled_by,
    }


def build_virtual_name_change_from_entity(ha_changes: dict, entry) -> dict:
    """Maps a template helper rename to a device-level name change.

    Home Assistant stores the helper title in original_name; the inventory uses
    name or original_name, so both fields collapse into changes.name.
    """
    if not VIRTUAL_ENTITY_NAME_FIELDS.intersection(ha_changes):
        return {}

    previous_name = ha_changes["name"] if "name" in ha_changes else entry.name
    previous_original_name = (
        ha_changes["original_name"] if "original_name" in ha_changes else entry.original_name
    )
    old_name = previous_name or previous_original_name or entry.entity_id
    new_name = resolve_virtual_device_name(entry)
    return _build_name_change(old_name, new_name)


def build_virtual_name_change_from_ha_device(ha_changes: dict, device) -> dict:
    """Maps a template-only HA device rename to a device-level name change."""
    if not VIRTUAL_HA_DEVICE_NAME_FIELDS.intersection(ha_changes):
        return {}

    previous_name_by_user = (
        ha_changes["name_by_user"] if "name_by_user" in ha_changes else device.name_by_user
    )
    previous_name = ha_changes["name"] if "name" in ha_changes else device.name
    old_name = previous_name_by_user or previous_name
    new_name = device.name_by_user or device.name
    if old_name is None or new_name is None:
        return {}

    return _build_name_change(old_name, new_name)


def _build_name_change(old_name: str, new_name: str) -> dict:
    """Returns a name change payload when the resolved display name differs."""
    if old_name == new_name:
        return {}

    return {"name": {"old": old_name, "new": new_name}}


def _normalize_registry_changes(
    ha_changes: dict,
    current_values: dict,
    allowed_fields: frozenset[str],
) -> dict:
    """Builds old/new pairs for fields present in the HA changes dict."""
    normalized_changes: dict = {}

    for field_name, old_value in ha_changes.items():
        if field_name not in allowed_fields:
            continue

        new_value = current_values.get(field_name)
        serialized_old = _serialize_registry_value(old_value)
        serialized_new = _serialize_registry_value(new_value)

        if serialized_old == serialized_new:
            continue

        normalized_changes[field_name] = {
            "old": serialized_old,
            "new": serialized_new,
        }

    return normalized_changes


def _serialize_registry_value(value) -> str | list[str] | None:
    """Converts registry values to JSON-safe primitives."""
    if value is None:
        return None

    if isinstance(value, Enum):
        return value.value

    if isinstance(value, set):
        return sorted(value)

    if isinstance(value, (list, tuple)):
        return sorted(value)

    return value
