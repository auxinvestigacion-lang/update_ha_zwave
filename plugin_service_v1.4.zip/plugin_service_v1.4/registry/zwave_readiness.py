"""Waits until Z-Wave JS inventory is stable enough for register/state_sync."""

import asyncio
import logging

from homeassistant.config_entries import ConfigEntryState
from homeassistant.const import EVENT_HOMEASSISTANT_STARTED
from homeassistant.core import CoreState, HomeAssistant, callback
from homeassistant.helpers import entity_registry as er

from ..const import (
    LOG_PREFIX,
    ZWAVE_JS_DOMAIN,
    ZWAVE_READY_POLL_INTERVAL_SECONDS,
    ZWAVE_READY_SETTLE_SECONDS,
    ZWAVE_READY_TIMEOUT_SECONDS,
)
from .device_enrichment import BOOTSTRAP_ENTITY_STATES, is_zwave_node_status_entity

_LOGGER = logging.getLogger(__name__)


async def wait_for_zwave_inventory_ready(hass: HomeAssistant) -> bool:
    """Blocks until Z-Wave entities are present in the state machine.

    Returns True when readiness was confirmed, False when the timeout expired
    or Z-Wave is unavailable. Callers still proceed so registration is not
    permanently blocked.
    """
    await _wait_for_home_assistant_running(hass)

    if not _has_zwave_config_entry(hass):
        _LOGGER.info(
            "%s no zwave_js config entry — skipping Z-Wave readiness wait",
            LOG_PREFIX,
        )
        return False

    deadline = asyncio.get_running_loop().time() + ZWAVE_READY_TIMEOUT_SECONDS
    last_reason = "zwave_js not connected"

    while asyncio.get_running_loop().time() < deadline:
        if hass.is_stopping:
            return False

        ready, last_reason = _evaluate_zwave_inventory_readiness(hass)
        if ready:
            if ZWAVE_READY_SETTLE_SECONDS > 0:
                await asyncio.sleep(ZWAVE_READY_SETTLE_SECONDS)
            _LOGGER.info("%s Z-Wave inventory ready for registration sync", LOG_PREFIX)
            return True

        await asyncio.sleep(ZWAVE_READY_POLL_INTERVAL_SECONDS)

    _LOGGER.warning(
        "%s Z-Wave readiness timed out after %ss (%s) — continuing anyway",
        LOG_PREFIX,
        ZWAVE_READY_TIMEOUT_SECONDS,
        last_reason,
    )
    return False


async def _wait_for_home_assistant_running(hass: HomeAssistant) -> None:
    """Waits until Home Assistant reaches the running state."""
    if hass.state is CoreState.running:
        return

    started = asyncio.Event()

    @callback
    def _on_started(_event) -> None:
        started.set()

    hass.bus.async_listen_once(EVENT_HOMEASSISTANT_STARTED, _on_started)
    if hass.state is CoreState.running:
        started.set()

    await started.wait()


def _has_zwave_config_entry(hass: HomeAssistant) -> bool:
    """Returns True when at least one zwave_js config entry exists."""
    return bool(hass.config_entries.async_entries(ZWAVE_JS_DOMAIN))


def _evaluate_zwave_inventory_readiness(hass: HomeAssistant) -> tuple[bool, str]:
    """Checks whether the Z-Wave driver and entity states are ready to export."""
    client = _get_zwave_client(hass)
    if client is None:
        return False, "zwave_js client not loaded"

    if not getattr(client, "connected", False):
        return False, "zwave_js client disconnected"

    if getattr(client, "driver", None) is None:
        return False, "zwave_js driver missing"

    with_state, total = _count_zwave_entity_state_coverage(hass)
    if total == 0:
        return False, "no zwave_js entities in registry yet"

    if with_state < total:
        return False, f"entity states {with_state}/{total}"

    if not _are_node_status_sensors_settled(hass):
        return False, "node status sensors still bootstrapping"

    return True, "ready"


def _get_zwave_client(hass: HomeAssistant):
    """Returns the first loaded zwave_js client, when available."""
    for entry in hass.config_entries.async_entries(ZWAVE_JS_DOMAIN):
        if entry.state is not ConfigEntryState.LOADED:
            continue

        runtime_data = getattr(entry, "runtime_data", None)
        client = getattr(runtime_data, "client", None)
        if client is not None:
            return client

    return None


def _count_zwave_entity_state_coverage(hass: HomeAssistant) -> tuple[int, int]:
    """Counts enabled zwave_js entities that already exist in the state machine."""
    entity_reg = er.async_get(hass)
    total = 0
    with_state = 0

    for entry in entity_reg.entities.values():
        if entry.platform != ZWAVE_JS_DOMAIN or entry.disabled_by is not None:
            continue

        total += 1
        if hass.states.get(entry.entity_id) is not None:
            with_state += 1

    return with_state, total


def _are_node_status_sensors_settled(hass: HomeAssistant) -> bool:
    """Returns True when node status sensors left bootstrap unknown/unavailable."""
    entity_reg = er.async_get(hass)
    found_status_sensor = False

    for entry in entity_reg.entities.values():
        if entry.platform != ZWAVE_JS_DOMAIN or entry.disabled_by is not None:
            continue

        if not is_zwave_node_status_entity(entry):
            continue

        found_status_sensor = True
        state = hass.states.get(entry.entity_id)
        if state is None or state.state.lower() in BOOTSTRAP_ENTITY_STATES:
            return False

    # No status sensors yet is not a pass — wait until zwave creates them.
    return found_status_sensor
