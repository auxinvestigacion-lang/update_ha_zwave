"""Home Assistant registry access: device filtering and data collection."""
