"""Groups blueprint plugin families and their helper entities into one logical device."""

import logging

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from ..const import LOG_PREFIX

from .device_enrichment import build_standalone_availability
from .device_filter import resolve_entity_device_class
from .payload_serialization import serialize_disabled_by, serialize_state_attributes
from .plugin_family import resolve_plugin_family
from .plugin_group_resolver import build_plugin_group_assignments
from .standalone_filter import build_plugin_device_id

_LOGGER = logging.getLogger(__name__)


def collect_grouped_plugin_devices(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
    area_name_map: dict[str, str],
    standalone_entries: list[er.RegistryEntry],
) -> tuple[list[dict], set[str]]:
    """Builds one logical device per plugin family (primary + satellites + helpers).

    Returns the plugin devices and the entity_ids already assigned to a plugin.
    ``standalone_entries`` is kept for call-site compatibility; grouping reads the
    full entity registry so satellites and helpers stay consistent.
    """
    _ = standalone_entries
    assignments = build_plugin_group_assignments(hass, entity_reg)
    if not assignments:
        return [], set()

    grouped_entity_ids: set[str] = set()
    devices: list[dict] = []

    for primary_entity_id in sorted(assignments):
        plugin_entities = assignments[primary_entity_id]
        primary_automation = next(
            entry
            for entry in plugin_entities
            if entry.entity_id == primary_entity_id
        )
        device = _build_plugin_device(
            hass=hass,
            plugin_automation=primary_automation,
            plugin_entities=plugin_entities,
            area_name_map=area_name_map,
        )
        devices.append(device)
        grouped_entity_ids.update(
            entity["entity_id"] for entity in device["entities"]
        )

    _LOGGER.debug(
        "%s grouped %d plugin device(s) with %d entities",
        LOG_PREFIX,
        len(devices),
        len(grouped_entity_ids),
    )
    return devices, grouped_entity_ids


def build_plugin_entity_device_map(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
) -> dict[str, str]:
    """Returns entity_id → plugin device_id for entities belonging to a plugin group."""
    assignments = build_plugin_group_assignments(hass, entity_reg)
    tracking_map: dict[str, str] = {}

    for automation_entity_id, plugin_entries in assignments.items():
        plugin_device_id = build_plugin_device_id(automation_entity_id)
        for entry in plugin_entries:
            tracking_map[entry.entity_id] = plugin_device_id

    return tracking_map


def _build_plugin_device(
    hass: HomeAssistant,
    plugin_automation: er.RegistryEntry,
    plugin_entities: list[er.RegistryEntry],
    area_name_map: dict[str, str],
) -> dict:
    """Builds a single plugin logical device payload."""
    plugin_name = (
        plugin_automation.name
        or plugin_automation.original_name
        or plugin_automation.entity_id
    )
    area_id = plugin_automation.area_id
    entities = [
        _serialize_standalone_entity(hass, entry)
        for entry in sorted(plugin_entities, key=lambda item: item.entity_id)
    ]

    return {
        "id": build_plugin_device_id(plugin_automation.entity_id),
        "source": "standalone",
        "device_kind": "plugin",
        "plugin_family": resolve_plugin_family(plugin_automation.entity_id),
        "name": plugin_name,
        "manufacturer": "Home Assistant",
        "model": "blueprint_plugin",
        "model_id": _extract_plugin_version(plugin_name),
        "hw_version": None,
        "sw_version": _extract_plugin_version(plugin_name),
        "serial_number": None,
        "entry_type": "logical",
        "labels": sorted(plugin_automation.labels),
        "disabled_by": serialize_disabled_by(plugin_automation.disabled_by),
        "primary_domain": "automation",
        "area_id": area_id,
        "area_name": area_name_map.get(area_id) if area_id else None,
        "availability": _build_plugin_availability(
            hass, plugin_automation, plugin_entities
        ),
        "entities": entities,
    }


def _serialize_standalone_entity(
    hass: HomeAssistant,
    entry: er.RegistryEntry,
) -> dict:
    """Serializes a standalone entity for inclusion in a plugin device."""
    state = hass.states.get(entry.entity_id)
    attributes = serialize_state_attributes(dict(state.attributes) if state else {})
    entity_name = entry.name or entry.original_name or entry.entity_id

    return {
        "entity_id": entry.entity_id,
        "domain": entry.domain,
        "name": entity_name,
        "platform": entry.platform,
        "entity_category": None,
        "device_class": resolve_entity_device_class(entry, attributes),
        "state": state.state if state else None,
        "attributes": attributes,
    }


def _build_plugin_availability(
    hass: HomeAssistant,
    primary_automation: er.RegistryEntry,
    plugin_entities: list[er.RegistryEntry],
) -> dict:
    """Aggregates availability from the plugin family; status follows the primary."""
    unavailable_count = 0
    for entry in plugin_entities:
        availability = build_standalone_availability(hass, entry)
        unavailable_count += availability["primary_entities_unavailable"]

    primary_status = build_standalone_availability(hass, primary_automation)["status"]

    if unavailable_count == len(plugin_entities):
        return {
            "status": "offline",
            "is_reachable": False,
            "node_status": None,
            "primary_entities_unavailable": unavailable_count,
        }

    if primary_status == "disabled":
        return {
            "status": "disabled",
            "is_reachable": True,
            "node_status": None,
            "primary_entities_unavailable": unavailable_count,
        }

    return {
        "status": "online",
        "is_reachable": True,
        "node_status": None,
        "primary_entities_unavailable": unavailable_count,
    }


def _extract_plugin_version(plugin_name: str) -> str | None:
    """Extracts a version token from the plugin automation name when present."""
    if "v" not in plugin_name.lower():
        return None

    for token in plugin_name.replace("-", " ").split():
        if token.lower().startswith("v") and any(char.isdigit() for char in token):
            return token.lstrip("vV")

    return None
