"""Resolves Z-Wave lock entities and queries user-code capabilities from Home Assistant."""

import logging

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from ..const import (
    LOCK_CODE_INVENTORY_INCLUDE_PINS,
    LOCK_CODE_MIN_PIN_LENGTH,
    LOG_PREFIX,
    ZWAVE_JS_DOMAIN,
)

_LOGGER = logging.getLogger(__name__)

LOCK_DOMAIN = "lock"
LOCK_CODE_API_USERCODE = "usercode"
LOCK_CODE_API_CREDENTIAL = "credential"
ZWAVE_JS_SERVICE_GET_CREDENTIAL_CAPABILITIES = "get_credential_capabilities"
ZWAVE_JS_SERVICE_GET_LOCK_USERCODE = "get_lock_usercode"


def resolve_lock_entity_id(entity_entries: list[er.RegistryEntry]) -> str | None:
    """Returns the primary zwave_js lock entity_id for a device, if present."""
    for entry in entity_entries:
        if entry.disabled_by is not None:
            continue

        if (
            entry.domain == LOCK_DOMAIN
            and entry.platform == ZWAVE_JS_DOMAIN
            and entry.entity_category is None
        ):
            return entry.entity_id

    return None


def build_default_lock_codes_profile(entity_id: str) -> dict:
    """Builds a lock_codes profile before querying Home Assistant capabilities."""
    return {
        "entity_id": entity_id,
        "supported": True,
        "api": LOCK_CODE_API_USERCODE,
        "max_slots": None,
        "min_pin_length": LOCK_CODE_MIN_PIN_LENGTH,
        "max_pin_length": None,
        "supports_user_management": False,
    }


async def fetch_lock_code_capabilities(
    hass: HomeAssistant,
    entity_id: str,
) -> dict:
    """Queries zwave_js for lock user-code capabilities and normalizes the profile."""
    profile = build_default_lock_codes_profile(entity_id)
    credential_caps = await _query_credential_capabilities(hass, entity_id)
    if credential_caps is not None:
        return credential_caps

    legacy_supported = await _probe_legacy_usercode_api(hass, entity_id)
    if not legacy_supported:
        profile["supported"] = False

    return profile


async def enrich_devices_with_lock_codes(
    hass: HomeAssistant,
    devices: list[dict],
    entity_reg: er.EntityRegistry,
) -> None:
    """Attaches lock_codes metadata and occupied slots to actionable lock devices."""
    for device in devices:
        if device.get("primary_domain") != LOCK_DOMAIN:
            continue

        entity_entries = er.async_entries_for_device(entity_reg, device["id"])
        lock_entity_id = resolve_lock_entity_id(entity_entries)
        if lock_entity_id is None:
            continue

        lock_codes_profile = await fetch_lock_code_capabilities(hass, lock_entity_id)
        lock_codes_profile["slots"] = await _resolve_lock_code_slots_for_device(
            hass,
            lock_entity_id,
            lock_codes_profile,
            device,
        )
        device["lock_codes"] = lock_codes_profile


def _is_lock_device_reachable(device: dict) -> bool:
    """Returns whether the lock device is considered reachable for slot queries."""
    availability = device.get("availability") or {}
    return bool(availability.get("is_reachable", False))


async def _resolve_lock_code_slots_for_device(
    hass: HomeAssistant,
    entity_id: str,
    lock_codes_profile: dict,
    device: dict,
) -> list[dict]:
    """Returns occupied lock slots, or an empty list when the device is offline."""
    if not lock_codes_profile.get("supported", True):
        return []

    if not _is_lock_device_reachable(device):
        _LOGGER.debug(
            "%s skipping lock code slots for offline device [entity: %s | device: %s]",
            LOG_PREFIX,
            entity_id,
            device.get("id"),
        )
        return []

    return await fetch_lock_code_slots(
        hass,
        entity_id,
        lock_codes_profile.get("api", LOCK_CODE_API_USERCODE),
        include_pins=LOCK_CODE_INVENTORY_INCLUDE_PINS,
    )


async def fetch_lock_code_slots(
    hass: HomeAssistant,
    entity_id: str,
    lock_api: str,
    *,
    include_pins: bool = False,
    code_slot: int | None = None,
) -> list[dict]:
    """Returns normalized lock user-code slots for credential or legacy APIs."""
    if lock_api == LOCK_CODE_API_CREDENTIAL:
        from .lock_user_mapper import fetch_lock_user_slots

        return await fetch_lock_user_slots(
            hass,
            entity_id,
            include_pins=include_pins,
        )

    try:
        from ..api.service_executor import execute_ha_service

        service_data: dict = {"entity_id": entity_id}
        if code_slot is not None:
            service_data["code_slot"] = code_slot

        response = await execute_ha_service(
            hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_GET_LOCK_USERCODE,
            service_data=service_data,
            return_response=True,
        )
    except Exception as err:
        _LOGGER.debug(
            "%s lock code slot query failed for %s: %s",
            LOG_PREFIX,
            entity_id,
            err,
        )
        return []

    return normalize_legacy_lock_code_slots(
        response,
        entity_id,
        include_pins=include_pins,
    )


def normalize_legacy_lock_code_slots(
    response: dict | None,
    entity_id: str,
    *,
    include_pins: bool,
) -> list[dict]:
    """Normalizes get_lock_usercode responses into a stable slot list."""
    if not isinstance(response, dict):
        return []

    slot_map = response.get(entity_id, response)
    if not isinstance(slot_map, dict):
        return []

    normalized_slots: list[dict] = []
    for slot_key, slot_data in slot_map.items():
        if not isinstance(slot_data, dict):
            continue

        try:
            parsed_code_slot = int(slot_key)
        except (TypeError, ValueError):
            continue

        slot_entry = {
            "code_slot": parsed_code_slot,
            "user_id": parsed_code_slot,
            "in_use": bool(slot_data.get("in_use", False)),
        }
        if include_pins:
            usercode = slot_data.get("usercode")
            slot_entry["usercode"] = str(usercode) if usercode else None

        normalized_slots.append(slot_entry)

    normalized_slots.sort(key=lambda item: item["code_slot"])
    return normalized_slots


def build_lock_device_map(devices: list[dict]) -> dict[str, dict]:
    """Returns device_id → lock_codes profile for devices that support PIN management."""
    lock_device_map: dict[str, dict] = {}

    for device in devices:
        lock_codes = device.get("lock_codes")
        if not lock_codes or not lock_codes.get("entity_id"):
            continue

        if not lock_codes.get("supported", True):
            continue

        lock_device_map[device["id"]] = lock_codes

    return lock_device_map


async def _query_credential_capabilities(
    hass: HomeAssistant,
    entity_id: str,
) -> dict | None:
    """Returns normalized capabilities when the modern credential API is available."""
    try:
        from ..api.service_executor import execute_ha_service

        response = await execute_ha_service(
            hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_GET_CREDENTIAL_CAPABILITIES,
            service_data={"entity_id": entity_id},
            return_response=True,
        )
    except Exception as err:
        _LOGGER.debug(
            "%s credential capabilities unavailable for %s: %s",
            LOG_PREFIX,
            entity_id,
            err,
        )
        return None

    entity_caps = _extract_entity_response(response, entity_id)
    if not entity_caps:
        return None

    pin_code_caps = entity_caps.get("supported_credential_types", {}).get("pin_code", {})
    max_slots = entity_caps.get("max_users") or pin_code_caps.get("num_slots")

    return {
        "entity_id": entity_id,
        "supported": bool(entity_caps.get("supports_user_management", True)),
        "api": LOCK_CODE_API_CREDENTIAL,
        "max_slots": max_slots,
        "min_pin_length": pin_code_caps.get("min_length", LOCK_CODE_MIN_PIN_LENGTH),
        "max_pin_length": pin_code_caps.get("max_length"),
        "supports_user_management": bool(entity_caps.get("supports_user_management")),
        "supported_user_types": entity_caps.get("supported_user_types") or [],
        "supported_credential_rules": entity_caps.get("supported_credential_rules") or [],
    }


async def _probe_legacy_usercode_api(hass: HomeAssistant, entity_id: str) -> bool:
    """Returns True when the legacy get_lock_usercode service responds for the lock."""
    try:
        from ..api.service_executor import execute_ha_service

        await execute_ha_service(
            hass,
            domain=ZWAVE_JS_DOMAIN,
            service=ZWAVE_JS_SERVICE_GET_LOCK_USERCODE,
            service_data={"entity_id": entity_id},
            return_response=True,
        )
        return True
    except Exception as err:
        _LOGGER.debug(
            "%s legacy usercode API unavailable for %s: %s",
            LOG_PREFIX,
            entity_id,
            err,
        )
        return False


def _extract_entity_response(response: dict | None, entity_id: str) -> dict | None:
    """Extracts per-entity payload from a zwave_js service response."""
    if not isinstance(response, dict):
        return None

    entity_caps = response.get(entity_id)
    if isinstance(entity_caps, dict):
        return entity_caps

    if len(response) == 1:
        only_value = next(iter(response.values()))
        if isinstance(only_value, dict):
            return only_value

    return None
