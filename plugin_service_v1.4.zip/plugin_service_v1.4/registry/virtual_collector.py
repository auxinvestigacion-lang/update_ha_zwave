"""Collects Home Assistant template helpers as virtual logical devices."""

import logging

from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

from ..const import LOG_PREFIX
from .device_enrichment import build_standalone_availability
from .device_filter import is_actionable_device, resolve_entity_device_class
from .payload_serialization import serialize_disabled_by, serialize_state_attributes
from .standalone_filter import (
    VIRTUAL_DEVICE_KIND,
    build_logical_device_id,
    is_virtual_device_entity,
    resolve_virtual_device_name,
)

_LOGGER = logging.getLogger(__name__)


def get_virtual_logical_ids_for_ha_device(
    hass: HomeAssistant,
    ha_device_id: str,
) -> list[str]:
    """Returns logical device ids for template helpers linked to a HA device."""
    device_reg = dr.async_get(hass)
    entity_reg = er.async_get(hass)
    logical_ids: list[str] = []

    for entry in er.async_entries_for_device(entity_reg, ha_device_id):
        if not _is_registrable_virtual_entity(entry, device_reg, entity_reg):
            continue
        logical_ids.append(build_logical_device_id(entry.entity_id))

    return logical_ids


def collect_virtual_devices(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
    area_name_map: dict[str, str],
) -> list[dict]:
    """Collects template helpers as one logical device per virtual entity."""
    device_reg = dr.async_get(hass)
    devices: list[dict] = []

    for entry in sorted(entity_reg.entities.values(), key=lambda item: item.entity_id):
        virtual_device = _build_virtual_device_if_registrable(
            hass, entry, device_reg, entity_reg, area_name_map
        )
        if virtual_device is not None:
            devices.append(virtual_device)

    _LOGGER.debug(
        "%s collected %d virtual logical device(s)",
        LOG_PREFIX,
        len(devices),
    )
    return devices


def build_virtual_entity_device_map(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
) -> dict[str, str]:
    """Returns entity_id → virtual device_id for registrable template helpers."""
    device_reg = dr.async_get(hass)
    tracking_map: dict[str, str] = {}

    for entry in entity_reg.entities.values():
        if not _is_registrable_virtual_entity(entry, device_reg, entity_reg):
            continue
        tracking_map[entry.entity_id] = build_logical_device_id(entry.entity_id)

    return tracking_map


def _build_virtual_device_if_registrable(
    hass: HomeAssistant,
    entry: er.RegistryEntry,
    device_reg: dr.DeviceRegistry,
    entity_reg: er.EntityRegistry,
    area_name_map: dict[str, str],
) -> dict | None:
    """Builds a virtual device payload when the template helper should be registered."""
    if not _is_registrable_virtual_entity(entry, device_reg, entity_reg):
        return None

    area_id = _resolve_virtual_area_id(entry, device_reg)
    return _build_virtual_device_payload(hass, entry, area_id, area_name_map)


def _build_virtual_device_payload(
    hass: HomeAssistant,
    entry: er.RegistryEntry,
    area_id: str | None,
    area_name_map: dict[str, str],
) -> dict:
    """Builds the logical device payload for one template helper."""
    return {
        "id": build_logical_device_id(entry.entity_id),
        "source": "standalone",
        "device_kind": VIRTUAL_DEVICE_KIND,
        "name": resolve_virtual_device_name(entry),
        "manufacturer": "Home Assistant",
        "model": "template",
        "model_id": None,
        "hw_version": None,
        "sw_version": None,
        "serial_number": None,
        "entry_type": "logical",
        "labels": sorted(entry.labels),
        "disabled_by": serialize_disabled_by(entry.disabled_by),
        "primary_domain": entry.domain,
        "area_id": area_id,
        "area_name": area_name_map.get(area_id) if area_id else None,
        "availability": build_standalone_availability(hass, entry),
        "entities": [_serialize_virtual_entity(hass, entry)],
    }


def _is_registrable_virtual_entity(
    entry: er.RegistryEntry,
    device_reg: dr.DeviceRegistry,
    entity_reg: er.EntityRegistry,
) -> bool:
    """Returns True when a template helper should be sent as its own virtual device."""
    if not is_virtual_device_entity(entry):
        return False

    if _belongs_to_actionable_physical_device(entry, device_reg, entity_reg):
        return False

    return _resolve_virtual_area_id(entry, device_reg) is not None


def _belongs_to_actionable_physical_device(
    entry: er.RegistryEntry,
    device_reg: dr.DeviceRegistry,
    entity_reg: er.EntityRegistry,
) -> bool:
    """Returns True when the helper is already attached to registrable hardware."""
    if entry.device_id is None:
        return False

    device = device_reg.async_get(entry.device_id)
    if device is None:
        return False

    device_entities = er.async_entries_for_device(entity_reg, device.id)
    return is_actionable_device(device, device_entities)


def _resolve_virtual_area_id(
    entry: er.RegistryEntry,
    device_reg: dr.DeviceRegistry,
) -> str | None:
    """Resolves area from the entity, then from a linked template-only device."""
    if entry.area_id is not None:
        return entry.area_id

    if entry.device_id is None:
        return None

    device = device_reg.async_get(entry.device_id)
    if device is None:
        return None

    return device.area_id


def _serialize_virtual_entity(hass: HomeAssistant, entry: er.RegistryEntry) -> dict:
    """Serializes a template helper entity for a virtual device payload."""
    state = hass.states.get(entry.entity_id)
    attributes = serialize_state_attributes(dict(state.attributes) if state else {})
    return {
        "entity_id": entry.entity_id,
        "domain": entry.domain,
        "name": resolve_virtual_device_name(entry),
        "platform": entry.platform,
        "entity_category": None,
        "device_class": resolve_entity_device_class(entry, attributes),
        "state": state.state if state else None,
        "attributes": attributes,
    }
