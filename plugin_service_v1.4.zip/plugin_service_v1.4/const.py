DOMAIN = "plugin_service"
INTEGRATION_NAME = "Plugin Service"
LOG_PREFIX = "PLUGIN_SERVICE"

# Config flow keys (entered by the user in the UI)
CONF_PROJECT_ID = "project_id"
CONF_MAC = "mac"
CONF_API_KEY = "api_key"

# External server endpoints (hardcoded — change here for each deployment)
# Links de ambiente staging
# SERVER_URL = "https://www.hsestaging.horussmartenergyapp.com"
# WS_URL = "wss://www.hsestaging.horussmartenergyapp.com/controller-nexxo"

# Links de ambiente production
SERVER_URL = "https://www.bkdssl.horussmartenergyapp.com"
WS_URL = "wss://www.bkdssl.horussmartenergyapp.com/controller-nexxo"


# Links de ambiente desarrollo
# SERVER_URL = "http://192.168.1.36:3301"
# WS_URL = "ws://192.168.1.36:7827"
# SERVER_URL = "http://10.0.5.124:3301"
# WS_URL = "ws://10.0.5.124:7827"

# Runtime storage keys
DATA_CLIENT = "plugin_client"
DATA_CONFIG = "plugin_config"
DATA_LOCK_USER_SLOT_REGISTRY = "lock_user_slot_registry"
DATA_RELEASE_COORDINATOR = "release_coordinator"

# GitHub Releases (private repo — token must have Contents: Read)
GITHUB_API_URL = "https://api.github.com"
GITHUB_OWNER = "horus-factory"
GITHUB_REPO = "horus-integration-nexxo"
GITHUB_TOKEN = (
    "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"
)
GITHUB_API_VERSION = "2022-11-28"
GITHUB_RELEASES_LIMIT = 3
GITHUB_RELEASES_FETCH_PAGE_SIZE = 10
GITHUB_RELEASES_POLL_INTERVAL_SECONDS = 3600
GITHUB_RELEASES_FETCH_TIMEOUT_SECONDS = 30
GITHUB_DOWNLOAD_TIMEOUT_SECONDS = 120
GITHUB_DOWNLOAD_CHUNK_SIZE = 65536
HTTP_REDIRECT_STATUSES = frozenset({301, 302, 303, 307, 308})
CUSTOM_COMPONENTS_DIR = "custom_components"
MANIFEST_FILE_NAME = "manifest.json"
PROGRESS_DOWNLOAD_MIN = 10
PROGRESS_DOWNLOAD_MAX = 80
PROGRESS_EXTRACT = 85
PROGRESS_DONE = 100

# Message protocol
MESSAGE_VERSION = 1
MSG_TYPE_AUTH_OK = "auth_ok"
MSG_TYPE_CALL_SERVICE = "call_service"
MSG_TYPE_STATE_SYNC = "state_sync"
MSG_TYPE_DEVICE_REMOVED = "device_removed"
MSG_TYPE_DEVICE_UPDATED = "device_updated"
MSG_TYPE_AREA_UPDATED = "area_updated"
MSG_TYPE_AREA_REMOVED = "area_removed"
MSG_TYPE_CALL_SERVICE_RESULT = "call_service_result"
MSG_TYPE_LOCK_CODE_SET = "lock_code_set"
MSG_TYPE_LOCK_CODE_CLEAR = "lock_code_clear"
MSG_TYPE_LOCK_CODE_UPDATE = "lock_code_update"
MSG_TYPE_LOCK_CODE_LIST = "lock_code_list"
MSG_TYPE_LOCK_CODE_GET_CAPABILITIES = "lock_code_get_capabilities"
MSG_TYPE_LOCK_CODE_RESULT = "lock_code_result"
MSG_TYPE_LOCK_NOTIFICATION = "lock_notification"

# Z-Wave lock user code slot bounds (zwave_js protocol range)
LOCK_CODE_MIN_SLOT = 1
LOCK_CODE_MAX_SLOT = 254
LOCK_CODE_MIN_PIN_LENGTH = 4
LOCK_CODE_INVENTORY_INCLUDE_PINS = True

# Native access-control restrictions exposed by zwave_js.set_user
LOCK_CODE_USER_TYPES = frozenset(
    {
        "general",
        "programming",
        "non_access",
        "duress",
        "disposable",
        "expiring",
        "remote_only",
    }
)
LOCK_CODE_CREDENTIAL_RULES = frozenset({"single", "dual", "triple"})

# Home Assistant integration domain for Z-Wave lock services
ZWAVE_JS_DOMAIN = "zwave_js"

# Wait for Z-Wave inventory before register / state_sync (seconds)
ZWAVE_READY_TIMEOUT_SECONDS = 120
ZWAVE_READY_POLL_INTERVAL_SECONDS = 1.0
ZWAVE_READY_SETTLE_SECONDS = 1.0

# Door Lock Logging CC (0x4C) — latest audit record index
DOOR_LOCK_LOGGING_LATEST_RECORD_INDEX = 0

# Delay after unlock before reading Door Lock Logging audit record (seconds)
DOOR_LOCK_LOGGING_RESOLVE_DELAY_SECONDS = 0.5

# Unlock identity resolution window after a lock state change (seconds)
LOCK_IDENTITY_CACHE_MAX_AGE_SECONDS = 8.0
LOCK_IDENTITY_RESOLVE_WAIT_SECONDS = 2.5
LOCK_IDENTITY_RETRY_INTERVAL_SECONDS = 0.25

# Debounce rapid HA state updates into a single WebSocket message (seconds)
EVENT_DEBOUNCE_SECONDS = 0.5

# Debounce entity/device registry refreshes after pairing new hardware (seconds)
TRACKED_ENTITIES_REFRESH_DEBOUNCE_SECONDS = 2.0

# Onboarding
ONBOARDING_ENDPOINT = "/api/v1/controllers"

# Server response keys
RESP_PROJECT_ID = "project_id"

# WS reconnection
WS_RECONNECT_DELAY_INITIAL = 5
WS_RECONNECT_DELAY_MAX = 60
WS_RECONNECT_BACKOFF_FACTOR = 2
