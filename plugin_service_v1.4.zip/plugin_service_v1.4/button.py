"""Platform button for Plugin Service.

Home Assistant requires a button.py file at the integration root when "button"
is declared in PLATFORMS.
"""

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CONF_MAC, DATA_CONFIG, DATA_RELEASE_COORDINATOR, DOMAIN
from .entity.install_release_button import InstallReleaseButton
from .entity.onboarding_button import OnboardingButton


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Registers onboarding and release-install buttons for this config entry."""
    entry_data = hass.data[DOMAIN][entry.entry_id]
    entry_config = entry_data[DATA_CONFIG]
    coordinator = entry_data[DATA_RELEASE_COORDINATOR]
    async_add_entities(
        [
            OnboardingButton(hass, entry_config, entry.entry_id),
            InstallReleaseButton(coordinator, entry_config[CONF_MAC]),
        ],
        update_before_add=False,
    )
