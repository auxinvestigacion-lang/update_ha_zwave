"""Shared Home Assistant device identity for Plugin Service gateway entities."""

from ..const import DOMAIN, INTEGRATION_NAME


def build_gateway_device_info(mac: str, sw_version: str | None = None) -> dict:
    """Builds the device registry payload shared by all Plugin Service entities."""
    device_info = {
        "identifiers": {(DOMAIN, mac)},
        "name": f"{INTEGRATION_NAME} [{mac}]",
        "manufacturer": INTEGRATION_NAME,
        "model": "Gateway ZW885",
    }
    if sw_version:
        device_info["sw_version"] = sw_version
    return device_info
