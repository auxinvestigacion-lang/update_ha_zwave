"""Select entity listing up to three GitHub releases."""

from homeassistant.components.select import SelectEntity
from homeassistant.const import EntityCategory
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from ..const import DOMAIN
from ..core.installed_version import normalize_version_tag
from ..core.release_coordinator import PluginReleaseCoordinator
from .gateway_device import build_gateway_device_info

_CURRENT_SUFFIX_EN = " (current)"
_CURRENT_SUFFIX_ES = " (instalada)"


def _strip_current_suffix(option: str) -> str:
    """Removes the installed-version marker from a select option."""
    for suffix in (_CURRENT_SUFFIX_EN, _CURRENT_SUFFIX_ES):
        if option.endswith(suffix):
            return option[: -len(suffix)]
    return option


class ReleaseSelect(CoordinatorEntity[PluginReleaseCoordinator], SelectEntity):
    """Lets the user pick one of the three newest GitHub releases."""

    _attr_has_entity_name = True
    _attr_translation_key = "release"
    _attr_icon = "mdi:tag-multiple"
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(self, coordinator: PluginReleaseCoordinator, mac: str) -> None:
        super().__init__(coordinator)
        self._mac = mac
        self._attr_unique_id = f"{DOMAIN}_{mac}_release"

    @property
    def device_info(self) -> dict:
        installed = self.coordinator.data.installed_version if self.coordinator.data else None
        return build_gateway_device_info(self._mac, installed)

    @property
    def available(self) -> bool:
        return bool(self.options)

    @property
    def options(self) -> list[str]:
        catalog = self.coordinator.data
        if not catalog or not catalog.tags:
            return []
        suffix = self._current_suffix()
        return [
            f"{tag}{suffix}" if tag == catalog.installed_version else tag
            for tag in catalog.tags
        ]

    @property
    def current_option(self) -> str | None:
        selected = self.coordinator.selected_tag
        for option in self.options:
            if _strip_current_suffix(option) == selected:
                return option
        return self.options[0] if self.options else None

    @property
    def extra_state_attributes(self) -> dict[str, str | bool | None]:
        installed = self.coordinator.data.installed_version if self.coordinator.data else None
        selected = _strip_current_suffix(self.current_option or "")
        return {
            "installed_version": installed,
            "is_current": selected == installed,
        }

    async def async_select_option(self, option: str) -> None:
        """Stores the tag that Install selected release will use."""
        self.coordinator.selected_tag = normalize_version_tag(
            _strip_current_suffix(option)
        )
        self.async_write_ha_state()

    def _current_suffix(self) -> str:
        """Returns a visible marker for the version already running on this gateway."""
        language = (self.hass.config.language or "en").lower()
        if language.startswith("es"):
            return _CURRENT_SUFFIX_ES
        return _CURRENT_SUFFIX_EN
