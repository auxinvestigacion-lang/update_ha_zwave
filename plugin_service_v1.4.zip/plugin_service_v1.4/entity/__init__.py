"""Home Assistant entities exposed by this integration."""
