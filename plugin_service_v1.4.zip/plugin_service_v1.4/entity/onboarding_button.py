"""Onboarding button entity for manual device synchronization."""

import logging

from homeassistant.components.button import ButtonEntity
from homeassistant.core import HomeAssistant

from ..api.onboarding import run_onboarding
from ..const import CONF_MAC, CONF_PROJECT_ID, DOMAIN, LOG_PREFIX
from ..core.entry_manager import apply_server_response, start_ws_client
from ..core.installed_version import read_installed_version_tag
from .gateway_device import build_gateway_device_info

_LOGGER = logging.getLogger(__name__)


class OnboardingButton(ButtonEntity):
    """Button that re-runs registration and starts the WebSocket if needed."""

    _attr_has_entity_name = True
    _attr_translation_key = "onboarding"
    _attr_icon = "mdi:cloud-upload"

    def __init__(self, hass: HomeAssistant, config: dict, entry_id: str) -> None:
        self.hass = hass
        self._config = config
        self._entry_id = entry_id
        self._attr_unique_id = f"{DOMAIN}_{config[CONF_MAC]}_onboarding"
        self._sw_version = read_installed_version_tag()

    @property
    def device_info(self):
        return build_gateway_device_info(self._config[CONF_MAC], self._sw_version)

    async def async_press(self) -> None:
        """Re-runs registration and connects the WebSocket on success."""
        _LOGGER.info(
            "%s synchronization started [project: %s | serial: %s]",
            LOG_PREFIX,
            self._config[CONF_PROJECT_ID],
            self._config[CONF_MAC],
        )

        server_response = await run_onboarding(self.hass, self._config)
        if not server_response:
            _LOGGER.error("%s synchronization failed — check the logs", LOG_PREFIX)
            return

        apply_server_response(self._config, server_response)
        await start_ws_client(self.hass, self._entry_id, self._config)
        _LOGGER.info("%s synchronization completed successfully", LOG_PREFIX)
