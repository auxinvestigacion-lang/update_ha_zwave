"""Button that installs the GitHub release currently selected in the list."""

from homeassistant.components.button import ButtonEntity
from homeassistant.const import EntityCategory
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from ..const import DOMAIN
from ..core.release_coordinator import PluginReleaseCoordinator
from .gateway_device import build_gateway_device_info


class InstallReleaseButton(CoordinatorEntity[PluginReleaseCoordinator], ButtonEntity):
    """Installs the selected GitHub tag after the user presses the button."""

    _attr_has_entity_name = True
    _attr_translation_key = "install_release"
    _attr_icon = "mdi:cloud-download"
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(self, coordinator: PluginReleaseCoordinator, mac: str) -> None:
        super().__init__(coordinator)
        self._mac = mac
        self._attr_unique_id = f"{DOMAIN}_{mac}_install_release"

    @property
    def device_info(self) -> dict:
        installed = self.coordinator.data.installed_version if self.coordinator.data else None
        return build_gateway_device_info(self._mac, installed)

    @property
    def available(self) -> bool:
        catalog = self.coordinator.data
        selected = self.coordinator.selected_tag
        if catalog is None or self.coordinator.is_installing:
            return False
        return bool(selected) and selected != catalog.installed_version

    async def async_press(self) -> None:
        """Installs the tag currently highlighted in the release list."""
        await self.coordinator.async_install_tag(self.coordinator.selected_tag)
