"""Diagnostic sensor for the version currently installed on disk."""

from homeassistant.components.sensor import SensorEntity
from homeassistant.const import EntityCategory
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from ..const import DOMAIN
from ..core.installed_version import read_installed_version_tag
from ..core.release_coordinator import PluginReleaseCoordinator
from .gateway_device import build_gateway_device_info


class InstalledVersionSensor(CoordinatorEntity[PluginReleaseCoordinator], SensorEntity):
    """Exposes the installed Plugin Service tag so the current version is obvious."""

    _attr_has_entity_name = True
    _attr_translation_key = "installed_version"
    _attr_icon = "mdi:package-variant"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, coordinator: PluginReleaseCoordinator, mac: str) -> None:
        super().__init__(coordinator)
        self._mac = mac
        self._attr_unique_id = f"{DOMAIN}_{mac}_installed_version"

    @property
    def device_info(self) -> dict:
        return build_gateway_device_info(self._mac, self.native_value)

    @property
    def available(self) -> bool:
        return True

    @property
    def native_value(self) -> str:
        if self.coordinator.data:
            return self.coordinator.data.installed_version
        return read_installed_version_tag()

    @property
    def extra_state_attributes(self) -> dict[str, str | bool | None]:
        latest = None
        if self.coordinator.data and self.coordinator.data.latest:
            latest = self.coordinator.data.latest.tag_name
        return {
            "latest_version": latest,
            "is_latest": self.native_value == latest,
        }
