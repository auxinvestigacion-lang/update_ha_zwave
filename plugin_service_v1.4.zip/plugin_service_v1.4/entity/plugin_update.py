"""Update entity that offers GitHub Releases for Plugin Service."""

from awesomeversion import AwesomeVersion
from homeassistant.components.update import (
    UpdateEntity,
    UpdateEntityFeature,
)
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from ..const import DOMAIN, INTEGRATION_NAME
from ..core.installed_version import read_installed_version_tag
from ..core.release_coordinator import PluginReleaseCoordinator, ReleaseCatalog
from .gateway_device import build_gateway_device_info


class PluginServiceUpdate(CoordinatorEntity[PluginReleaseCoordinator], UpdateEntity):
    """Shows the installed vs latest GitHub version and installs on confirmation."""

    _attr_has_entity_name = True
    _attr_name = None
    _attr_title = INTEGRATION_NAME
    _attr_supported_features = (
        UpdateEntityFeature.INSTALL
        | UpdateEntityFeature.SPECIFIC_VERSION
        | UpdateEntityFeature.RELEASE_NOTES
        | UpdateEntityFeature.PROGRESS
    )

    def __init__(self, coordinator: PluginReleaseCoordinator, mac: str) -> None:
        super().__init__(coordinator)
        self._mac = mac
        self._attr_unique_id = f"{DOMAIN}_{mac}_update"

    @property
    def device_info(self) -> dict:
        return build_gateway_device_info(self._mac, self.installed_version)

    @property
    def _catalog(self) -> ReleaseCatalog | None:
        return self.coordinator.data

    @property
    def available(self) -> bool:
        return self.coordinator.data is not None

    @property
    def installed_version(self) -> str | None:
        if self._catalog:
            return self._catalog.installed_version
        return read_installed_version_tag()

    @property
    def latest_version(self) -> str | None:
        if self._catalog and self._catalog.latest:
            return self._catalog.latest.tag_name
        return self.installed_version

    @property
    def release_url(self) -> str | None:
        if self._catalog and self._catalog.latest:
            return self._catalog.latest.html_url
        return None

    @property
    def release_summary(self) -> str | None:
        body = self._latest_body()
        if not body:
            return None
        return body[:255]

    @property
    def in_progress(self) -> bool:
        return self.coordinator.is_installing

    @property
    def update_percentage(self) -> int | None:
        return self.coordinator.install_percentage

    def version_is_newer(self, latest_version: str, installed_version: str) -> bool:
        """Compares GitHub tags and manifest versions that may include a v prefix."""
        return AwesomeVersion(latest_version) > AwesomeVersion(installed_version)

    async def async_release_notes(self) -> str | None:
        """Returns markdown release notes for the latest GitHub version."""
        return self._latest_body() or None

    async def async_install(self, version: str | None, backup: bool, **kwargs) -> None:
        """Installs a specific tag, or the latest GitHub release when omitted."""
        await self.coordinator.async_install_tag(version)

    def _latest_body(self) -> str:
        """Returns changelog text for the newest cached GitHub release."""
        if self._catalog and self._catalog.latest:
            return self._catalog.latest.body
        return ""
