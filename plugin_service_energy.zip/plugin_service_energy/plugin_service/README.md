# Plugin Service

Integración personalizada de Home Assistant que conecta una instancia local con un servidor remoto. Registra áreas, dispositivos y entidades, transmite cambios de estado en tiempo real y ejecuta comandos recibidos desde el servidor.

## Instalación

Copia esta carpeta como `plugin_service` dentro de `custom_components/` de Home Assistant:

```
config/
└── custom_components/
    └── plugin_service/     ← contenido de este repositorio
        ├── __init__.py
        ├── manifest.json
        ├── api/
        ├── registry/
        └── ...
```

Reinicia Home Assistant y agrega la integración desde **Configuración → Dispositivos y servicios → Agregar integración → Plugin Service**.

> **Migración desde `ws_bridge`:** elimina la integración antigua, renombra la carpeta a `plugin_service`, reinicia HA y vuelve a configurar la integración.

## Configuración

### Desde la UI (config flow)

| Campo | Descripción |
|---|---|
| Project ID | Identificador del proyecto en el servidor |
| MAC / Serial | Identificador único del gateway. Se guarda y envía solo con letras y números en minúsculas (`AA:BB:CC` → `aabbcc`) |
| Ambiente | `Staging`, `Production` o `Development` |

Para cambiar de servidor después de instalar: **Configuración → Dispositivos y servicios → Plugin Service → Configurar**. Al guardar, la integración se recarga, vuelve a registrarse y reconecta el WebSocket.

| Ambiente | URLs |
|---|---|
| Staging | Fijas (`hsestaging.horussmartenergyapp.com`) |
| Production | Fijas (`bkdssl.horussmartenergyapp.com`) |
| Development | Las que aparecen en el mismo formulario al elegir Development (HTTP + WebSocket) |

Las instalaciones que aún no tienen ambiente guardado usan **Production**.

## Flujo de operación

1. **Espera Z-Wave:** al iniciar, el plugin espera a que zwave_js tenga driver, nodos entrevistados y entidades en el state machine (máx. 120s).
2. **Registro (REST):** envía áreas, dispositivos y entidades al servidor.
3. **WebSocket:** tras registro exitoso, mantiene conexión persistente con el servidor.
4. **Sincronización (`state_sync`):** tras `auth_ok`, vuelve a comprobar Z-Wave y envía un snapshot con los estados actuales.
5. **Eventos:** publica `state_changed` cuando cambian dispositivos accionables, plugins blueprint o dispositivos virtuales.
6. **Inventario (WebSocket):** publica `device_updated`, `device_removed`, `area_updated` y `area_removed` cuando cambia metadata en HA (sin cache en memoria para áreas).
7. **Comandos:** recibe `call_service` del servidor y los ejecuta en Home Assistant.

### Filtrado

- **Dispositivos físicos:** solo hardware **Z-Wave** (`zwave_js`). El resto de integraciones (incluido Plugin Service, Cast, Tuya, MQTT, el hub **WiFi Module**) se omite **sin error**. También se excluyen Sun, Backup, controlador USB Z-Wave y entidades diagnostic/config del WebSocket. Un nodo Z-Wave **sin área** sí bloquea el registro y avisa.
- **Plugins:** el `entity_id` es la fuente de verdad (`plugin_hotel_` / `plugin_ocupacion_` / `plugin_aula_` / `bp_plugin_hotel_*` / `plugin_motel_*`). El nombre `Plugin Ocupación|Aula …` no basta si el `entity_id` está mal. Los helpers siguen `{tipo}_{familia}_{sitio}`: hotel/aula usan `state_hotel_hab_302` + `mode_` + `action_` (o `estado_`/`modo_`/`accion_`) en la **misma área**; motel usa un solo `state_motel_motel_89`. Varios plugins en una hab usan el sufijo `_2`, `_3`. Las satélites motel (`_ext` / `_semaforo`) se agrupan bajo `_main` (`plugin_motel_main_motel_89`). Si el contrato falla, falta el área o el servidor responde error, **no se registra nada**; el instalador ve el fallo en **Estado del registro** y en una notificación. Una automatización plugin en `off` **no bloquea**; se omite del inventario y se anuncia al instalador.
- **Dispositivos virtuales:** registra helpers `platform: template` (p. ej. `binary_sensor.sensor_mov_virtual`) como dispositivos lógicos propios (`device_kind: "virtual"`). Sin área también **bloquean** el registro.
- **Escenas:** automatizaciones `automation.escena_<sitio>` / `automation.scene_<sitio>` (o nombre `Escena|Scene …`) se omiten aunque compartan helpers con un plugin.
- **Excluido:** otras automatizaciones, scripts, scenes nativos de HA e `input_*` sin plugin.

Detalle completo en [docs/architecture.md](docs/architecture.md#reglas-de-filtrado).

## Estructura del proyecto

```
plugin_service/
├── __init__.py              # Entry point de la integración HA
├── manifest.json            # Metadatos requeridos por HA
├── config_flow.py           # Configuración desde la UI
├── const.py                 # Constantes globales
├── button.py                # Platform entry (requerido por HA en root)
├── strings.json             # Textos del config flow
├── translations/            # Traducciones (en, es)
│
├── api/                     # Comunicación con el servidor externo
│   ├── messages.py          # Envelope y builders de mensajes
│   ├── onboarding.py        # Registro REST
│   ├── server_error_text.py # Mensaje HTTP de fallo de registro
│   ├── registry_notifier.py # Cambios de inventario (device/area)
│   └── websocket_client.py  # Cliente WebSocket
│
├── registry/                # Lectura de registros de Home Assistant
│   ├── data_collector.py    # Recolección de áreas/dispositivos/entidades
│   ├── plugin_naming_contract.py  # Contrato de entity_id del plugin
│   ├── plugin_validation.py # Errores de contrato que bloquean el registro
│   ├── plugin_off_automation.py  # Aviso de plugins en off (no bloquea)
│   └── device_filter.py     # Filtrado de dispositivos accionables
│
├── entity/                  # Entidades expuestas por la integración
│   ├── onboarding_button.py # Botón "Sincronizar dispositivos"
│   └── registration_status_sensor.py  # OK/error del registro
│
├── core/                    # Orquestación interna
│   ├── entry_manager.py     # Ciclo de vida de config entries
│   ├── installer_notification.py  # Errores de plugin / aviso off / registro OK
│   └── registration_status.py     # Estado del último registro
│
└── docs/                    # Documentación
    ├── architecture.md      # Arquitectura y responsabilidades
    └── command-execution.md   # Protocolo de comandos
```

Ver [docs/architecture.md](docs/architecture.md) para detalle de cada módulo.

## Documentación

| Documento | Contenido |
|---|---|
| [architecture.md](docs/architecture.md) | Arquitectura, capas y responsabilidades |
| [command-execution.md](docs/command-execution.md) | Cómo enviar comandos a dispositivos |

## Desarrollo

### Requisitos

- Home Assistant 2024.x+
- Python 3.11+
- Dependencia: `aiohttp>=3.8.0` (declarada en `manifest.json`)

### Convenciones

- Archivos y carpetas: `kebab-case` o `snake_case` según contexto HA
- Constantes globales: `UPPER_SNAKE_CASE`
- Funciones: `snake_case` con verbo descriptivo
- Un concepto por archivo — sin módulos genéricos tipo `utils.py`
- Comentarios de funciones en inglés

### Despliegue en HA

Tras modificar el código, recarga la integración:

**Configuración → Dispositivos y servicios → Plugin Service → Recargar**

## Protocolo de mensajes

Todos los mensajes usan un envelope común:

```json
{
  "type": "register | auth | state_sync | state_changed | device_removed | device_updated | area_updated | area_removed | call_service",
  "version": 1,
  "project_id": "...",
  "serial": "...",
  "timestamp": "ISO-8601",
  "data": { }
}
```

## Licencia

Pendiente de definir.
