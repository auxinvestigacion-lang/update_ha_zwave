# Arquitectura — Plugin Service

## Visión general

Plugin Service actúa como **puente bidireccional** entre Home Assistant y un servidor remoto:

```
┌─────────────────┐         REST (register)         ┌─────────────────┐
│                 │ ──────────────────────────────► │                 │
│  Home Assistant │                                 │  Servidor remoto│
│                 │ ◄──────── WebSocket ──────────► │                 │
│ Plugin Service  │   auth, state_sync,             │   API + WS      │
│                 │   state_changed, call_service   │                 │
└─────────────────┘                                 └─────────────────┘
```

## Capas

### Root — Entry points de Home Assistant

Home Assistant exige ciertos archivos en la raíz de la integración. No mueven lógica de negocio.

| Archivo | Responsabilidad |
|---|---|
| `__init__.py` | Setup/unload de la integración; delega a `core/` |
| `manifest.json` | Metadatos, dependencias, versión |
| `config_flow.py` | Flujo de configuración UI (proyecto, serial y ambiente) |
| `const.py` | Constantes globales, catálogo de ambientes, tipos de mensaje |
| `button.py` | Entry point de la platform `button` |
| `strings.json` | Textos del config flow |

### `api/` — Comunicación externa

Todo lo que habla con el servidor remoto.

| Módulo | Responsabilidad |
|---|---|
| `messages.py` | Envelope estándar, builders de mensajes, diff de cambios |
| `onboarding.py` | POST de registro al endpoint REST |
| `websocket_client.py` | Conexión persistente, auth, eventos, call_service |

**Depende de:** `registry/` (para saber qué entidades trackear), `const.py`

### `registry/` — Datos de Home Assistant

Lee los registros oficiales de HA y aplica reglas de filtrado.

| Módulo | Responsabilidad |
|---|---|
| `device_filter.py` | Qué dispositivos/entidades son accionables vs excluidos |
| `device_enrichment.py` | Metadatos del dispositivo (manufacturer, model, availability) |
| `standalone_filter.py` | Reglas para entidades sin device_id (automation, script, helpers, virtuales) |
| `plugin_helper_contract.py` | Prefijos y parseo `{tipo}_{familia}_{sitio}` (`state_hotel_hab_302`, `state_motel_motel_89`) |
| `plugin_naming_contract.py` | Contrato de `entity_id` de plugin (fuente de verdad), detección por nombre y contrato de escenas (`escena_` / `scene_`) |
| `plugin_validation.py` | Incidencias de contrato que bloquean el registro |
| `plugin_off_automation.py` | Automatizaciones plugin en `off`: avisa, no bloquea |
| `missing_area_validation.py` | Hardware Z-Wave y virtuales sin área que bloquean el registro |
| `plugin_group_resolver.py` | Agrupa automatización + helpers por área e instancia |
| `plugin_family.py` | Roles motel (`_main`/`_ext`/`_semaforo`) y `plugin_family` |
| `plugin_grouper.py` | Serializa cada grupo como dispositivo lógico `plugin` |
| `standalone_collector.py` | Recolecta plugins agrupados y dispositivos virtuales como lógicos |
| `virtual_collector.py` | Recolecta helpers template como dispositivos virtuales |
| `data_collector.py` | Construye payload de registro y mapa de entidades trackeadas |
| `zwave_readiness.py` | Espera a que zwave_js tenga entities/estados listos antes de sync |

**Depende de:** `api/messages.py` (para el envelope de registro), `const.py`

**APIs HA usadas:**
- `area_registry.async_list_areas()`
- `device_registry.devices`
- `entity_registry.async_entries_for_device()`

### `entity/` — Entidades del plugin

Entidades que Plugin Service expone dentro de Home Assistant.

| Módulo | Responsabilidad |
|---|---|
| `onboarding_button.py` | Botón "Sincronizar dispositivos" / "Synchronize devices" para re-registro |
| `registration_status_sensor.py` | Estado OK/error del último registro (visible en el gateway) |

**Depende de:** `core/entry_manager.py`, `api/onboarding.py`

### `core/` — Orquestación interna

Coordinación del ciclo de vida sin depender de plataformas HA específicas.

| Módulo | Responsabilidad |
|---|---|
| `entry_manager.py` | Config de entry, registro, start/stop del WebSocket |
| `controller_serial.py` | Normaliza el serial a alfanumérico en minúsculas |
| `config_entry_migration.py` | Migración de entries (quita API key, normaliza serial) |
| `installer_notification.py` | Notificación persistente de errores, plugins en off o registro OK |
| `registration_status.py` | Último resultado de registro para el sensor del gateway |

**Depende de:** `api/onboarding.py`, `api/websocket_client.py`, `const.py`

## Flujo de datos

### Arranque (async_setup_entry)

```
__init__.py
  └─► core/entry_manager.build_entry_config()
  └─► button.py → entity/onboarding_button.OnboardingButton
  └─► (background task) core/entry_manager.register_and_start_client()
        ├─► registry/zwave_readiness.wait_for_zwave_inventory_ready()
        ├─► api/onboarding.run_onboarding()
        │     └─► registry/data_collector.build_registration_payload()
        │           └─► api/messages.build_register_message()
        └─► api/websocket_client.WSClient.start()
              └─► registry/data_collector.build_tracked_entity_map()
              └─► (on auth_ok) wait_for_zwave_inventory_ready()
                    └─► registry/data_collector.build_state_sync_payload()
```

`register` y `state_sync` esperan a que Z-Wave JS tenga el driver conectado y las
entidades presentes en el state machine (timeout 120s). Así se evita clasificar
motion sensors como switch cuando el nodo aún no restauró `device_class`.

Además, `device_class` usa fallback al entity registry (`device_class` /
`original_device_class`) si el state vivo llega vacío.

### Sincronización de estados (auth_ok → state_sync)

```
WebSocket auth → servidor responde auth_ok
  └─► api/websocket_client._send_state_snapshot()
        ├─► registry/zwave_readiness.wait_for_zwave_inventory_ready()
        └─► registry/data_collector.build_state_sync_payload()
              └─► api/messages.build_state_sync_message()
```

Se envía el inventario completo con estados actuales. El servidor actualiza sin requerir un nuevo POST REST en cada arranque.

### Cambio de estado (HA → Servidor)

```
HA event bus (state_changed)
  └─► api/websocket_client._queue_state_event()
        ├─► api/messages.extract_meaningful_changes()
        ├─► debounce (0.5s por entity_id)
        └─► api/messages.build_state_changed_message() → WebSocket
```

### Cambio de inventario (HA → Servidor)

```
HA event bus (device_registry_updated | entity_registry_updated | area_registry_updated)
  └─► api/registry_notifier.RegistryNotifier
        ├─► registry/registry_event_filter.py (solo dispositivos actionable)
        ├─► registry/registry_change_normalizer.py ({ old, new } para device/entity)
        ├─► debounce (2s por device_id / area_id)
        └─► device_removed | device_updated | area_updated | area_removed → WebSocket
```

`area_updated` lee `area_id` + `name` del area registry de HA al recibir el evento (HA no envía `changes` ni valor anterior).

Los `create` se ignoran; las altas las cubre `register` (REST) o `state_sync`.

### Comando (Servidor → HA)

```
WebSocket (call_service)
  └─► api/websocket_client._execute_service()
        └─► hass.services.async_call(domain, service, data)
              └─► HA event bus → state_changed → WebSocket (confirmación)
```

## Reglas de filtrado

### Dispositivos físicos (Z-Wave)

Definidas en `registry/device_filter.py`:

| Regla | Efecto |
|---|---|
| Plataforma distinta de `zwave_js` | Omite el resto de integraciones HA (Plugin Service, Cast, Tuya, MQTT, …) **sin error** |
| `is_integration_device()` | Excluye el propio dispositivo Plugin Service |
| `entry_type == "service"` | Excluye Sun, Backup, etc. |
| `EXCLUDED_DEVICE_PLATFORMS` | Excluye sun, backup, homeassistant, hassio, plugin_service |
| `entity_category != null` | Excluye diagnostic/config del tracking WebSocket (salvo medición y alertas de calor) |
| `_is_zwave_controller()` | Excluye controladores USB Z-Wave |
| `_is_integration_hub_device()` | Excluye hubs de integración (p. ej. **WiFi Module**) y dispositivos solo de conectividad |
| `area_id is None` | Hardware **Z-Wave** registrable **sin área**: no se envía; **bloquea** el registro y avisa al instalador |
| `switch` / `cover` / `button` con `entity_category: config` | **Incluidos** como entidades de control (cortinas Z-Wave) |
| Sensores de medición (`power` / `energy` / `voltage` / `current` / `temperature`) y alertas (`problem` / `heat` / `cold` / `safety`), incluso `diagnostic` | **Incluidos** — emiten eventos WS (switches con medidor, p. ej. Heavy Duty) |
| Sufijos `_ping`, `_identify`, `_firmware`, `_estado_del_nodo` | Excluidos del tracking WebSocket |

### Entidades standalone (plugins, helpers y dispositivos virtuales)

Definidas en `registry/standalone_filter.py`, `registry/plugin_helper_contract.py`, `registry/plugin_group_resolver.py`, `registry/plugin_naming_contract.py`, `registry/plugin_validation.py`, `registry/plugin_off_automation.py`, `registry/plugin_family.py`, `registry/plugin_grouper.py` y `registry/virtual_collector.py`.

Hay **dos familias lógicas**. El resto de automatizaciones, scripts, scenes e `input_*` huérfanos **no aparece** en el registro ni emite eventos WebSocket.

#### Qué entra al registro

| Tipo | Criterio | Ejemplo |
|---|---|---|
| Dispositivo físico | Pasa filtros de `device_filter.py` (**solo Z-Wave**) | `climate.aire`, `lock.cerradura` |
| Plugin agrupado | Helpers de contrato + automatización del mismo área | `logical:plugin:…`, `state_hotel_hab_302` / `state_motel_motel_89` |
| Dispositivo virtual | Helper `platform: template` con área, fuera de plugins | `logical:binary_sensor.sensor_mov_virtual` |

#### Cómo se detecta un plugin blueprint

El grupo lo siguen formando los helpers de contrato y el área. El **`entity_id` es la fuente de verdad** para aceptar el plugin (`plugin_naming_contract.py`). Solo se agrupan automatizaciones con `entity_id` de contrato; las **escenas** (`automation.escena_<sitio>` / `automation.scene_<sitio>`, o nombre `Escena|Scene …`) se omiten aunque referencien los mismos helpers. El nombre amigable de plugin **no basta**: si solo el nombre está bien, el registro falla. Un nombre tipo `Bp Plugin v1.2.3.4` es válido cuando el `entity_id` ya cumple el contrato.

`entity_id` aceptado:

| Familia exportada | `entity_id` |
|---|---|
| occupancy | `automation.plugin_hotel_<sitio>`, `automation.plugin_ocupacion_<sitio>`, `automation.plugin_aula_<sitio>` |
| occupancy (legado) | `automation.bp_plugin_hotel_*` |
| motel | `automation.plugin_motel_main` / `_ext` / `_semaforo` (también `plugin_motel_<rol>_<sitio>` y `plugin_motel_<n>_main`) |
| escena (omitida) | `automation.escena_<sitio>` o `automation.scene_<sitio>` |

El nombre `Plugin Ocupación|Aula|Motel <sitio>` solo se usa para **detectar** un plugin mal configurado y mostrar el error (p. ej. nombre correcto + `automation.luces_hab_202`). Aula se etiqueta `plugin_family: "occupancy"`.

Si hay cualquier fallo de contrato, **se bloquea todo el registro** y el instalador ve una notificación persistente con la automatización y el ajuste requerido.

Helpers y área (`plugin_helper_contract.py` + `plugin_group_resolver.py`):

| Criterio | Efecto |
|---|---|
| Helper `input_*` `{tipo}_{familia}_{sitio}` | Identifica el contrato: hotel/aula usan `state`/`mode`/`action`; motel solo `state_motel_motel_89` |
| Stem de habitación + instancia | `state_hotel_hab_302` = instancia 1; `state_hotel_hab_302_2` = instancia 2 en la misma hab |
| Automatización con `area_id` y estado `on` | Sin área no se envía; en `off` no se envía y se avisa |
| Referencias HA exclusivas a **un** grupo | Si referencia 401 y 402, es escena cruzada: se omite |
| `entity_id` `escena_` / `scene_` (o nombre `Escena|Scene`) | Se omite; no contamina el grupo del plugin ni lanza error |
| Misma `area_id` que sus helpers | La escena de AA sin área no se lleva los helpers del plugin |
| Familia + sitio del `entity_id` = helper | `plugin_hotel_hab_202` no puede ir con `state_hotel_hab_201` ni con helpers `aula`/`motel` (el legado `bp_plugin_hotel_*` no exige sitio) |

Dos plugins en la hab 302:

| Instancia | Helpers |
|---|---|
| 1 | `state_hotel_hab_302`, `action_hotel_hab_302`, `mode_hotel_hab_302` |
| 2 | `state_hotel_hab_302_2`, `action_hotel_hab_302_2`, `mode_hotel_hab_302_2` |

Motel (un helper): `input_select.state_motel_motel_89`. Las tres automatizaciones (`main` / `ext` / `semaforo`) cuelgan de ese helper.

Cada automatización solo entra al grupo de los helpers que referencia.

#### Familias y roles (ocupación vs motel)

Tras formar el grupo, `plugin_family` se etiqueta occupancy o motel. Las satélites motel (`_ext` / `_semaforo`) se pliegan al único grupo **motel** de su área cuando no referencian helpers. El rol se lee como token (`plugin_motel_main_motel_89` cuenta como `main`, no hace falta que el `entity_id` termine en `_main`).

| Escenario | Device lógico | `plugin_family` |
|---|---|---|
| Ocupación en E-401 | `logical:plugin:<automation_primaria>` | `occupancy` |
| Dos plugins en hab 302 | Dos devices (instancia 1 y `_2`) | `occupancy` |
| Motel `_main` + `_ext` + `_semaforo` | Un device anclado en `_main` | `motel` |

#### Dispositivos virtuales (helpers template)

Un helper de tipo **Template** (p. ej. un `binary_sensor` de movimiento virtual) **no es un plugin**. Se registra como dispositivo lógico propio:

| Criterio | Efecto |
|---|---|
| `platform == "template"` | Distingue el helper virtual de `input_*` de ocupación/motel |
| Dominio en `VIRTUAL_DEVICE_DOMAINS` (`binary_sensor`, `sensor`, `switch`, …) | Solo entidades que representan un dispositivo |
| Área en la entidad o en el device template | Misma regla que el hardware: sin área no se registra |
| Sin `device_id`, o device solo-template | Camino virtual (`device_kind: "virtual"`) |
| Template colgado de un dispositivo físico accionable | Se queda en el hardware; no se duplica como virtual |

```json
{
  "id": "logical:binary_sensor.sensor_mov_virtual",
  "source": "standalone",
  "device_kind": "virtual",
  "primary_domain": "binary_sensor"
}
```

Los `state_changed` usan ese `device_id`:

```json
{
  "type": "state_changed",
  "data": {
    "device_id": "logical:binary_sensor.sensor_mov_virtual",
    "entity_id": "binary_sensor.sensor_mov_virtual",
    "changes": { "state": { "old": "off", "new": "on" } }
  }
}
```

Los devices de HA que solo tienen entidades `template` se excluyen del inventario físico para no enviarlos dos veces ni clasificarlos como hardware.

Un rename del helper se publica como `device_updated` **a nivel dispositivo** (sin `entity_id`), con `changes.name`. HA suele cambiar `original_name` o el nombre del device template; ambos se resuelven al mismo `name` del inventario.

```json
{
  "type": "device_updated",
  "data": {
    "device_id": "logical:binary_sensor.sensor_mov_virtual",
    "changes": {
      "name": { "old": "Sensor mov virtual", "new": "Movimiento suite" }
    }
  }
}
```

#### Qué se excluye explícitamente

| Entidad | Motivo |
|---|---|
| Automatizaciones plugin en `off` | No se envían y **no bloquean**; se anuncian al instalador |
| Automatizaciones plugin-like en `on` con `entity_id` inválido, sin área o sin helpers de contrato | **Bloquea** el registro y notifica al instalador |
| Integraciones HA que no son Z-Wave (Plugin Service, Cast, …) | **Omitidas**; no bloquean aunque no tengan área |
| Dispositivo Z-Wave registrable sin área | **Bloquea** el registro y notifica al instalador |
| Dispositivo virtual (template) sin área | **Bloquea** el registro y notifica al instalador |
| Automatizaciones escena (`escena_` / `scene_`) | Fuera de alcance del bridge; no bloquean |
| Scripts y scenes nativos de HA | Fuera de alcance del bridge |
| Helpers `input_*` huérfanos (sin plugin detectado) | Evita ruido en el registro |
| Automatizaciones de sistema HA | Prefijos `automation.homeassistant_`, `script.homeassistant_` |
| Entidades con `device_id` en un dispositivo físico accionable | Ya van agrupadas como dispositivo físico |
| Entidades `diagnostic` / `config` | No emiten `state_changed` (excepto sensores de medición y alertas de calor) |

#### Identificadores del plugin agrupado

```json
{
  "id": "logical:plugin:plugin_motel_main",
  "source": "standalone",
  "device_kind": "plugin",
  "plugin_family": "motel",
  "primary_domain": "automation"
}
```

Las entidades del grupo (primario, satélites y helpers) comparten el mismo `device_id` en eventos WebSocket:

```json
{
  "type": "state_changed",
  "data": {
    "device_id": "logical:plugin:plugin_motel_main",
    "entity_id": "input_select.state_motel_motel_89",
    "changes": { "state": { "old": "Libre", "new": "Ocupado" } }
  }
}
```

#### Añadir otro plugin en el futuro

- `entity_id` de ocupación/aula: `plugin_hotel_<sitio>`, `plugin_ocupacion_<sitio>` o `plugin_aula_<sitio>`. El legado `bp_plugin_hotel_*` sigue válido.
- Helpers hotel/aula: `{state|mode|action}_{hotel|aula}_{hab}_{numero}` y `_2`, `_3`… si hay más de un plugin en la misma habitación. Motel: un helper `state_motel_motel_89`.
- La automatización debe estar en el **mismo área** y referenciar solo los helpers de su instancia.
- **Motel:** `plugin_motel_<rol>_<sitio>` (p. ej. `plugin_motel_main_motel_89`); el device se ancla en `main`. También vale el legado `plugin_motel_main` / `_ext` / `_semaforo` sin sitio.
- **Escenas:** `automation.escena_<sitio>` o `automation.scene_<sitio>` (nombre `Escena|Scene …`). Se omiten; no deben usar el prefijo `plugin_`.

#### Serialización del payload

Los `attributes` de entidades se sanitizan con el encoder JSON de Home Assistant (`registry/payload_serialization.py`) para evitar fallos con `datetime` u otros tipos no serializables.

## Almacenamiento en runtime

```python
hass.data["plugin_service"][entry_id] = {
    "plugin_config": { project_id, mac },
    "plugin_client": WSClient instance,
}
```

## Disponibilidad (`is_reachable`)

Definida en `registry/device_enrichment.py`:

| Situación | `is_reachable` | `status` |
|---|---|---|
| Dispositivo deshabilitado en HA | `false` | `disabled` |
| Nodo Z-Wave `alive` / `awake` / `asleep` | `true` | `online` / `sleeping` |
| Nodo Z-Wave `dead` / `failed` | `false` | `offline` |
| Arranque: entidades aún `unknown` / `unavailable` | `true` | `unknown` |
| Sensor de nodo sin cargar aún | usa fallback por entidades | no asume offline |

El `state_sync` post-`auth_ok` y el `register` REST esperan a que Z-Wave JS esté listo
(`registry/zwave_readiness.py`). Si el timeout expira, el sync continúa con un warning
y `device_class` puede recuperarse desde el entity registry.

## Decisiones de diseño

| Decisión | Razón |
|---|---|
| Catálogo de URLs en `const.py` + selector en la UI | Staging/Production fijos; Development pide URLs; instalaciones viejas usan Production |
| Envelope de mensajes unificado | Consistencia entre REST y WebSocket |
| Debounce de eventos | HA emite cascadas de state_changed por un solo cambio de usuario |
| Registro antes de WebSocket | El servidor necesita inventario antes de recibir eventos |
| `button.py` en root | Requisito de Home Assistant para platforms |
| Sin `utils.py` | Un concepto por archivo, responsabilidades claras |

## Qué agregar y dónde

| Necesidad | Ubicación |
|---|---|
| Nuevo tipo de mensaje | `api/messages.py` + `const.py` |
| Cambios de metadata de inventario | `api/registry_notifier.py` + `registry/registry_event_filter.py` |
| Nuevo filtro de dispositivo | `registry/device_filter.py` |
| Nuevo dispositivo virtual / helper template | `registry/standalone_filter.py` + `registry/virtual_collector.py` |
| Nueva entidad HA (sensor, etc.) | `entity/` + platform en root |
| Nuevo endpoint REST | `api/` (nuevo módulo o extender `onboarding.py`) |
| Lógica de setup/unload | `core/entry_manager.py` |
| Constante global | `const.py` |
| Documentación de protocolo | `docs/` |

## Limitaciones conocidas

- Sin respuesta `call_service_result` al servidor
- Sin validación de entidades controlables al recibir comandos
- Sin autenticación de comandos WebSocket
- Sin tests automatizados (pendiente)
