# Ejecución de comandos — Plugin Service

Documentación del protocolo para **enviar instrucciones desde el servidor hacia dispositivos** en Home Assistant a través del plugin Plugin Service.

---

## Concepto clave

Home Assistant **no controla dispositivos directamente**. Todo comando se ejecuta como un **servicio** (`domain.service`) sobre una **entidad** (`entity_id`).

```
Servidor  →  call_service (WebSocket)  →  Plugin Service  →  Home Assistant  →  Dispositivo
Dispositivo  →  Home Assistant  →  Plugin  →  state_changed (WebSocket)  →  Servidor
```

| Concepto | Descripción | Ejemplo |
|---|---|---|
| **Dominio** | Tipo de entidad / familia de servicios | `climate`, `lock`, `switch` |
| **Servicio** | Acción a ejecutar | `set_temperature`, `unlock`, `turn_on` |
| **entity_id** | Identificador único de la entidad | `climate.aire` |
| **service_data** | Parámetros del comando | `{ "temperature": 22 }` |

Referencia oficial: [Home Assistant — Service calls](https://www.home-assistant.io/docs/scripts/service-calls/)

---

## Flujo completo

```mermaid
sequenceDiagram
    participant Server as Servidor
    participant WS as WebSocket
    participant Plugin as Plugin Service (HA)
    participant HA as Home Assistant
    participant Device as Dispositivo

    Note over Server,Device: 1. Registro inicial (REST)
    Plugin->>Server: POST register (areas, devices, entities)

    Note over Server,Device: 2. Conexión persistente
    Plugin->>WS: auth
    WS-->>Plugin: auth_ok
    Plugin->>WS: state_sync (inventario + estados actuales)

    Note over Server,Device: 3. Ejecutar comando
    Server->>WS: call_service
    WS->>Plugin: call_service
    Plugin->>HA: hass.services.async_call(domain, service, data)
    HA->>Device: Comando Z-Wave / integración

    Note over Server,Device: 4. Confirmación del cambio
    Device-->>HA: Nuevo estado
    HA-->>Plugin: state_changed (event bus)
    Plugin-->>WS: state_changed (debounced)
    WS-->>Server: state_changed
```

### Pasos resumidos

1. **Registro (REST):** el plugin envía el inventario de áreas, dispositivos y entidades. Usa esa información para saber qué `entity_id` controlar.
2. **WebSocket conectado:** el plugin mantiene la conexión activa tras autenticarse.
3. **Sincronización:** tras `auth_ok`, envía `state_sync` con el inventario y estados actuales.
4. **Comando:** el servidor envía `call_service` con `domain`, `service` y `service_data`.
5. **Ejecución:** el plugin llama a Home Assistant de forma asíncrona (`blocking=false`).
6. **Confirmación:** no hay ACK directo hoy; el resultado llega como `state_changed` unos instantes después (con debounce de 0.5 s).

---

## Envelope estándar de mensajes

Todos los mensajes WebSocket comparten esta estructura:

```json
{
  "type": "<tipo_de_mensaje>",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-06-10T16:00:00.000000+00:00",
  "data": { }
}
```

| Campo | Tipo | Descripción |
|---|---|---|
| `type` | string | Tipo de mensaje (`auth`, `state_changed`, `call_service`, …) |
| `version` | int | Versión del protocolo (actualmente `1`) |
| `project_id` | string | ID del proyecto en el servidor |
| `serial` | string | MAC / serial del gateway |
| `timestamp` | string | ISO 8601 UTC |
| `data` | object | Contenido específico del mensaje |

### Tipos de mensaje

| Dirección | type | Descripción |
|---|---|---|
| Plugin → Servidor | `auth` | Autenticación al conectar |
| Servidor → Plugin | `auth_ok` | Confirmación de auth |
| Plugin → Servidor | `state_sync` | Snapshot de inventario y estados tras auth |
| Plugin → Servidor | `state_changed` | Cambio de estado de entidad |
| Plugin → Servidor | `device_removed` | Dispositivo actionable eliminado en HA |
| Plugin → Servidor | `device_updated` | Cambio de metadata de dispositivo o entidad |
| Plugin → Servidor | `area_updated` | Cambio de metadata de área |
| Plugin → Servidor | `area_removed` | Área eliminada en HA |
| Servidor → Plugin | `call_service` | Ejecutar comando en HA |
| Servidor → Plugin | `lock_code_set` | Programar PIN en cerradura Z-Wave |
| Servidor → Plugin | `lock_code_clear` | Borrar PIN de cerradura |
| Servidor → Plugin | `lock_code_update` | Actualizar restricciones de un PIN existente |
| Servidor → Plugin | `lock_code_list` | Listar usuarios/slots de cerradura |
| Servidor → Plugin | `lock_code_get_capabilities` | Consultar capacidades de PIN |
| Plugin → Servidor | `lock_code_result` | Resultado de gestión de PIN |
| Plugin → Servidor | `lock_notification` | Desbloqueo con `unlock_method` e identificación de PIN |
| Plugin → Servidor | `call_service_result` | Resultado de `call_service` con `request_id` |
| Protocolo WS | ping/pong | Keepalive (no es JSON, invisible en `on("message")`) |

---

## Mensaje `state_sync`

Tras `auth_ok`, el plugin envía un snapshot con la misma estructura de datos que el registro REST:

```json
{
  "type": "state_sync",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-06-22T12:00:00.000000+00:00",
  "data": {
    "areas": [ { "id": "salon", "name": "Salón" } ],
    "devices": [
      {
        "id": "df40bccc2e66b752b04908079fcc9e78",
        "source": "physical",
        "name": "Aire",
        "availability": { "status": "online", "is_reachable": true },
        "entities": [
          {
            "entity_id": "climate.aire",
            "domain": "climate",
            "state": "cool",
            "attributes": { "current_temperature": 24.8 }
          }
        ]
      }
    ]
  }
}
```

El servidor debe tratar `state_sync` como una actualización del inventario y estados actuales, sin requerir un nuevo POST REST en cada reconexión.

---

## Cambios de inventario (WebSocket)

Los altas (`create`) de dispositivos, entidades o áreas **no** se envían por WebSocket. El servidor debe descubrirlas con `register` (REST) o con un `state_sync` tras reconexión.

Las bajas y los cambios de metadata sí se publican en tiempo real:

| Evento HA | Mensaje WS |
|---|---|
| `device_registry_updated` → `remove` | `device_removed` |
| `device_registry_updated` → `update` | `device_updated` |
| `entity_registry_updated` → `update` | `device_updated` (con `entity_id`; virtuales sin `entity_id` si cambia el nombre) |
| `area_registry_updated` → `update` | `area_updated` |
| `area_registry_updated` → `remove` | `area_removed` |

Los mensajes usan debounce de 2 s.

- `device_updated` usa el mismo formato de `changes` que `state_changed`: `{ "campo": { "old": ..., "new": ... } }`.
- `area_updated` envía el nombre actual en `data.name` (sin `changes`; ver nota abajo).
- `device_removed` y `area_removed` solo incluyen el id del recurso.

**Nota:** a diferencia de device/entity registry, el evento HA `area_registry_updated` con `action: "update"` **no incluye** un dict `changes`. El plugin lee el nombre actual desde el area registry de HA al recibir el evento (sin cache en memoria).

### `device_removed`

```json
{
  "type": "device_removed",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-06-23T20:00:00.000000+00:00",
  "data": {
    "device_id": "df40bccc2e66b752b04908079fcc9e78"
  }
}
```

### `device_updated`

Cambio a nivel dispositivo:

```json
{
  "type": "device_updated",
  "data": {
    "device_id": "df40bccc2e66b752b04908079fcc9e78",
    "changes": {
      "name_by_user": { "old": "Aire", "new": "AC Dormitorio" },
      "area_id": { "old": "dormitorio", "new": "salon" },
      "disabled_by": { "old": null, "new": "user" }
    }
  }
}
```

Cambio a nivel entidad (mismo mensaje, con `entity_id`):

```json
{
  "type": "device_updated",
  "data": {
    "device_id": "df40bccc2e66b752b04908079fcc9e78",
    "entity_id": "switch.switch_triple",
    "changes": {
      "name": { "old": "Swicth 1", "new": "Luz techo" }
    }
  }
}
```

Rename de un dispositivo virtual (helper template). Va **sin** `entity_id` porque el nombre del inventario es el del dispositivo lógico:

```json
{
  "type": "device_updated",
  "data": {
    "device_id": "logical:binary_sensor.sensor_mov_virtual",
    "changes": {
      "name": { "old": "Sensor mov virtual", "new": "Movimiento suite" }
    }
  }
}
```

Campos propagados en `changes`:

| Origen | Campos |
|---|---|
| Device registry | `name`, `name_by_user`, `area_id`, `disabled_by`, `labels` |
| Entity registry | `name`, `name_by_user`, `area_id`, `disabled_by` |
| Helper template (virtual) | `name` (desde `name` u `original_name` del entity registry, o `name` / `name_by_user` del device template) |

### `area_updated`

```json
{
  "type": "area_updated",
  "data": {
    "area_id": "salon",
    "name": "Salón"
  }
}
```

El servidor debe actualizar el nombre del área por `area_id`. No se envía `old` porque HA no lo expone en el evento.

Si un dispositivo cambia de área, el evento va en `device_updated` (`changes.area_id`), no en `area_updated`.

### `area_removed`

```json
{
  "type": "area_removed",
  "data": {
    "area_id": "cocina"
  }
}
```

---

## Mensaje `call_service`

### Estructura

El servidor envía este mensaje por el WebSocket al plugin conectado:

```json
{
  "type": "call_service",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "data": {
    "domain": "climate",
    "service": "set_temperature",
    "service_data": {
      "entity_id": "climate.aire",
      "temperature": 22
    }
  }
}
```

### Campos de `data`

| Campo | Requerido | Descripción |
|---|---|---|
| `domain` | Sí | Dominio del servicio HA |
| `service` | Sí | Nombre del servicio |
| `service_data` | Sí* | Parámetros, incluyendo `entity_id` |

\* `entity_id` es obligatorio en la práctica para apuntar al dispositivo correcto.

### Formato mínimo (también soportado)

El plugin acepta el payload sin envelope completo por compatibilidad:

```json
{
  "type": "call_service",
  "data": {
    "domain": "switch",
    "service": "turn_on",
    "service_data": {
      "entity_id": "switch.switch_triple_3"
    }
  }
}
```

---

## Confirmación: mensaje `state_changed`

Tras ejecutar un comando, el plugin publica el nuevo estado:

```json
{
  "type": "state_changed",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-06-10T16:05:00.000000+00:00",
  "data": {
    "device_id": "df40bccc2e66b752b04908079fcc9e78",
    "entity_id": "climate.aire",
    "domain": "climate",
    "device_class": null,
    "state": { "old": "cool", "new": "cool" },
    "changes": {
      "temperature": { "old": 21, "new": 22 }
    }
  }
}
```

### Cómo interpretar `state` vs `changes`

| Campo | Significado |
|---|---|
| `data.state.old` / `data.state.new` | Valor principal de la entidad (modo HVAC, locked/unlocked, on/off) |
| `data.changes` | Solo lo que cambió; clave para detectar setpoints y atributos |

**Ejemplo climate:** al cambiar el setpoint, `state.old` y `state.new` pueden ser iguales (`"cool"`), pero `changes.temperature` refleja el cambio real.

---

## Qué dispositivos aceptan comandos

### Regla general

Un dispositivo es **controlable** si tiene al menos una entidad **primaria**:

```json
"entity_category": null
```

| entity_category | Controlable | Uso |
|---|---|---|
| `null` | **Sí** | Entidad principal (climate, lock, switch, …) |
| `"diagnostic"` | No* | Estado del nodo, batería, RSSI |
| `"config"` | No* | Ping, identify, firmware, modos internos |

\* El servicio técnicamente puede existir (ej. `button.press`), pero no son acciones de usuario típicas.

### Por dominio

| Dominio | ¿Acepta comandos? | Servicios habituales |
|---|---|---|
| `climate` | Sí | `set_temperature`, `set_hvac_mode`, `set_fan_mode`, `turn_off` |
| `lock` | Sí | `lock`, `unlock` |
| `switch` | Sí | `turn_on`, `turn_off`, `toggle` |
| `light` | Sí | `turn_on`, `turn_off`, `toggle` (+ brillo, color) |
| `cover` | Sí | `open_cover`, `close_cover`, `stop_cover` |
| `fan` | Sí | `turn_on`, `turn_off`, `set_percentage` |
| `button` | Parcial | `press` (identify, ping — mantenimiento) |
| `binary_sensor` | **No** | Solo lectura |
| `sensor` | **No** | Solo lectura |
| `event` | **No** | Solo lectura (notificaciones de escena/botón) |
| `update` | No recomendado | Actualización de firmware |

### Dispositivos excluidos del registro

El plugin **no registra ni monitoriza** estos dispositivos:

- Sun, Backup, Home Assistant core
- Controlador Z-Wave USB
- El propio dispositivo Plugin Service
- Dispositivos con `entry_type: "service"`
- Dispositivos sin entidades primarias

---

## Inventario de tu instalación

Basado en el payload de registro actual.

### Aire (`primary_domain: climate`)

| entity_id | ¿Controlable? | Notas |
|---|---|---|
| `climate.aire` | **Sí** | Entidad principal — termostato |
| `sensor.aire_air_temperature` | No | Solo lectura |
| `sensor.aire_humidity` | No | Solo lectura |
| `sensor.aire_estado_del_nodo` | No | diagnostic |
| `sensor.aire_battery_level` | No | diagnostic |
| `button.aire_ping` | No | config |
| `update.aire_firmware` | No | config |

**Modos HVAC disponibles:** `off`, `heat`, `cool`, `fan_only`, `dry`, `heat_cool`  
**Modos ventilador:** `Auto low`, `Low`, `High`, `Medium`  
**Rango temperatura:** 17 – 30 °C

---

### Cerradura (`primary_domain: lock`)

| entity_id | ¿Controlable? | Notas |
|---|---|---|
| `lock.cerradura` | **Sí** | Abrir / cerrar |
| `binary_sensor.cerradura_current_status_of_the_door` | No | Solo lectura (puerta abierta/cerrada) |
| `select.cerradura_current_lock_mode` | No | config |
| `sensor.cerradura_battery_level` | No | diagnostic |
| `button.cerradura_ping` | No | config |
| `button.cerradura_identify` | No | config |
| `update.cerradura_firmware` | No | config |

---

### Switch triple (`primary_domain: switch`)

| entity_id | ¿Controlable? | Notas |
|---|---|---|
| `switch.switch_triple` | **Sí** | Switch 1 |
| `switch.switch_triple_2` | **Sí** | Switch 2 |
| `switch.switch_triple_3` | **Sí** | Switch 3 |
| `event.switch_triple_scene_001` | No | Evento de botón físico |
| `event.switch_triple_scene_002` | No | Evento de botón físico |
| `event.switch_triple_scene_003` | No | Evento de botón físico |
| `event.switch_triple_scene_id*` | No | Evento de escena |
| `button.switch_triple_identify` | No | config |
| `update.switch_triple_firmware` | No | config |

---

### Door sensor (`primary_domain: binary_sensor`)

| entity_id | ¿Controlable? | Notas |
|---|---|---|
| `binary_sensor.door_sensor_*` | **No** | Solo lectura — puerta abierta/cerrada |
| Resto de entidades | No | diagnostic / config |

---

## Ejemplos de comandos

### Climate — Aire

**Setpoint 22 °C en modo cool:**

```json
{
  "type": "call_service",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "data": {
    "domain": "climate",
    "service": "set_temperature",
    "service_data": {
      "entity_id": "climate.aire",
      "temperature": 22,
      "hvac_mode": "cool"
    }
  }
}
```

**Apagar:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "climate",
    "service": "set_hvac_mode",
    "service_data": {
      "entity_id": "climate.aire",
      "hvac_mode": "off"
    }
  }
}
```

**Cambiar ventilador a Low:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "climate",
    "service": "set_fan_mode",
    "service_data": {
      "entity_id": "climate.aire",
      "fan_mode": "Low"
    }
  }
}
```

**Respuesta esperada (`state_changed`):**

```json
{
  "type": "state_changed",
  "data": {
    "entity_id": "climate.aire",
    "domain": "climate",
    "changes": {
      "temperature": { "old": 21, "new": 22 }
    }
  }
}
```

---

### Lock — Cerradura

**Desbloquear:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "lock",
    "service": "unlock",
    "service_data": {
      "entity_id": "lock.cerradura"
    }
  }
}
```

**Bloquear:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "lock",
    "service": "lock",
    "service_data": {
      "entity_id": "lock.cerradura"
    }
  }
}
```

**Respuesta esperada:**

```json
{
  "type": "state_changed",
  "data": {
    "entity_id": "lock.cerradura",
    "domain": "lock",
    "state": { "old": "locked", "new": "unlocked" },
    "changes": {
      "state": { "old": "locked", "new": "unlocked" }
    }
  }
}
```

---

### Switch — Switch triple

**Encender Switch 3:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "switch",
    "service": "turn_on",
    "service_data": {
      "entity_id": "switch.switch_triple_3"
    }
  }
}
```

**Apagar Switch 1:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "switch",
    "service": "turn_off",
    "service_data": {
      "entity_id": "switch.switch_triple"
    }
  }
}
```

**Alternar Switch 2:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "switch",
    "service": "toggle",
    "service_data": {
      "entity_id": "switch.switch_triple_2"
    }
  }
}
```

---

## Referencia rápida de servicios por dominio

| Dominio | Servicio | service_data típico |
|---|---|---|
| `climate` | `set_temperature` | `entity_id`, `temperature`, opcional `hvac_mode` |
| `climate` | `set_hvac_mode` | `entity_id`, `hvac_mode` |
| `climate` | `set_fan_mode` | `entity_id`, `fan_mode` |
| `lock` | `lock` | `entity_id` |
| `lock` | `unlock` | `entity_id` |
| `switch` | `turn_on` | `entity_id` |
| `switch` | `turn_off` | `entity_id` |
| `switch` | `toggle` | `entity_id` |
| `light` | `turn_on` | `entity_id`, opcional `brightness`, `rgb_color` |
| `light` | `turn_off` | `entity_id` |
| `cover` | `open_cover` | `entity_id` |
| `cover` | `close_cover` | `entity_id` |
| `button` | `press` | `entity_id` |

Documentación completa de servicios: [home-assistant.io/integrations](https://www.home-assistant.io/integrations/) → buscar la integración por dominio.

---

## Implementación en el servidor (Node.js)

```javascript
function sendCommand(socket, { domain, service, entityId, extra = {} }) {
  socket.send(JSON.stringify({
    type: "call_service",
    version: 1,
    project_id: "2",
    serial: "674384894949494",
    data: {
      domain,
      service,
      service_data: {
        entity_id: entityId,
        ...extra,
      },
    },
  }));
}

// Setpoint del aire a 22 °C
sendCommand(socket, {
  domain: "climate",
  service: "set_temperature",
  entityId: "climate.aire",
  extra: { temperature: 22, hvac_mode: "cool" },
});

// Encender switch 3
sendCommand(socket, {
  domain: "switch",
  service: "turn_on",
  entityId: "switch.switch_triple_3",
});
```

### Resolver entity_id desde el registro

Al recibir el mensaje `register`, indexa las entidades controlables:

```javascript
function getControllableEntities(devices) {
  const controllable = [];

  for (const device of devices) {
    for (const entity of device.entities) {
      if (entity.entity_category !== null) continue;

      const readOnlyDomains = ["sensor", "binary_sensor", "event"];
      if (readOnlyDomains.includes(entity.domain)) continue;

      controllable.push({
        device_id: device.id,
        device_name: device.name,
        entity_id: entity.entity_id,
        domain: entity.domain,
        primary_domain: device.primary_domain,
      });
    }
  }

  return controllable;
}
```

---

## Cómo identificar la entidad correcta

```
1. Buscar device_id o nombre del dispositivo en el registro
2. Filtrar entidades con entity_category = null
3. Descartar dominios de solo lectura (sensor, binary_sensor, event)
4. Usar primary_domain como guía:
   - climate  → climate.*
   - lock     → lock.*
   - switch   → switch.* (puede haber varias por dispositivo)
   - plugin   → `input_select.*`, `input_boolean.*` bajo `device_kind: "plugin"`
   - virtual  → entidad template bajo `device_kind: "virtual"` (`binary_sensor` / `sensor` son solo lectura)
```

---

## Qué se registra (y qué no)

El mensaje `register` incluye **tres familias** de dispositivos:

| Familia | `source` | Descripción |
|---|---|---|
| Físicos | `"physical"` | Hardware **Z-Wave** (`zwave_js`) con `device_id` en HA |
| Plugin blueprint | `"standalone"` + `device_kind: "plugin"` | Familia de automatizaciones plugin (ocupación o motel) + helpers `input_*` |
| Dispositivo virtual | `"standalone"` + `device_kind: "virtual"` | Helper template (p. ej. sensor de movimiento virtual) |

### Plugin agrupado

Un solo dispositivo lógico por **familia** de plugin (no por cada automatización):

**Ocupación** (`plugin_family: "occupancy"`):

```json
{
  "id": "logical:plugin:bp_plugin_hotel_v1_3_2_8",
  "device_kind": "plugin",
  "plugin_family": "occupancy",
  "entities": [
    { "entity_id": "automation.bp_plugin_hotel_v1_3_2_8", "domain": "automation" },
    { "entity_id": "input_select.state_hotel_hab_202", "domain": "input_select" },
    { "entity_id": "input_select.action_hotel_hab_202", "domain": "input_select" }
  ]
}
```

**Motel** (`plugin_family: "motel"`) — `main` + satélites `ext` / `semaforo` bajo el mismo device:

```json
{
  "id": "logical:plugin:plugin_motel_main",
  "device_kind": "plugin",
  "plugin_family": "motel",
  "entities": [
    { "entity_id": "automation.plugin_motel_ext", "domain": "automation" },
    { "entity_id": "automation.plugin_motel_main", "domain": "automation" },
    { "entity_id": "automation.plugin_motel_semaforo", "domain": "automation" },
    { "entity_id": "input_select.state_motel_motel_89", "domain": "input_select" }
  ]
}
```

Los eventos `state_changed` del plugin usan el mismo `device_id` aunque cambian distintas entidades (`input_select.state_motel_motel_89`, `automation.plugin_motel_*`, etc.).

### Dispositivo virtual (helper template)

Un helper de tipo Template **no pertenece al plugin**. Va como dispositivo lógico 1:1:

```json
{
  "id": "logical:binary_sensor.sensor_mov_virtual",
  "source": "standalone",
  "device_kind": "virtual",
  "primary_domain": "binary_sensor",
  "entities": [
    { "entity_id": "binary_sensor.sensor_mov_virtual", "domain": "binary_sensor", "platform": "template" }
  ]
}
```

Los `input_select` / `input_boolean` de ocupación y motel **no** usan este camino: siguen agrupados bajo `device_kind: "plugin"`.

### Excluido del registro

| Tipo | ¿Aparece en `register`? | ¿Emite `state_changed`? |
|---|---|---|
| Automatización nueva sin marcador plugin | No | No |
| Automatización escena (`escena_` / `scene_`) | No | No |
| Scripts / scenes nativos de HA | No | No |
| Integraciones HA que no son Z-Wave | No | No |
| Helpers `input_*` sueltos (sin plugin detectado) | No | No |
| Helper template virtual (con área) | Sí (`device_kind: "virtual"`) | Sí |
| Entidades diagnostic/config | Sí en registro físico | No en WebSocket |

**Detección del plugin:** `entity_id` de contrato (`plugin_hotel_` / `plugin_ocupacion_` / `plugin_aula_` / `bp_plugin_hotel_*` / `plugin_motel_*`) + helpers `{tipo}_{familia}_{sitio}` en la misma área (hotel/aula: `state_`/`mode_`/`action_`; motel: `state_motel_motel_89`). El nombre amigable no sustituye al `entity_id`. Un fallo de contrato bloquea el registro. Ver [architecture.md](architecture.md#entidades-standalone-plugins-helpers-y-dispositivos-virtuales).

### Comandos sobre el plugin

Para cambiar estado de ocupación desde el servidor:

```json
{
  "type": "call_service",
  "data": {
    "domain": "input_select",
    "service": "select_option",
    "service_data": {
      "entity_id": "input_select.state_hotel_hab_202",
      "option": "libre"
    }
  }
}
```

Servicios habituales: `input_select.select_option`, `input_boolean.turn_on` / `turn_off`.

### Cortina Z-Wave con medición de consumo (patrón real)

Dispositivos como el de tu captura suelen organizarse así en Home Assistant:

| Sección HA | Entidad típica | ¿Registro? | ¿Eventos WS? |
|---|---|---|---|
| **Controles → Curtain / Switch** | `cover.*` o `switch.*` | Sí | **Sí** |
| **Sensores → Electric Consumption** | `sensor.*` (power, energy, voltage, current) | Sí | **Sí** (medición en vivo) |
| **Sensores → Temperatura / Overheat** | `sensor.*` temperature, `binary_sensor.*` problem/heat | Sí | **Sí** |
| **Sensores → Alarm Level/Type** | `sensor.*` diagnostic genérico | Sí | No |
| **Ping** | `button.*_ping` | Sí | No |

El icono de rayo en Controles indica dominio **`switch`** (no `cover` con flechas). El plugin lo trackea aunque tenga `entity_category: config`.

Los sensores de consumo eléctrico (W, A, V, kWh), temperatura y alertas de overheat/underheat **sí emiten eventos** hacia el servidor.

| Entidad | ¿Trackea eventos? | Notas |
|---|---|---|
| `cover.curtain` | Sí | Estado `open` / `closed` / `opening` / `closing` y `current_position` |
| `switch.*` de subida/bajada | Sí | Incluso si `entity_category` es `config` |
| `sensor.*_estado_del_nodo` | No | diagnostic |
| `button.*_ping` / `*_identify` | No | mantenimiento |
| `update.*_firmware` | No | config |

**Comandos habituales:**

```json
{
  "type": "call_service",
  "data": {
    "domain": "cover",
    "service": "open_cover",
    "service_data": { "entity_id": "cover.curtain" }
  }
}
```

Servicios: `open_cover`, `close_cover`, `stop_cover`, `set_cover_position` (con `position` 0–100).

**Si no llegan eventos tras emparejar la cortina:**

1. Pulsa **Sincronizar dispositivos** (actualiza registro en servidor).
2. Revisa logs `PLUGIN_SERVICE added N trackable entities` — deberían aparecer `cover.*` o `switch.*` de la cortina.
3. Si solo cambia `last_changed` sin variar `state`, el evento incluye `changes.last_changed` (switches momentáneos).

---

## Códigos de cerradura Z-Wave

Las cerraduras Z-Wave con soporte de PIN se gestionan con mensajes semánticos dedicados. El plugin traduce estos comandos a servicios `zwave_js` (API legacy `usercode` o API moderna `credential`).

### `lock_codes` en `register` y `state_sync`

Los dispositivos lock incluyen un bloque `lock_codes` con capacidades y los slots ocupados (misma estructura que `lock_code_list` con `include_pins: true`):

```json
"lock_codes": {
  "entity_id": "lock.cerradura",
  "supported": true,
  "api": "credential",
  "max_slots": 50,
  "min_pin_length": 4,
  "max_pin_length": 10,
  "supports_user_management": true,
  "supported_user_types": ["general", "programming", "disposable", "expiring"],
  "supported_credential_rules": ["single"],
  "slots": [
    {
      "user_id": 4,
      "code_slot": 4,
      "credential_slots": [4],
      "in_use": true,
      "user_name": "Huésped 42",
      "active": true,
      "user_type": "general",
      "credential_rule": "single",
      "credentials": [
        {
          "type": "pin_code",
          "slot": 4
        }
      ]
    }
  ]
}
```

En API legacy `usercode`, cada slot incluye `usercode` cuando `in_use` es `true`. Las restricciones (`user_type`, `active`, `credential_rule`) solo aplican a API `credential`.

| Caso | `slots` |
|---|---|
| Cerradura online y responde | Lista de slots con credenciales (`credentials` o `usercode`) |
| Cerradura offline (`availability.is_reachable: false`) | `[]` — el servidor debe ignorarlo |
| Consulta Z-Wave falla | `[]` |
| API no soportada (`supported: false`) | `[]` |

**Nota:** en API `credential`, `get_users` puede devolver metadata del PIN (`type`, `slot`) sin el valor en claro, según el firmware. Usa `in_use` y la presencia de `credentials` para saber si el slot está programado.

### Restricciones nativas (API `credential`)

Home Assistant / Z-Wave JS **no** expone calendarios tipo “lunes–viernes 9:00–17:00” como servicio nativo. Lo que sí soporta la cerradura (si el firmware lo permite) son restricciones de **tipo de usuario** y estado:

| Campo | Valores | Efecto |
|---|---|---|
| `user_type` | `general`, `programming`, `non_access`, `duress`, `disposable`, `expiring`, `remote_only` | Comportamiento del usuario en la cerradura |
| `active` | `true` / `false` | Habilita o deshabilita el usuario sin borrar el PIN |
| `credential_rule` | `single`, `dual`, `triple` | Cuántas credenciales se exigen para abrir |

Significado de `user_type`:

| Valor | Descripción |
|---|---|
| `general` | Usuario normal (default) |
| `programming` | Puede programar la cerradura y abrir |
| `non_access` | Se reconoce, pero **no** abre (solo eventos) |
| `duress` | Abre y dispara alarma de coacción |
| `disposable` | Abre **una vez** y queda deshabilitado |
| `expiring` | Abre hasta que expire tras el primer uso (si el firmware lo soporta) |
| `remote_only` | Solo operación remota |

Los tipos disponibles por dispositivo vienen en `lock_codes.supported_user_types` (register / state_sync / `lock_code_get_capabilities`).

**Horarios / rango de fechas / N usos:** no son nativos en `zwave_js` para esta API. Si el negocio los necesita, el servidor debe implementar la lógica (activar/desactivar con `lock_code_update` + `active`) o usar una integración externa en HA.

### Flujo recomendado en el servidor

```mermaid
sequenceDiagram
    participant Server as Servidor
    participant Plugin as Plugin Service
    participant Lock as Cerradura

    Server->>Plugin: lock_code_set (code_slot, usercode, user_type?)
    Plugin->>Lock: Programar PIN + restricciones
    Plugin-->>Server: lock_code_result (code_slot, user_id, user_type)

    Server->>Plugin: lock_code_update (code_slot, active/user_type)
    Plugin->>Lock: set_user (restricciones)
    Plugin-->>Server: lock_code_result (action: update)

    Lock-->>Plugin: Desbloqueo con PIN
    Plugin-->>Server: lock_notification (unlock_method: access_code, user_id, code_slot)
```

**Importante:** en cerraduras con API `credential`, el `user_id` del audit log (ej. `204`) **no coincide** con el `user_id` de `get_users` (ej. `4`) ni necesariamente con `code_slot`. El servidor debe guardar el mapeo al recibir `lock_code_result` tras programar el PIN y resolver el huésped con la lógica de negocio adecuada.

### `lock_code_set` — Programar PIN

**Dirección:** Servidor → Plugin

```json
{
  "type": "lock_code_set",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "data": {
    "request_id": "req-set-pin-001",
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "code_slot": 3,
    "usercode": "1234",
    "user_name": "Huésped 42",
    "user_type": "disposable",
    "active": true,
    "credential_rule": "single"
  }
}
```

| Campo | Requerido | Descripción |
|---|---|---|
| `request_id` | Recomendado | ID de correlación para emparejar con `lock_code_result` |
| `device_id` | Sí | ID del dispositivo en el inventario (`register` / `state_sync`) |
| `code_slot` | Sí | Slot lógico donde programar el PIN (1–`max_slots`) |
| `usercode` | Sí | PIN numérico |
| `user_name` | No | Nombre del usuario en la cerradura (API credential) |
| `user_type` | No | Restricción de tipo (`general`, `disposable`, …) |
| `active` | No | `true`/`false` — habilitar o deshabilitar el usuario |
| `credential_rule` | No | `single`, `dual` o `triple` |
| `entity_id` | No | Override de la entidad lock; si se omite, usa la del inventario |

### `lock_code_update` — Actualizar restricciones

**Dirección:** Servidor → Plugin

Actualiza restricciones de un PIN **ya existente** sin reenviar el `usercode`. Requiere API `credential`.

```json
{
  "type": "lock_code_update",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "data": {
    "request_id": "req-update-001",
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "code_slot": 3,
    "user_type": "general",
    "active": false
  }
}
```

| Campo | Requerido | Descripción |
|---|---|---|
| `request_id` | Recomendado | ID de correlación |
| `device_id` | Sí | Dispositivo lock |
| `code_slot` | Sí | Slot del PIN existente |
| `user_type` | Condicional | Al menos uno de `user_type`, `active`, `credential_rule` o `user_name` |
| `active` | Condicional | Deshabilitar (`false`) o rehabilitar (`true`) sin borrar el PIN |
| `credential_rule` | Condicional | Regla de credenciales |
| `user_name` | Condicional | Renombrar el usuario en la cerradura |

**Ejemplos de uso en el servidor:**

| Caso de negocio | Comando |
|---|---|
| PIN de un solo uso (delivery) | `lock_code_set` con `user_type: "disposable"` |
| Suspender acceso del huésped | `lock_code_update` con `active: false` |
| Rehabilitar acceso | `lock_code_update` con `active: true` |
| Ventana horaria (software) | Servidor decide y envía `active` true/false según horario |

Respuesta (`action: update`):

```json
{
  "type": "lock_code_result",
  "data": {
    "request_id": "req-update-001",
    "action": "update",
    "success": true,
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "entity_id": "lock.cerradura",
    "code_slot": 3,
    "user_id": 3,
    "user_type": "general",
    "active": false
  }
}
```

### `lock_code_result` — Respuesta al programar PIN

**Dirección:** Plugin → Servidor

**Éxito:**

```json
{
  "type": "lock_code_result",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-07-07T16:40:00.000000+00:00",
  "data": {
    "request_id": "req-set-pin-001",
    "action": "set",
    "success": true,
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "entity_id": "lock.cerradura",
    "code_slot": 3,
    "user_id": 4
  }
}
```

| Campo | Descripción |
|---|---|
| `user_id` | ID de la API credential (`get_users`), **no** el audit ID del log |

**Error:**

```json
{
  "type": "lock_code_result",
  "data": {
    "request_id": "req-set-pin-001",
    "action": "set",
    "success": false,
    "error": "usercode must be at least 4 digits",
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662"
  }
}
```

| Campo | Descripción |
|---|---|
| `action` | `set`, `clear`, `update`, `list`, `get_capabilities` |
| `success` | `true` si la operación terminó correctamente |
| `code_slot` | Slot programado o consultado |
| `user_id` | ID credential de la cerradura (`get_users`); distinto del audit ID en `lock_notification` |
| `slots` | Lista de slots (solo en `action: list`) |
| `capabilities` | Perfil `lock_codes` (solo en `action: get_capabilities`) |
| `error` | Mensaje de error cuando `success` es `false` |

### `lock_code_clear` — Borrar PIN

```json
{
  "type": "lock_code_clear",
  "data": {
    "request_id": "req-clear-001",
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "code_slot": 3
  }
}
```

### `lock_code_list` — Listar usuarios/slots

```json
{
  "type": "lock_code_list",
  "data": {
    "request_id": "req-list-001",
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "include_pins": false
  }
}
```

Respuesta (`action: list`):

```json
{
  "type": "lock_code_result",
  "data": {
    "request_id": "req-list-001",
    "action": "list",
    "success": true,
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "slots": [
      {
        "user_id": 204,
        "code_slot": 3,
        "credential_slots": [3],
        "in_use": true
      }
    ]
  }
}
```

### `lock_notification` — Desbloqueo con método e identificación

**Dirección:** Plugin → Servidor (automático al detectar `locked → unlocked`)

El plugin clasifica **cómo** se abrió la cerradura antes de notificar. `user_id` y `code_slot` solo se envían cuando `unlock_method` es `access_code` o `master_code_access`.

**PIN en el teclado:**

```json
{
  "type": "lock_notification",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-07-07T16:51:27.746644+00:00",
  "data": {
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "entity_id": "lock.cerradura",
    "unlock_method": "access_code",
    "user_id": 204,
    "code_slot": 3,
    "event_label": "Unlocked via Access Code",
    "notification_type": "zwave_driver_log",
    "source": "zwave_driver_log",
    "parameters": {
      "userId": 204
    }
  }
}
```

**PIN maestro (`user ID` 1 o 2 en Door Lock Logging):**

```json
{
  "type": "lock_notification",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-08-26T17:34:12.284709+00:00",
  "data": {
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "entity_id": "lock.cerradura",
    "unlock_method": "master_code_access",
    "user_id": 1,
    "code_slot": 1,
    "event_label": "Unlocked via Access Code",
    "notification_type": "zwave_driver_log",
    "source": "zwave_driver_log",
    "parameters": {
      "userId": 1
    }
  }
}
```

**Comando remoto (`call_service` lock.unlock):**

```json
{
  "type": "lock_notification",
  "version": 1,
  "project_id": "2",
  "serial": "674384894949494",
  "timestamp": "2026-08-26T16:01:26.082053+00:00",
  "data": {
    "device_id": "2ac5c2f6fd9115fe1cfa06427daeb662",
    "entity_id": "lock.cerradura",
    "unlock_method": "remote_command",
    "user_id": null,
    "code_slot": null,
    "event_label": "Remote unlock",
    "notification_type": "call_service",
    "source": "call_service",
    "parameters": {}
  }
}
```

| Campo | Descripción |
|---|---|
| `unlock_method` | Cómo se abrió: `access_code`, `master_code_access`, `remote_command`, `manual`, `unknown` |
| `user_id` | ID del audit log Z-Wave; **solo** si el método es PIN (`access_code` o `master_code_access`) |
| `code_slot` | Slot lógico del PIN, si se pudo resolver vía `get_users`; `null` si no es PIN |
| `source` | Origen del dato de clasificación |
| `event_label` | Descripción legible; en remoto/manual no se reenvía el label mentiroso del firmware |
| `parameters` | Datos adicionales del evento Z-Wave |

**Valores de `unlock_method`:**

| `unlock_method` | Significado | `user_id` / `code_slot` |
|---|---|---|
| `access_code` | PIN de huésped/plataforma en el teclado | Presentes si se resolvieron |
| `master_code_access` | PIN maestro de fábrica (`user ID` 1 o 2 en Door Lock Logging) | `user_id` del audit (1 o 2) |
| `remote_command` | `lock.unlock` desde el servidor, HA u otro cliente | Siempre `null` |
| `manual` | Pomo / botón físico | Siempre `null` |
| `unknown` | Se abrió, sin evidencia suficiente | Siempre `null` |

**Cómo clasifica el plugin:**

1. Evidencia fuerte de teclado (`zwave_js_notification` keypad con `userId`) → `access_code` o `master_code_access` si el `userId` es 1 o 2.
2. `lock.unlock` ejecutado en HA en los últimos 20 s → `remote_command` (gana sobre logs que digan “Unlocked via Access Code”).
3. Notification CC / Door Lock Logging de RF o manual → `remote_command` o `manual`.
4. Pide el último registro Door Lock Logging **sin bloquear** y espera hasta 10 s el `RecordReport` en los driver logs. El PIN maestro llega así (`event type: Unlocked via Access Code`, `user ID: 1` o `2`). El RTC de esta cerradura queda en `2023-01-01`, así que no se usa el timestamp para descartar el registro. El auto-relock no cancela esa espera.
5. Audit log fresco de PIN, solo si no hay comando remoto pendiente → `access_code` o `master_code_access`.
6. Si no hay evidencia → `unknown`. Si el log del PIN llega después de ese `unknown` (hasta 15 s), se envía un segundo `lock_notification`; el servidor debe quedarse con el último.

**Resolución de huésped en el servidor:**

1. Si `unlock_method` es `master_code_access`, es el PIN maestro de la cerradura (`user_id` 1 o 2), no un huésped.
2. Si `unlock_method` no es `access_code`, **no** atribuir la apertura a un PIN de huésped.
3. Si es `access_code`, mantener tabla `device_id + audit_user_id → guest_id`, aprendida en el primer unlock tras check-in.
4. Usar `device_id + code_slot` como respaldo cuando `code_slot` no sea `null` (API `usercode`).

**Valores de `source`:**

| `source` | Significado |
|---|---|
| `call_service` | Correlacionado con `lock.unlock` de Home Assistant |
| `zwave_driver_log` | Extraído del log Z-Wave (Door Lock Logging) |
| `door_lock_logging` | Leído vía API Door Lock Logging CC |
| `zwave_js_notification` | Evento `zwave_js_notification` de Home Assistant |
| `lock_state_changed` | Solo cambio de estado; método `unknown` |

---

## Limitaciones actuales del plugin

| Funcionalidad | Estado |
|---|---|
| Recibir y ejecutar `call_service` | Implementado |
| Confirmación vía `state_changed` | Implementado |
| Debounce de eventos (0.5 s) | Implementado |
| Gestión de PIN (`lock_code_set/clear/update/list`) | Implementado |
| Notificación de desbloqueo (`lock_notification`) | Implementado (`unlock_method`) |
| Respuesta `lock_code_result` | Implementado |
| Respuesta `call_service_result` (con `request_id`) | Implementado |
| Envelope estándar en `call_service` entrante | Parcial (acepta con o sin envelope) |
| Validación de entidades controlables antes de ejecutar | **No implementado** |
| Autenticación de comandos | **No implementado** |
| Timeout / correlación comando ↔ respuesta | Parcial (`request_id` en lock codes y call_service) |
| Persistencia del mapeo `user_id → code_slot` tras reinicio HA | **No implementado** (el servidor debe guardarlo) |

Si el comando falla (entidad inexistente, servicio inválido), el error se registra en los logs de Home Assistant pero **no se envía al servidor**.

---

## Errores comunes

| Problema | Causa | Solución |
|---|---|---|
| Comando no surte efecto | `entity_id` incorrecto | Verificar en el payload `register` |
| Comando a entidad de solo lectura | `sensor.*`, `binary_sensor.*`, `event.*` | Usar la entidad primaria del dominio correcto |
| No llega confirmación | WebSocket desconectado | Verificar conexión y ping/pong |
| `state.old == state.new` en climate | Solo cambió un atributo | Revisar `changes.temperature`, no `state` |
| Varios `state_changed` por un comando | Cadena de actualizaciones en HA | Normal; el debounce los fusiona en uno (~0.5 s) |
| Comando enviado sin conexión WS | Plugin desconectado | El mensaje se pierde; no hay cola |
| Automatización nueva no aparece en registro | No coincide con marcadores de plugin | Solo entran plugins blueprint detectados; ver architecture.md |
| `state.old == state.new` en automation | Solo cambió un atributo (`last_triggered`, `current`) | Revisar `changes`, no `state` |

---

## Checklist para ejecutar un comando

- [ ] El plugin está conectado al WebSocket (`auth` → `auth_ok`)
- [ ] Tienes el `entity_id` del payload `register`
- [ ] La entidad tiene `entity_category: null`
- [ ] El dominio admite el servicio (`climate.set_temperature`, no `sensor.set_temperature`)
- [ ] Los parámetros son válidos (temperatura dentro de min/max, modos en `hvac_modes`)
- [ ] Esperas confirmación en `state_changed`, no un ACK directo

---

## Referencias

- [Home Assistant — Service calls](https://www.home-assistant.io/docs/scripts/service-calls/)
- [Home Assistant — WebSocket API (call_service)](https://developers.home-assistant.io/docs/api/websocket#calling-a-service-action)
- [Home Assistant — Entity categories](https://developers.home-assistant.io/docs/core/entity/#registry-properties)
- Código del plugin: `api/websocket_client.py` → `_execute_service()`
