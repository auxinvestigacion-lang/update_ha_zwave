"""Config flow for Plugin Service.

The user enters project_id, mac/serial and the target environment from the UI.
Development URLs appear on the same form when that environment is selected.
The serial is stored as alphanumeric lowercase (colons and other marks are dropped).
"""

import voluptuous as vol
from homeassistant import config_entries
from homeassistant.helpers.selector import (
    SelectSelector,
    SelectSelectorConfig,
    SelectSelectorMode,
    TextSelector,
    TextSelectorConfig,
    TextSelectorType,
)

from .const import (
    CONF_ENVIRONMENT,
    CONF_MAC,
    CONF_PROJECT_ID,
    CONF_SERVER_URL,
    CONF_WS_URL,
    DOMAIN,
    ENV_DEVELOPMENT,
    ENV_PRODUCTION,
    ENV_STAGING,
    HTTP_URL_SCHEMES,
    INTEGRATION_NAME,
    WS_URL_SCHEMES,
)
from .core.controller_serial import normalize_controller_serial


class _DevelopmentUrlSelector(TextSelector):
    """URL field shown only when the selected environment is development."""

    def serialize(self) -> dict:
        """Attaches a live visibility condition for the HA 2026.8+ form renderer."""
        serialized = dict(super().serialize())
        serialized["visible"] = {
            "field": CONF_ENVIRONMENT,
            "value": ENV_DEVELOPMENT,
        }
        return serialized


_DEVELOPMENT_URL_SELECTOR = _DevelopmentUrlSelector(
    TextSelectorConfig(type=TextSelectorType.URL)
)


def _environment_selector() -> SelectSelector:
    """Returns the environment dropdown used in config and options flows."""
    return SelectSelector(
        SelectSelectorConfig(
            options=[ENV_STAGING, ENV_PRODUCTION, ENV_DEVELOPMENT],
            mode=SelectSelectorMode.DROPDOWN,
            translation_key="environment",
        )
    )


def _required_field(key: str, current_value: str | None) -> object:
    """Returns a required marker, prefilled when a value already exists."""
    if current_value is not None:
        return vol.Required(key, default=current_value)
    return vol.Required(key)


def _optional_url_field(key: str, current_value: str) -> object:
    """Returns an optional URL marker, prefilled when a value already exists."""
    if current_value:
        return vol.Optional(key, description={"suggested_value": current_value})
    return vol.Optional(key)


def _schema_from_values(values: dict | None, include_mac: bool = True) -> vol.Schema:
    """Builds the form schema prefilled with the given values."""
    values = values or {}
    return _form_schema(
        project_id=values.get(CONF_PROJECT_ID),
        mac=values.get(CONF_MAC),
        environment=values.get(CONF_ENVIRONMENT, ENV_PRODUCTION),
        server_url=values.get(CONF_SERVER_URL, ""),
        ws_url=values.get(CONF_WS_URL, ""),
        include_mac=include_mac,
    )


def _form_schema(
    *,
    project_id: str | None = None,
    mac: str | None = None,
    environment: str = ENV_PRODUCTION,
    server_url: str = "",
    ws_url: str = "",
    include_mac: bool = True,
) -> vol.Schema:
    """Builds the single-page schema for config and options flows."""
    fields: dict = {_required_field(CONF_PROJECT_ID, project_id): str}
    if include_mac:
        fields[_required_field(CONF_MAC, mac)] = str
    fields[vol.Required(CONF_ENVIRONMENT, default=environment)] = _environment_selector()
    fields[_optional_url_field(CONF_SERVER_URL, server_url)] = _DEVELOPMENT_URL_SELECTOR
    fields[_optional_url_field(CONF_WS_URL, ws_url)] = _DEVELOPMENT_URL_SELECTOR
    return vol.Schema(fields)


def validate_development_urls(server_url: str, ws_url: str) -> dict[str, str]:
    """Returns form errors when development URLs are missing or malformed."""
    errors: dict[str, str] = {}
    if not server_url.startswith(HTTP_URL_SCHEMES):
        errors[CONF_SERVER_URL] = "invalid_server_url"
    if not ws_url.startswith(WS_URL_SCHEMES):
        errors[CONF_WS_URL] = "invalid_ws_url"
    return errors


def _validate_user_input(user_input: dict) -> dict[str, str]:
    """Validates development URLs only when that environment is selected."""
    if user_input[CONF_ENVIRONMENT] != ENV_DEVELOPMENT:
        return {}
    return validate_development_urls(
        user_input.get(CONF_SERVER_URL, "").strip(),
        user_input.get(CONF_WS_URL, "").strip(),
    )


def _normalized_development_urls(user_input: dict) -> dict[str, str]:
    """Returns stripped development URLs from submitted form data."""
    return {
        CONF_SERVER_URL: user_input.get(CONF_SERVER_URL, "").strip().rstrip("/"),
        CONF_WS_URL: user_input.get(CONF_WS_URL, "").strip().rstrip("/"),
    }


class PluginServiceConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Config flow for Plugin Service."""

    VERSION = 2

    async def async_step_user(self, user_input=None):
        errors = {}

        if user_input is not None:
            serial = normalize_controller_serial(user_input.get(CONF_MAC, ""))
            if not serial:
                errors[CONF_MAC] = "invalid_serial"
            else:
                user_input = {**user_input, CONF_MAC: serial}
                await self.async_set_unique_id(serial)
                self._abort_if_unique_id_configured()
                errors = _validate_user_input(user_input)
                if not errors:
                    self._user_input = user_input
                    if user_input[CONF_ENVIRONMENT] == ENV_DEVELOPMENT:
                        self._user_input.update(_normalized_development_urls(user_input))
                    return self._create_config_entry()

        return self.async_show_form(
            step_id="user",
            data_schema=_schema_from_values(user_input),
            errors=errors,
        )

    def _create_config_entry(self):
        """Creates the config entry from the collected user input."""
        mac = self._user_input[CONF_MAC]
        data = {
            CONF_PROJECT_ID: self._user_input[CONF_PROJECT_ID],
            CONF_MAC: mac,
            CONF_ENVIRONMENT: self._user_input[CONF_ENVIRONMENT],
        }
        if self._user_input[CONF_ENVIRONMENT] == ENV_DEVELOPMENT:
            data[CONF_SERVER_URL] = self._user_input[CONF_SERVER_URL]
            data[CONF_WS_URL] = self._user_input[CONF_WS_URL]
        return self.async_create_entry(
            title=f"{INTEGRATION_NAME} [{mac}]",
            data=data,
        )

    @staticmethod
    def async_get_options_flow(config_entry):
        """Allows editing project, environment and development URLs without removing the integration."""
        return PluginServiceOptionsFlow()


class PluginServiceOptionsFlow(config_entries.OptionsFlow):
    """Options flow: project, environment, and optional development URLs."""

    async def async_step_init(self, user_input=None):
        errors = {}

        if user_input is not None:
            errors = _validate_user_input(user_input)
            if not errors:
                return self.async_create_entry(
                    title="", data=self._build_options(user_input)
                )

        values = user_input or {
            CONF_PROJECT_ID: self._current_value(CONF_PROJECT_ID),
            CONF_ENVIRONMENT: self._current_value(CONF_ENVIRONMENT, ENV_PRODUCTION),
            CONF_SERVER_URL: self._current_value(CONF_SERVER_URL),
            CONF_WS_URL: self._current_value(CONF_WS_URL),
        }
        return self.async_show_form(
            step_id="init",
            data_schema=_schema_from_values(values, include_mac=False),
            errors=errors,
        )

    def _current_value(self, key: str, default: str = "") -> str:
        """Returns the latest saved value for a config key."""
        return self.config_entry.options.get(
            key, self.config_entry.data.get(key, default)
        )

    def _build_options(self, user_input: dict) -> dict:
        """Builds the options payload, keeping previous development URLs."""
        options = {
            CONF_PROJECT_ID: user_input[CONF_PROJECT_ID],
            CONF_ENVIRONMENT: user_input[CONF_ENVIRONMENT],
        }
        previous_server = self._current_value(CONF_SERVER_URL)
        previous_ws = self._current_value(CONF_WS_URL)
        if previous_server:
            options[CONF_SERVER_URL] = previous_server
        if previous_ws:
            options[CONF_WS_URL] = previous_ws
        if user_input[CONF_ENVIRONMENT] == ENV_DEVELOPMENT:
            options.update(_normalized_development_urls(user_input))
        return options
