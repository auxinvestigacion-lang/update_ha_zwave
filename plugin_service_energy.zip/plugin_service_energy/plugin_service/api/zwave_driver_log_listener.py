"""Captures Door Lock Logging audit records from Z-Wave JS driver logs."""

import logging
import re
from collections.abc import Callable

from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import device_registry as dr
from zwave_js_server.const import CommandClass

from ..const import (
    LOCK_NOTIFICATION_SOURCE_ZWAVE_DRIVER_LOG,
    LOG_PREFIX,
    UNLOCK_METHOD_ACCESS_CODE,
)
from .lock_unlock_classifier import (
    ACCESS_CODE_LABEL_MARKERS,
    MANUAL_LABEL_MARKERS,
    REMOTE_LABEL_MARKERS,
    apply_master_code_method,
    classify_method_from_door_lock_logging,
    classify_method_from_label,
    is_access_code_unlock,
)
from .lock_unlock_identity_cache import LockUnlockIdentity, LockUnlockIdentityCache

_LOGGER = logging.getLogger(__name__)

USER_ID_LOG_PATTERN = re.compile(r"user\s*id\s*[:=]\s*(\d+)", re.IGNORECASE)
EVENT_TYPE_LOG_PATTERN = re.compile(r"event\s*type\s*[:=]\s*(.+)", re.IGNORECASE)
UNLOCK_LOG_LABEL_MARKERS = (
    ACCESS_CODE_LABEL_MARKERS + REMOTE_LABEL_MARKERS + MANUAL_LABEL_MARKERS
)


class ZwaveDriverLogListener:
    """Parses Door Lock Logging lines from Z-Wave JS driver log events."""

    def __init__(
        self,
        hass: HomeAssistant,
        identity_cache: LockUnlockIdentityCache,
        get_lock_device_map: Callable[[], dict[str, dict]],
        on_identity_stored: Callable[[str], None] | None = None,
    ) -> None:
        self._hass = hass
        self._identity_cache = identity_cache
        self._get_lock_device_map = get_lock_device_map
        self._on_identity_stored = on_identity_stored
        self._driver_unsub = None
        self._log_listener_started = False

    def subscribe(self) -> None:
        """Subscribes to Z-Wave JS driver logging events."""
        if self._driver_unsub is not None:
            return

        client = _get_zwave_client(self._hass)
        if client is None or client.driver is None:
            _LOGGER.warning("%s zwave_js client unavailable for driver log listener", LOG_PREFIX)
            return

        self._ensure_log_stream(client)

        @callback
        def _on_driver_log(event: dict) -> None:
            self._handle_driver_log(client.driver, event)

        self._driver_unsub = client.driver.on("logging", _on_driver_log)
        _LOGGER.info("%s subscribed to Z-Wave driver logs for lock audit records", LOG_PREFIX)

    def unsubscribe(self) -> None:
        """Unsubscribes from Z-Wave JS driver logging events."""
        if self._driver_unsub:
            self._driver_unsub()
            self._driver_unsub = None

    def _ensure_log_stream(self, client) -> None:
        """Starts the Z-Wave JS log stream once for this HA session."""
        if self._log_listener_started:
            return

        async def _start_logs() -> None:
            try:
                await client.async_start_listening_logs()
                self._log_listener_started = True
            except Exception as err:
                _LOGGER.warning("%s failed to start Z-Wave log stream: %s", LOG_PREFIX, err)

        self._hass.async_create_task(_start_logs())

    def _handle_driver_log(self, driver, event: dict) -> None:
        """Parses a driver log event and stores unlock identities for tracked locks."""
        log_message = event.get("log_message")
        if log_message is None:
            return

        context = getattr(log_message, "context", None)
        node_id = getattr(context, "node_id", None) if context is not None else None
        command_class = getattr(context, "command_class", None) if context is not None else None
        message_blob = _build_log_blob(log_message)
        if not message_blob or not _is_door_lock_logging_message(command_class, message_blob):
            return

        self._store_unlock_from_log_blob(driver, node_id, log_message, message_blob)

    def _store_unlock_from_log_blob(self, driver, node_id, log_message, message_blob: str) -> None:
        """Stores a classified unlock identity extracted from one driver log blob."""
        if node_id is None:
            node_id = _extract_node_id_from_tags(
                getattr(log_message, "primary_tags", None),
                message_blob,
            )
        if node_id is None:
            return

        device_id = _resolve_device_id_for_node(self._hass, driver, node_id)
        if device_id is None or device_id not in self._get_lock_device_map():
            return

        user_id = _extract_user_id_from_log(message_blob)
        event_label = _extract_event_label_from_log(message_blob)
        unlock_method = _classify_driver_log_unlock_method(
            event_label, message_blob, user_id
        )
        if unlock_method is None:
            return
        if is_access_code_unlock(unlock_method) and user_id is None:
            return

        self._identity_cache.store(
            device_id,
            LockUnlockIdentity(
                source=LOCK_NOTIFICATION_SOURCE_ZWAVE_DRIVER_LOG,
                user_id=user_id,
                event_label=event_label,
                parameters={"userId": user_id} if user_id is not None else {},
                unlock_method=unlock_method,
            ),
        )
        _LOGGER.info(
            "%s captured unlock from Z-Wave log [device: %s | node: %s | method: %s | user_id: %s]",
            LOG_PREFIX,
            device_id,
            node_id,
            unlock_method,
            user_id,
        )
        if self._on_identity_stored is not None:
            self._on_identity_stored(device_id)


def _classify_driver_log_unlock_method(
    event_label: str | None,
    message_blob: str,
    user_id: int | None,
) -> str | None:
    """Classifies a driver log unlock, using user id when the label is generic."""
    unlock_method = classify_method_from_door_lock_logging(None, event_label, user_id)
    if unlock_method is not None:
        return unlock_method

    unlock_method = classify_method_from_label(message_blob)
    if unlock_method is not None:
        return apply_master_code_method(unlock_method, user_id)

    if user_id is not None:
        return apply_master_code_method(UNLOCK_METHOD_ACCESS_CODE, user_id)
    return None


def _get_zwave_client(hass: HomeAssistant):
    """Returns the first loaded zwave_js client, when available."""
    from homeassistant.components.zwave_js import DOMAIN
    from homeassistant.config_entries import ConfigEntryState

    for entry in hass.config_entries.async_entries(DOMAIN):
        if entry.state is not ConfigEntryState.LOADED:
            continue
        runtime_data = entry.runtime_data
        client = getattr(runtime_data, "client", None)
        if client is not None:
            return client

    return None


def _resolve_device_id_for_node(hass: HomeAssistant, driver, node_id: int) -> str | None:
    """Maps a Z-Wave node ID to a Home Assistant device_id."""
    from homeassistant.components.zwave_js.helpers import get_device_id

    node = driver.controller.nodes.get(node_id)
    if node is None:
        return None

    device_registry = dr.async_get(hass)
    device = device_registry.async_get_device(identifiers={get_device_id(driver, node)})
    return device.id if device is not None else None


def _is_door_lock_logging_message(command_class, message_blob: str) -> bool:
    """Returns True when a log message looks like a Door Lock Logging audit record."""
    if command_class == CommandClass.DOOR_LOCK_LOGGING:
        return True

    normalized_blob = message_blob.casefold()
    if "doorlocklogging" in normalized_blob:
        return True
    if _extract_user_id_from_log(message_blob) is not None:
        return True

    return any(marker in normalized_blob for marker in UNLOCK_LOG_LABEL_MARKERS)


def _extract_user_id_from_log(message_blob: str) -> int | None:
    """Extracts the numeric user ID from a Door Lock Logging log block."""
    match = USER_ID_LOG_PATTERN.search(message_blob)
    if match is None:
        return None

    try:
        return int(match.group(1))
    except ValueError:
        return None


def _build_log_blob(log_message) -> str:
    """Joins formatted and raw log lines so nested CC reports are searchable."""
    blob_lines: list[str] = []
    blob_lines.extend(_coerce_log_lines(getattr(log_message, "formatted_message", None)))
    blob_lines.extend(_coerce_log_lines(getattr(log_message, "message", None)))
    primary_tags = getattr(log_message, "primary_tags", None)
    if primary_tags:
        blob_lines.append(str(primary_tags))
    return "\n".join(blob_lines)


def _coerce_log_lines(raw_message) -> list[str]:
    """Normalizes a log field that may be a string or a list of lines."""
    if raw_message is None:
        return []
    if isinstance(raw_message, str):
        return raw_message.splitlines()
    if isinstance(raw_message, (list, tuple)):
        return [str(line) for line in raw_message]
    return [str(raw_message)]


def _extract_event_label_from_log(message_blob: str) -> str | None:
    """Extracts the human-readable unlock label from a log block."""
    match = EVENT_TYPE_LOG_PATTERN.search(message_blob)
    if match is None:
        return None
    return match.group(1).strip().splitlines()[0].strip()


def _extract_node_id_from_tags(primary_tags: str | None, message_blob: str) -> int | None:
    """Extracts node ID from Z-Wave log tags when context metadata is missing."""
    tag_blob = " ".join(filter(None, [primary_tags, message_blob]))
    match = re.search(r"Node\s+(\d+)", tag_blob, re.IGNORECASE)
    if match is None:
        return None

    try:
        return int(match.group(1))
    except ValueError:
        return None
