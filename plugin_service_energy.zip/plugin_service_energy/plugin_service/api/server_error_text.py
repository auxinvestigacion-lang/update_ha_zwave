"""Builds an installer-facing message from a failed registration HTTP response."""

from __future__ import annotations

import json

_SERVER_ERROR_KEYS = ("message", "error", "detail", "msg")
_MAX_ERROR_SNIPPET_LENGTH = 200


def format_registration_http_error(status: int, body_text: str) -> str:
    """Returns HTTP status plus the server message, or a short body snippet."""
    extracted = extract_server_error_text(body_text)
    if extracted:
        return f"HTTP {status}: {extracted}"
    snippet = " ".join(body_text.split())[:_MAX_ERROR_SNIPPET_LENGTH]
    if snippet:
        return f"HTTP {status}: {snippet}"
    return f"HTTP {status}"


def extract_server_error_text(body_text: str) -> str | None:
    """Reads message/error/detail from a JSON body when the server sends one."""
    parsed = _parse_json_object(body_text)
    if parsed is None:
        return None
    for key in _SERVER_ERROR_KEYS:
        extracted = _stringify_error_value(parsed.get(key))
        if extracted:
            return extracted
    return _stringify_error_list(parsed.get("errors"))


def _parse_json_object(body_text: str) -> dict | None:
    """Returns a dict payload, or None when the body is empty or not an object."""
    if not body_text.strip():
        return None
    try:
        parsed = json.loads(body_text)
    except ValueError:
        return None
    if isinstance(parsed, dict):
        return parsed
    return None


def _stringify_error_value(value: object) -> str | None:
    """Converts a typical API error field into a single installer-facing string."""
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, dict):
        nested = value.get("message") or value.get("detail")
        if isinstance(nested, str) and nested.strip():
            return nested.strip()
    return None


def _stringify_error_list(value: object) -> str | None:
    """Joins a list of error entries when the API returns ``errors: [...]``."""
    if not isinstance(value, list):
        return None
    parts = [str(item).strip() for item in value if str(item).strip()]
    if not parts:
        return None
    return "; ".join(parts[:5])
