"""Onboarding: registers areas, devices and entities with the external server via REST."""

import json
import logging

import aiohttp

from homeassistant.core import HomeAssistant

from ..const import (
    CONF_MAC,
    CONF_PROJECT_ID,
    CONF_SERVER_URL,
    LOG_PREFIX,
    ONBOARDING_ENDPOINT,
    RESP_PROJECT_ID,
)
from ..core.installer_notification import (
    format_plugin_off_issue,
    format_plugin_validation_issue,
    is_installer_language_spanish,
    notify_plugin_validation_errors,
    notify_registration_failure,
    notify_registration_success,
)
from ..core.registration_status import RegistrationStatusStore
from ..registry.data_collector import build_registration_payload
from ..registry.payload_serialization import dumps_payload_bytes
from ..registry.plugin_error_summary import (
    format_plugin_off_summary,
    format_plugin_status_summary,
)
from ..registry.plugin_off_automation import collect_plugin_off_warnings
from ..registry.plugin_validation import collect_registration_validation_issues
from ..registry.zwave_readiness import wait_for_zwave_inventory_ready
from .server_error_text import format_registration_http_error

_LOGGER = logging.getLogger(__name__)


async def run_onboarding(
    hass: HomeAssistant,
    config: dict,
    status_store: RegistrationStatusStore | None = None,
) -> dict | None:
    """Collects HA data and registers it with the external server.

    Returns the parsed server response on success, or None on failure.
    The server may confirm or override the project_id in its response.
    Plugin contract violations and HTTP errors block the request and notify
    the installer on the gateway device and via persistent notification.
    """
    is_spanish = is_installer_language_spanish(hass)
    if status_store is not None:
        status_store.set_syncing(is_spanish)

    if await _is_plugin_validation_blocking(hass, status_store, is_spanish):
        return None

    await wait_for_zwave_inventory_ready(hass)
    payload = await build_registration_payload(hass, config)
    server_response, http_error = await _post_to_server(config, payload)
    if http_error:
        await _record_http_failure(hass, status_store, http_error)
        return None

    await _record_registration_success(hass, status_store, is_spanish)
    return server_response


async def _is_plugin_validation_blocking(
    hass: HomeAssistant,
    status_store: RegistrationStatusStore | None,
    is_spanish: bool,
) -> bool:
    """Notifies the installer and returns True when inventory validation errors exist."""
    issues = collect_registration_validation_issues(hass)
    if not issues:
        return False

    await notify_plugin_validation_errors(hass, issues)
    detail = "\n".join(
        format_plugin_validation_issue(issue, is_spanish) for issue in issues
    )
    summary = format_plugin_status_summary(issues, is_spanish)
    if status_store is not None:
        status_store.set_error(summary, detail)
    _LOGGER.error(
        "%s registration blocked: %d validation error(s)",
        LOG_PREFIX,
        len(issues),
    )
    for issue in issues:
        _LOGGER.error(
            "%s plugin validation entity_id=%s reason=%s",
            LOG_PREFIX,
            issue.entity_id,
            issue.reason,
        )
    return True


async def _record_registration_success(
    hass: HomeAssistant,
    status_store: RegistrationStatusStore | None,
    is_spanish: bool,
) -> None:
    """Marks register as OK and announces plugin automations that were off."""
    off_warnings = collect_plugin_off_warnings(hass)
    await notify_registration_success(hass, off_warnings)
    if status_store is None:
        return
    if not off_warnings:
        status_store.set_ok(is_spanish)
        return
    entity_ids = [warning.entity_id for warning in off_warnings]
    detail = "\n".join(
        format_plugin_off_issue(warning, is_spanish) for warning in off_warnings
    )
    summary = format_plugin_off_summary(entity_ids, is_spanish)
    status_store.set_ok(is_spanish, summary, detail)
    _LOGGER.info(
        "%s registration OK with %d plugin automation(s) off",
        LOG_PREFIX,
        len(off_warnings),
    )


async def _record_http_failure(
    hass: HomeAssistant,
    status_store: RegistrationStatusStore | None,
    http_error: str,
) -> None:
    """Surfaces a server/connection failure on the gateway and in notifications."""
    await notify_registration_failure(hass, http_error)
    if status_store is not None:
        check_notes = (
            "Revisa las notificaciones para más detalle."
            if is_installer_language_spanish(hass)
            else "Check notifications for more detail."
        )
        status_store.set_error(f"Error: {http_error}. {check_notes}", http_error)


async def _post_to_server(
    config: dict, payload: dict
) -> tuple[dict | None, str | None]:
    """Sends the registration payload and returns the body or an error message."""
    url = config[CONF_SERVER_URL].rstrip("/") + ONBOARDING_ENDPOINT
    headers = {
        "Content-Type": "application/json",
    }

    _LOGGER.info(
        "%s registration POST to %s [project: %s | serial: %s]",
        LOG_PREFIX,
        url,
        config[CONF_PROJECT_ID],
        config[CONF_MAC],
    )

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                data=dumps_payload_bytes(payload),
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                body_text = await resp.text()
                return _handle_registration_http_result(
                    resp.status, body_text, config
                )
    except aiohttp.ClientError as err:
        _LOGGER.error("%s registration connection error: %s", LOG_PREFIX, err)
        return None, f"Connection error: {err}"
    except Exception as err:
        _LOGGER.exception("%s registration unexpected error: %s", LOG_PREFIX, err)
        return None, str(err)


def _handle_registration_http_result(
    status: int, body_text: str, config: dict
) -> tuple[dict | None, str | None]:
    """Maps an HTTP status and body to a success payload or an error string."""
    if status not in (200, 201):
        http_error = format_registration_http_error(status, body_text)
        _LOGGER.error("%s registration failed: %s", LOG_PREFIX, http_error)
        return None, http_error

    response_body = _parse_response_body(body_text)
    _LOGGER.info(
        "%s registration successful (HTTP %d) — project_id: %s",
        LOG_PREFIX,
        status,
        response_body.get(RESP_PROJECT_ID, config[CONF_PROJECT_ID]),
    )
    return response_body, None


def _parse_response_body(body_text: str) -> dict:
    """Parses the server response body, falling back to an empty dict."""
    if not body_text.strip():
        return {}

    try:
        parsed = json.loads(body_text)
        if isinstance(parsed, dict):
            return parsed
    except ValueError:
        _LOGGER.warning("%s registration response is not valid JSON", LOG_PREFIX)

    return {}
