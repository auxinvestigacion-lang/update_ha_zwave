"""Classifies whether a lock opened via PIN, remote command, or manually."""

from dataclasses import dataclass, field

from ..const import (
    LOCK_MASTER_CODE_USER_IDS,
    LOCK_NOTIFICATION_SOURCE_CALL_SERVICE,
    LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION,
    UNLOCK_METHOD_ACCESS_CODE,
    UNLOCK_METHOD_MANUAL,
    UNLOCK_METHOD_MASTER_CODE_ACCESS,
    UNLOCK_METHOD_REMOTE_COMMAND,
    UNLOCK_METHOD_UNKNOWN,
)
from .lock_unlock_identity_cache import LockUnlockIdentity

# Door Lock Logging CC (0x4C) — zwave-js DoorLockLoggingEventType
DOOR_LOCK_LOGGING_UNLOCK_CODE = 0x02
DOOR_LOCK_LOGGING_UNLOCK_CODE_OUT_OF_SCHEDULE = 0x06
DOOR_LOCK_LOGGING_UNLOCK_BUTTON = 0x04
DOOR_LOCK_LOGGING_UNLOCK_MANUAL = 0x09
DOOR_LOCK_LOGGING_UNLOCK_REMOTE_CODE = 0x0D
DOOR_LOCK_LOGGING_UNLOCK_REMOTE = 0x0F
DOOR_LOCK_LOGGING_UNLOCK_MANUAL_2 = 0x14

# Notification CC Access Control events used by zwave_js_notification
NOTIFICATION_MANUAL_UNLOCK = 2
NOTIFICATION_RF_UNLOCK = 4
NOTIFICATION_KEYPAD_UNLOCK = 6

ACCESS_CODE_LABEL_MARKERS = (
    "unlocked via access code",
    "unlock via access code",
    "unlocking via access code",
    "keypad unlock",
)
REMOTE_LABEL_MARKERS = (
    "rf unlock",
    "unlock via rf",
    "unlocking via rf",
    "remote unlock",
    "unlock remote",
    "unlocking via remote",
)
MANUAL_LABEL_MARKERS = (
    "manual unlock",
    "unlock via manual",
    "unlocking via manual",
    "unlock button",
)

DOOR_LOCK_LOGGING_ACCESS_CODE_TYPES = frozenset(
    {
        DOOR_LOCK_LOGGING_UNLOCK_CODE,
        DOOR_LOCK_LOGGING_UNLOCK_CODE_OUT_OF_SCHEDULE,
    }
)
DOOR_LOCK_LOGGING_REMOTE_TYPES = frozenset(
    {
        DOOR_LOCK_LOGGING_UNLOCK_REMOTE,
        DOOR_LOCK_LOGGING_UNLOCK_REMOTE_CODE,
    }
)
DOOR_LOCK_LOGGING_MANUAL_TYPES = frozenset(
    {
        DOOR_LOCK_LOGGING_UNLOCK_BUTTON,
        DOOR_LOCK_LOGGING_UNLOCK_MANUAL,
        DOOR_LOCK_LOGGING_UNLOCK_MANUAL_2,
    }
)
NOTIFICATION_ACCESS_CODE_TYPES = frozenset({NOTIFICATION_KEYPAD_UNLOCK})
NOTIFICATION_REMOTE_TYPES = frozenset({NOTIFICATION_RF_UNLOCK})
NOTIFICATION_MANUAL_TYPES = frozenset({NOTIFICATION_MANUAL_UNLOCK})

REMOTE_UNLOCK_EVENT_LABEL = "Remote unlock"
MANUAL_UNLOCK_EVENT_LABEL = "Manual unlock"
UNKNOWN_UNLOCK_EVENT_LABEL = "Unlock"

STRONG_KEYPAD_SOURCES = frozenset({LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION})


@dataclass(frozen=True)
class UnlockClassification:
    """Resolved unlock method and optional PIN identity for lock_notification."""

    unlock_method: str
    source: str
    user_id: int | None = None
    event_label: str | None = None
    event_type: int | str | None = None
    parameters: dict = field(default_factory=dict)


def classify_method_from_label(event_label: str | None) -> str | None:
    """Returns an unlock method when the human-readable label is unambiguous."""
    if not event_label:
        return None

    normalized_label = event_label.casefold()
    if any(marker in normalized_label for marker in ACCESS_CODE_LABEL_MARKERS):
        return UNLOCK_METHOD_ACCESS_CODE
    if any(marker in normalized_label for marker in REMOTE_LABEL_MARKERS):
        return UNLOCK_METHOD_REMOTE_COMMAND
    if any(marker in normalized_label for marker in MANUAL_LABEL_MARKERS):
        return UNLOCK_METHOD_MANUAL
    return None


def classify_method_from_door_lock_logging(
    event_type: int | str | None,
    event_label: str | None,
    user_id: int | None = None,
) -> str | None:
    """Classifies a Door Lock Logging record by event type, label, then user id."""
    parsed_event_type = _coerce_event_type(event_type)
    if parsed_event_type in DOOR_LOCK_LOGGING_ACCESS_CODE_TYPES:
        return apply_master_code_method(UNLOCK_METHOD_ACCESS_CODE, user_id)
    if parsed_event_type in DOOR_LOCK_LOGGING_REMOTE_TYPES:
        return UNLOCK_METHOD_REMOTE_COMMAND
    if parsed_event_type in DOOR_LOCK_LOGGING_MANUAL_TYPES:
        return UNLOCK_METHOD_MANUAL

    from_label = classify_method_from_label(event_label)
    if from_label is not None:
        return apply_master_code_method(from_label, user_id)

    if user_id is not None:
        return apply_master_code_method(UNLOCK_METHOD_ACCESS_CODE, user_id)
    return None


def classify_method_from_notification(
    event_type: int | str | None,
    event_label: str | None,
    user_id: int | None = None,
) -> str | None:
    """Classifies a zwave_js_notification Access Control event."""
    parsed_event_type = _coerce_event_type(event_type)
    if parsed_event_type in NOTIFICATION_ACCESS_CODE_TYPES:
        return apply_master_code_method(UNLOCK_METHOD_ACCESS_CODE, user_id)
    if parsed_event_type in NOTIFICATION_REMOTE_TYPES:
        return UNLOCK_METHOD_REMOTE_COMMAND
    if parsed_event_type in NOTIFICATION_MANUAL_TYPES:
        return UNLOCK_METHOD_MANUAL

    from_label = classify_method_from_label(event_label)
    if from_label is not None:
        return apply_master_code_method(from_label, user_id)

    if user_id is not None:
        return apply_master_code_method(UNLOCK_METHOD_ACCESS_CODE, user_id)
    return None


def classify_from_cache_and_pending(
    cached_identity: LockUnlockIdentity | None,
    was_remote_pending: bool,
) -> UnlockClassification | None:
    """Applies keypad-over-remote priority, then pending command, then cached method."""
    if _is_strong_keypad_identity(cached_identity):
        return build_classification_from_identity(cached_identity)

    if was_remote_pending:
        return UnlockClassification(
            unlock_method=UNLOCK_METHOD_REMOTE_COMMAND,
            source=LOCK_NOTIFICATION_SOURCE_CALL_SERVICE,
            event_label=REMOTE_UNLOCK_EVENT_LABEL,
        )

    if cached_identity is None:
        return None

    return build_classification_from_identity(cached_identity)


def build_classification_from_identity(
    identity: LockUnlockIdentity,
) -> UnlockClassification:
    """Maps a cached identity onto the lock_notification classification shape."""
    unlock_method = apply_master_code_method(
        identity.unlock_method or UNLOCK_METHOD_UNKNOWN,
        identity.user_id,
    )
    user_id = identity.user_id if is_access_code_unlock(unlock_method) else None
    return UnlockClassification(
        unlock_method=unlock_method,
        source=identity.source,
        user_id=user_id,
        event_label=_event_label_for_method(unlock_method, identity.event_label),
        event_type=identity.event_type,
        parameters=dict(identity.parameters or {}),
    )


def build_unknown_classification(source: str) -> UnlockClassification:
    """Builds a notification payload when the unlock method could not be proven."""
    return UnlockClassification(
        unlock_method=UNLOCK_METHOD_UNKNOWN,
        source=source,
        event_label=UNKNOWN_UNLOCK_EVENT_LABEL,
    )


def apply_master_code_method(unlock_method: str, user_id: int | None) -> str:
    """Maps keypad unlocks from factory user IDs 1/2 to master_code_access."""
    if unlock_method == UNLOCK_METHOD_ACCESS_CODE and user_id in LOCK_MASTER_CODE_USER_IDS:
        return UNLOCK_METHOD_MASTER_CODE_ACCESS
    return unlock_method


def is_access_code_unlock(unlock_method: str) -> bool:
    """Returns True when a keypad PIN identity may be attached to the notification."""
    return unlock_method in {
        UNLOCK_METHOD_ACCESS_CODE,
        UNLOCK_METHOD_MASTER_CODE_ACCESS,
    }


def _is_strong_keypad_identity(identity: LockUnlockIdentity | None) -> bool:
    """Returns True for a keypad notification that includes a user id."""
    if identity is None or identity.unlock_method is None:
        return False
    return (
        identity.source in STRONG_KEYPAD_SOURCES
        and is_access_code_unlock(identity.unlock_method)
        and identity.user_id is not None
    )


def _event_label_for_method(unlock_method: str, original_label: str | None) -> str:
    """Returns a server-facing label that does not imply a PIN on remote/manual unlocks."""
    if unlock_method == UNLOCK_METHOD_REMOTE_COMMAND:
        return REMOTE_UNLOCK_EVENT_LABEL
    if unlock_method == UNLOCK_METHOD_MANUAL:
        return MANUAL_UNLOCK_EVENT_LABEL
    if unlock_method == UNLOCK_METHOD_UNKNOWN:
        return UNKNOWN_UNLOCK_EVENT_LABEL
    return original_label or UNKNOWN_UNLOCK_EVENT_LABEL


def _coerce_event_type(event_type: int | str | None) -> int | None:
    """Parses a numeric event type when the source provided one."""
    if event_type is None:
        return None
    try:
        return int(event_type)
    except (TypeError, ValueError):
        return None
