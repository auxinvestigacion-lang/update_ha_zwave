"""Caches recent lock unlock identities keyed by device_id."""

import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class LockUnlockIdentity:
    """Resolved unlock identity from any Z-Wave source."""

    source: str
    user_id: int | None = None
    event_label: str | None = None
    event_type: int | str | None = None
    parameters: dict | None = None
    unlock_method: str | None = None


class LockUnlockIdentityCache:
    """Stores unlock identities for a short window after they are observed."""

    def __init__(self, max_age_seconds: float) -> None:
        self._max_age_seconds = max_age_seconds
        self._entries: dict[str, tuple[LockUnlockIdentity, float]] = {}

    def store(self, device_id: str, identity: LockUnlockIdentity) -> None:
        """Stores or replaces the latest identity for a lock device."""
        self._entries[device_id] = (identity, time.monotonic())

    def get_recent(self, device_id: str) -> LockUnlockIdentity | None:
        """Returns a cached identity when it is still within the retention window."""
        entry = self._entries.get(device_id)
        if entry is None:
            return None

        identity, stored_at = entry
        if time.monotonic() - stored_at > self._max_age_seconds:
            self._entries.pop(device_id, None)
            return None

        return identity

    def clear(self, device_id: str) -> None:
        """Removes one cached identity entry."""
        self._entries.pop(device_id, None)
