"""Resolves lock unlock method and PIN identity from Z-Wave sources."""

import asyncio
import logging

from homeassistant.core import HomeAssistant

from ..const import (
    LOCK_IDENTITY_CACHE_MAX_AGE_SECONDS,
    LOCK_IDENTITY_RESOLVE_WAIT_SECONDS,
    LOCK_IDENTITY_RETRY_INTERVAL_SECONDS,
    LOCK_NOTIFICATION_SOURCE_LOCK_STATE_CHANGED,
    LOCK_REMOTE_UNLOCK_WINDOW_SECONDS,
    LOG_PREFIX,
)
from .door_lock_logging_resolver import prompt_latest_log_record
from .lock_unlock_classifier import (
    UnlockClassification,
    build_classification_from_identity,
    build_unknown_classification,
    classify_from_cache_and_pending,
)
from .lock_unlock_identity_cache import LockUnlockIdentityCache
from .pending_remote_unlock_tracker import PendingRemoteUnlockTracker

_LOGGER = logging.getLogger(__name__)


async def resolve_unlock_classification(
    hass: HomeAssistant,
    device_id: str,
    entity_id: str,
    identity_cache: LockUnlockIdentityCache,
    pending_tracker: PendingRemoteUnlockTracker,
) -> UnlockClassification:
    """Resolves unlock method, preferring keypad evidence over a pending remote command."""
    cached_identity = identity_cache.get_recent(device_id)
    was_remote_pending = pending_tracker.consume(entity_id)
    from_cache = classify_from_cache_and_pending(cached_identity, was_remote_pending)
    if from_cache is not None:
        return from_cache

    from_wait = await _wait_for_unlock_identity(
        hass, device_id, entity_id, identity_cache
    )
    if from_wait is not None:
        return from_wait

    _LOGGER.warning(
        "%s could not resolve unlock method [device: %s | entity: %s]",
        LOG_PREFIX,
        device_id,
        entity_id,
    )
    return build_unknown_classification(LOCK_NOTIFICATION_SOURCE_LOCK_STATE_CHANGED)


async def _wait_for_unlock_identity(
    hass: HomeAssistant,
    device_id: str,
    entity_id: str,
    identity_cache: LockUnlockIdentityCache,
) -> UnlockClassification | None:
    """Prompts a Door Lock Logging GET, then waits for the report in driver logs."""
    await prompt_latest_log_record(hass, device_id, entity_id)

    retry_deadline = asyncio.get_running_loop().time() + LOCK_IDENTITY_RESOLVE_WAIT_SECONDS
    while asyncio.get_running_loop().time() < retry_deadline:
        cached_identity = identity_cache.get_recent(device_id)
        if cached_identity is not None:
            return build_classification_from_identity(cached_identity)
        await asyncio.sleep(LOCK_IDENTITY_RETRY_INTERVAL_SECONDS)

    return None


def create_lock_unlock_identity_cache() -> LockUnlockIdentityCache:
    """Creates the shared unlock identity cache."""
    return LockUnlockIdentityCache(LOCK_IDENTITY_CACHE_MAX_AGE_SECONDS)


def create_pending_remote_unlock_tracker() -> PendingRemoteUnlockTracker:
    """Creates the tracker that correlates lock.unlock with the next opening."""
    return PendingRemoteUnlockTracker(LOCK_REMOTE_UNLOCK_WINDOW_SECONDS)
