"""Forwards Z-Wave lock unlock events with method and user identification."""

import logging
from collections.abc import Awaitable, Callable

from homeassistant.const import ATTR_DEVICE_ID, ATTR_ENTITY_ID, EVENT_CALL_SERVICE
from homeassistant.core import Event, HomeAssistant, callback

from ..const import (
    HA_LOCK_DOMAIN,
    HA_LOCK_SERVICE_UNLOCK,
    HA_LOCK_STATE_UNLOCKED,
    LOCK_LATE_IDENTITY_WINDOW_SECONDS,
    LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION,
    LOG_PREFIX,
)
from ..registry.lock_user_mapper import resolve_code_slot_for_user
from .lock_unlock_classifier import (
    UnlockClassification,
    build_classification_from_identity,
    classify_method_from_notification,
    is_access_code_unlock,
)
from .lock_unlock_identity_cache import LockUnlockIdentity, LockUnlockIdentityCache
from .lock_unlock_identity_resolver import resolve_unlock_classification
from .lock_unlock_publication_tracker import LockUnlockPublicationTracker
from .messages import build_lock_notification_message
from .pending_remote_unlock_tracker import PendingRemoteUnlockTracker
from .zwave_driver_log_listener import ZwaveDriverLogListener

_LOGGER = logging.getLogger(__name__)

ZWAVE_JS_NOTIFICATION_EVENT = "zwave_js_notification"


class LockNotificationForwarder:
    """Publishes lock_notification messages when a tracked lock unlocks."""

    def __init__(
        self,
        hass: HomeAssistant,
        project_id: str,
        serial: str,
        send_message: Callable[[dict], Awaitable[None]],
        get_lock_device_map: Callable[[], dict[str, dict]],
        identity_cache: LockUnlockIdentityCache,
        pending_tracker: PendingRemoteUnlockTracker,
    ) -> None:
        self._hass = hass
        self._project_id = project_id
        self._serial = serial
        self._send_message = send_message
        self._get_lock_device_map = get_lock_device_map
        self._identity_cache = identity_cache
        self._pending_tracker = pending_tracker
        self._publication_tracker = LockUnlockPublicationTracker()
        self._resolving_device_ids: set[str] = set()
        self._notification_unsub = None
        self._call_service_unsub = None
        self._driver_log_listener = ZwaveDriverLogListener(
            hass=hass,
            identity_cache=identity_cache,
            get_lock_device_map=get_lock_device_map,
            on_identity_stored=self._on_identity_stored,
        )

    def subscribe(self) -> None:
        """Subscribes to Z-Wave unlock identity sources and lock.unlock commands."""
        if self._notification_unsub is not None:
            return

        @callback
        def _on_zwave_notification(event: Event) -> None:
            self._handle_zwave_notification(event)

        @callback
        def _on_call_service(event: Event) -> None:
            self._handle_lock_unlock_service(event)

        self._notification_unsub = self._hass.bus.async_listen(
            ZWAVE_JS_NOTIFICATION_EVENT,
            _on_zwave_notification,
        )
        self._call_service_unsub = self._hass.bus.async_listen(
            EVENT_CALL_SERVICE,
            _on_call_service,
        )
        self._driver_log_listener.subscribe()

    def unsubscribe(self) -> None:
        """Unsubscribes from Z-Wave unlock identity listeners."""
        if self._notification_unsub:
            self._notification_unsub()
            self._notification_unsub = None

        if self._call_service_unsub:
            self._call_service_unsub()
            self._call_service_unsub = None

        self._driver_log_listener.unsubscribe()

    async def notify_lock_unlocked(self, device_id: str, entity_id: str) -> None:
        """Classifies the unlock method and publishes lock_notification to the server."""
        lock_profile = self._get_lock_device_map().get(device_id)
        if lock_profile is None:
            return

        self._resolving_device_ids.add(device_id)
        try:
            classification = await resolve_unlock_classification(
                self._hass,
                device_id,
                entity_id,
                self._identity_cache,
                self._pending_tracker,
            )
            await self._publish_classification(
                device_id=device_id,
                entity_id=entity_id,
                lock_profile=lock_profile,
                classification=classification,
            )
            self._publication_tracker.record(
                device_id, entity_id, classification.unlock_method
            )
            self._identity_cache.clear(device_id)
        finally:
            self._resolving_device_ids.discard(device_id)

    def clear_identity_if_idle(self, device_id: str) -> None:
        """Clears cached identity after a lock, unless a keypad resolve is still running."""
        if device_id in self._resolving_device_ids:
            return
        self._identity_cache.clear(device_id)

    @callback
    def _on_identity_stored(self, device_id: str) -> None:
        """Schedules a follow-up when a late keypad log arrives after unknown."""
        if device_id in self._resolving_device_ids:
            return

        self._hass.async_create_task(self._publish_late_access_code(device_id))

    async def _publish_late_access_code(self, device_id: str) -> None:
        """Publishes access_code when the master/user PIN log arrives after unknown."""
        identity = self._identity_cache.get_recent(device_id)
        if identity is None:
            return
        if not is_access_code_unlock(identity.unlock_method or "") or identity.user_id is None:
            return

        entity_id = self._publication_tracker.take_unknown_for_late_identity(
            device_id,
            LOCK_LATE_IDENTITY_WINDOW_SECONDS,
        )
        if entity_id is None:
            return

        lock_profile = self._get_lock_device_map().get(device_id)
        if lock_profile is None:
            return

        classification = build_classification_from_identity(identity)
        await self._publish_classification(
            device_id=device_id,
            entity_id=entity_id,
            lock_profile=lock_profile,
            classification=classification,
        )
        self._publication_tracker.record(
            device_id, entity_id, classification.unlock_method
        )
        self._identity_cache.clear(device_id)
        _LOGGER.info(
            "%s late keypad identity [device: %s | user_id: %s]",
            LOG_PREFIX,
            device_id,
            identity.user_id,
        )

    def _handle_lock_unlock_service(self, event: Event) -> None:
        """Marks a pending remote unlock when HA executes lock.unlock on a tracked lock."""
        event_data = event.data
        if event_data.get("domain") != HA_LOCK_DOMAIN:
            return
        if event_data.get("service") != HA_LOCK_SERVICE_UNLOCK:
            return

        for entity_id in _extract_tracked_lock_entity_ids(
            event_data,
            self._get_lock_device_map(),
        ):
            current_state = self._hass.states.get(entity_id)
            if current_state is not None and current_state.state == HA_LOCK_STATE_UNLOCKED:
                continue

            self._pending_tracker.mark(entity_id)
            _LOGGER.info(
                "%s marked remote unlock pending [entity: %s]",
                LOG_PREFIX,
                entity_id,
            )

    def _handle_zwave_notification(self, event: Event) -> None:
        """Caches Access Control unlock method and keypad userId when present."""
        event_data = event.data
        device_id = event_data.get("device_id")
        if not device_id or device_id not in self._get_lock_device_map():
            return

        event_label = event_data.get("event_label")
        event_type = event_data.get("event")
        user_id = _parse_optional_user_id((event_data.get("parameters") or {}).get("userId"))
        unlock_method = classify_method_from_notification(event_type, event_label, user_id)
        if unlock_method is None:
            return
        if is_access_code_unlock(unlock_method) and user_id is None:
            return

        parameters = event_data.get("parameters") or {}
        self._identity_cache.store(
            device_id,
            LockUnlockIdentity(
                source=LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION,
                user_id=user_id,
                event_label=event_label,
                event_type=event_type,
                parameters=parameters,
                unlock_method=unlock_method,
            ),
        )
        self._on_identity_stored(device_id)

    async def _publish_classification(
        self,
        *,
        device_id: str,
        entity_id: str,
        lock_profile: dict,
        classification: UnlockClassification,
    ) -> None:
        """Resolves code_slot for PIN unlocks and sends the envelope."""
        user_id = classification.user_id
        code_slot = None
        parameters = dict(classification.parameters)
        if is_access_code_unlock(classification.unlock_method) and user_id is not None:
            code_slot = await resolve_code_slot_for_user(
                self._hass,
                entity_id,
                user_id,
                lock_profile.get("api", "usercode"),
                device_id=device_id,
            )
            parameters.setdefault("userId", user_id)
        else:
            user_id = None
            parameters.pop("userId", None)

        await self._publish_notification(
            device_id=device_id,
            entity_id=entity_id,
            user_id=user_id,
            code_slot=code_slot,
            event_label=classification.event_label,
            event_type=classification.event_type,
            source=classification.source,
            parameters=parameters,
            unlock_method=classification.unlock_method,
        )

    async def _publish_notification(
        self,
        *,
        device_id: str,
        entity_id: str | None,
        user_id: int | None,
        code_slot: int | None,
        event_label: str | None,
        event_type,
        source: str,
        parameters: dict,
        unlock_method: str,
    ) -> None:
        """Builds and sends a lock_notification envelope."""
        payload = build_lock_notification_message(
            project_id=self._project_id,
            serial=self._serial,
            device_id=device_id,
            entity_id=entity_id,
            event=str(event_type) if event_type is not None else None,
            event_label=event_label,
            notification_type=source,
            user_id=user_id,
            code_slot=code_slot,
            parameters=parameters,
            source=source,
            unlock_method=unlock_method,
        )
        _LOGGER.info(
            "%s lock_notification [device: %s | method: %s | user_id: %s | code_slot: %s | source: %s]",
            LOG_PREFIX,
            device_id,
            unlock_method,
            user_id,
            code_slot,
            source,
        )
        await self._send_message(payload)


def _extract_tracked_lock_entity_ids(
    event_data: dict,
    lock_device_map: dict[str, dict],
) -> list[str]:
    """Returns tracked lock entity IDs targeted by a lock.unlock service call."""
    matched_entity_ids: list[str] = []
    for entity_id in _extract_id_values(event_data, ATTR_ENTITY_ID):
        if _is_tracked_lock_entity(entity_id, lock_device_map):
            matched_entity_ids.append(entity_id)

    for device_id in _extract_id_values(event_data, ATTR_DEVICE_ID):
        lock_profile = lock_device_map.get(device_id)
        entity_id = lock_profile.get("entity_id") if lock_profile else None
        if entity_id:
            matched_entity_ids.append(entity_id)

    return list(dict.fromkeys(matched_entity_ids))


def _extract_id_values(event_data: dict, field_name: str) -> list[str]:
    """Collects string IDs from service_data, target, and the event payload."""
    collected_ids: list[str] = []
    for container in (
        event_data.get("service_data") or {},
        event_data.get("target") or {},
        event_data,
    ):
        if not isinstance(container, dict):
            continue
        collected_ids.extend(_coerce_id_list(container.get(field_name)))
    return collected_ids


def _coerce_id_list(raw_value) -> list[str]:
    """Normalizes a service target value into a list of IDs."""
    if isinstance(raw_value, str):
        return [raw_value]
    if isinstance(raw_value, (list, tuple)):
        return [item for item in raw_value if isinstance(item, str)]
    return []


def _is_tracked_lock_entity(entity_id: str, lock_device_map: dict[str, dict]) -> bool:
    """Returns True when the entity belongs to a lock tracked for notifications."""
    return any(profile.get("entity_id") == entity_id for profile in lock_device_map.values())


def _parse_optional_user_id(raw_user_id) -> int | None:
    """Parses a Z-Wave userId parameter when present."""
    if raw_user_id is None:
        return None
    try:
        return int(raw_user_id)
    except (TypeError, ValueError):
        return None
