"""Resolves lock unlock user identity from Z-Wave Door Lock Logging CC."""

import asyncio
import logging
from dataclasses import dataclass
from datetime import timezone
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util
from zwave_js_server.const import CommandClass

from ..const import (
    DOOR_LOCK_LOGGING_LATEST_RECORD_INDEX,
    DOOR_LOCK_LOGGING_MAX_RECORD_AGE_SECONDS,
    DOOR_LOCK_LOGGING_RESOLVE_DELAY_SECONDS,
    LOG_PREFIX,
)
from .lock_unlock_classifier import classify_method_from_door_lock_logging, is_access_code_unlock

_LOGGER = logging.getLogger(__name__)

DOOR_LOCK_LOGGING_COMMAND_CLASS = CommandClass.DOOR_LOCK_LOGGING
DOOR_LOCK_LOGGING_GET_RECORD_METHOD = "getRecord"
DOOR_LOCK_LOGGING_GET_RECORDS_COUNT_METHOD = "getRecordsCount"
DOOR_LOCK_LOGGING_MAX_ATTEMPTS = 2
DOOR_LOCK_LOGGING_RETRY_DELAY_SECONDS = 0.25


@dataclass(frozen=True)
class DoorLockUnlockRecord:
    """Normalized unlock audit record from Door Lock Logging CC."""

    user_id: int
    event_label: str
    event_type: int | str | None
    record_number: int | None
    timestamp: str | None


async def fetch_latest_code_unlock_record(
    hass: HomeAssistant,
    device_id: str,
    entity_id: str | None = None,
    *,
    settle_delay: bool = True,
) -> DoorLockUnlockRecord | None:
    """Reads the latest Door Lock Logging record and returns a code-unlock entry."""
    node = await _get_lock_node(hass, device_id, entity_id)
    if node is None:
        return None

    if not await _supports_door_lock_logging_api(node, device_id):
        return None

    if settle_delay:
        await asyncio.sleep(DOOR_LOCK_LOGGING_RESOLVE_DELAY_SECONDS)

    for attempt_index in range(DOOR_LOCK_LOGGING_MAX_ATTEMPTS):
        if attempt_index > 0:
            await asyncio.sleep(DOOR_LOCK_LOGGING_RETRY_DELAY_SECONDS)

        raw_record = await _fetch_latest_log_record(node, device_id)
        if raw_record is None:
            continue

        normalized_record = _normalize_log_record(raw_record)
        if normalized_record is None:
            _LOGGER.warning(
                "%s door lock logging record could not be parsed [device: %s | raw: %s]",
                LOG_PREFIX,
                device_id,
                _summarize_raw_record(raw_record),
            )
            continue

        if not _is_code_unlock_record(normalized_record):
            _LOGGER.debug(
                "%s door lock logging record is not a code unlock [device: %s | label: %s | type: %s | user_id: %s]",
                LOG_PREFIX,
                device_id,
                normalized_record.event_label,
                normalized_record.event_type,
                normalized_record.user_id,
            )
            continue

        if not _is_record_fresh(normalized_record.timestamp):
            _LOGGER.debug(
                "%s door lock logging record is stale [device: %s | timestamp: %s]",
                LOG_PREFIX,
                device_id,
                normalized_record.timestamp,
            )
            continue

        _LOGGER.info(
            "%s resolved unlock user via CC API [device: %s | user_id: %s | label: %s]",
            LOG_PREFIX,
            device_id,
            normalized_record.user_id,
            normalized_record.event_label,
        )
        return normalized_record

    _LOGGER.debug(
        "%s door lock logging getRecord returned no code unlock [device: %s]",
        LOG_PREFIX,
        device_id,
    )
    return None


async def prompt_latest_log_record(
    hass: HomeAssistant,
    device_id: str,
    entity_id: str | None = None,
) -> None:
    """Requests the latest audit record without waiting; the report is parsed from driver logs."""
    node = await _get_lock_node(hass, device_id, entity_id)
    if node is None:
        return
    if not await _supports_door_lock_logging_api(node, device_id):
        return

    try:
        await node.async_invoke_cc_api(
            DOOR_LOCK_LOGGING_COMMAND_CLASS,
            DOOR_LOCK_LOGGING_GET_RECORD_METHOD,
            DOOR_LOCK_LOGGING_LATEST_RECORD_INDEX,
            wait_for_result=False,
        )
    except Exception as err:
        _LOGGER.debug(
            "%s door lock logging prompt failed [device: %s]: %s",
            LOG_PREFIX,
            device_id,
            err,
        )


async def _get_lock_node(hass: HomeAssistant, device_id: str, entity_id: str | None):
    """Returns the zwave_js node for a lock device or entity."""
    from homeassistant.components.zwave_js.helpers import (
        async_get_node_from_device_id,
        async_get_node_from_entity_id,
    )

    if entity_id:
        try:
            return async_get_node_from_entity_id(hass, entity_id)
        except Exception as err:
            _LOGGER.debug(
                "%s node lookup by entity failed [entity: %s]: %s",
                LOG_PREFIX,
                entity_id,
                err,
            )

    try:
        return async_get_node_from_device_id(hass, device_id)
    except Exception as err:
        _LOGGER.warning(
            "%s door lock logging node lookup failed [device: %s]: %s",
            LOG_PREFIX,
            device_id,
            err,
        )
        return None


async def _supports_door_lock_logging_api(node, device_id: str) -> bool:
    """Checks whether the lock exposes the Door Lock Logging CC API."""
    try:
        supported = await node.async_supports_cc_api(DOOR_LOCK_LOGGING_COMMAND_CLASS)
    except Exception as err:
        _LOGGER.warning(
            "%s door lock logging API check failed [device: %s]: %s",
            LOG_PREFIX,
            device_id,
            err,
        )
        return False

    if not supported:
        _LOGGER.info(
            "%s door lock logging API not supported [device: %s]",
            LOG_PREFIX,
            device_id,
        )
    return supported


async def _fetch_latest_log_record(node, device_id: str) -> Any | None:
    """Queries Door Lock Logging CC for the most recent audit record."""
    record_candidates = (
        await _invoke_get_record(node, record_number=None),
        await _invoke_get_record(node, record_number=DOOR_LOCK_LOGGING_LATEST_RECORD_INDEX),
        await _invoke_get_record_from_count(node),
    )

    for raw_record in record_candidates:
        if raw_record is not None:
            return raw_record

    return None


async def _invoke_get_record(node, *, record_number: int | None) -> Any | None:
    """Invokes getRecord on Door Lock Logging CC and waits for the Z-Wave response."""
    try:
        if record_number is None:
            raw_record = await node.async_invoke_cc_api(
                DOOR_LOCK_LOGGING_COMMAND_CLASS,
                DOOR_LOCK_LOGGING_GET_RECORD_METHOD,
                wait_for_result=True,
            )
        else:
            raw_record = await node.async_invoke_cc_api(
                DOOR_LOCK_LOGGING_COMMAND_CLASS,
                DOOR_LOCK_LOGGING_GET_RECORD_METHOD,
                record_number,
                wait_for_result=True,
            )
    except Exception as err:
        _LOGGER.debug(
            "%s door lock logging getRecord failed [record: %s | device node: %s]: %s",
            LOG_PREFIX,
            record_number,
            getattr(node, "node_id", "unknown"),
            err,
        )
        return None

    return _unwrap_log_record(raw_record)


async def _invoke_get_record_from_count(node) -> Any | None:
    """Fetches the latest record using getRecordsCount when direct lookups fail."""
    try:
        records_count = await node.async_invoke_cc_api(
            DOOR_LOCK_LOGGING_COMMAND_CLASS,
            DOOR_LOCK_LOGGING_GET_RECORDS_COUNT_METHOD,
            wait_for_result=True,
        )
    except Exception as err:
        _LOGGER.debug(
            "%s door lock logging getRecordsCount failed: %s",
            LOG_PREFIX,
            err,
        )
        return None

    parsed_count = _coerce_int(records_count)
    if parsed_count is None or parsed_count <= 0:
        return None

    return await _invoke_get_record(node, record_number=parsed_count)


def _normalize_log_record(raw_record) -> DoorLockUnlockRecord | None:
    """Maps a zwave-js DoorLockLoggingRecord into a stable plugin shape."""
    raw_record = _unwrap_log_record(raw_record)
    user_id = _read_record_value(raw_record, "userId", "user_id")
    if user_id is None:
        return None

    parsed_user_id = _coerce_int(user_id)
    if parsed_user_id is None:
        return None

    event_type = _read_record_value(raw_record, "eventType", "event_type")
    event_label = _read_record_value(raw_record, "label", "event_label")
    record_number = _read_record_value(raw_record, "recordNumber", "record_number")
    timestamp = _read_record_value(raw_record, "timestamp")

    normalized_label = str(event_label) if event_label is not None else "Unknown"
    parsed_record_number = _coerce_int(record_number)
    normalized_timestamp = str(timestamp) if timestamp is not None else None

    return DoorLockUnlockRecord(
        user_id=parsed_user_id,
        event_label=normalized_label,
        event_type=event_type,
        record_number=parsed_record_number,
        timestamp=normalized_timestamp,
    )


def _is_code_unlock_record(record: DoorLockUnlockRecord) -> bool:
    """Returns True when the audit record represents a keypad / access-code unlock."""
    unlock_method = classify_method_from_door_lock_logging(
        record.event_type,
        record.event_label,
        record.user_id,
    )
    return is_access_code_unlock(unlock_method)


def _is_record_fresh(timestamp: str | None) -> bool:
    """Returns True when the audit timestamp is usable, missing, or a default lock RTC."""
    if timestamp is None:
        return True

    parsed_timestamp = dt_util.parse_datetime(timestamp)
    if parsed_timestamp is None:
        return True

    if parsed_timestamp.tzinfo is None:
        parsed_timestamp = parsed_timestamp.replace(tzinfo=timezone.utc)

    if _is_unset_lock_clock(parsed_timestamp):
        return True

    age_seconds = abs((dt_util.utcnow() - parsed_timestamp).total_seconds())
    return age_seconds <= DOOR_LOCK_LOGGING_MAX_RECORD_AGE_SECONDS


def _is_unset_lock_clock(parsed_timestamp) -> bool:
    """Returns True when the lock RTC looks factory-default (this hardware stays on 2023-01-01)."""
    return parsed_timestamp.year <= 2023


def _unwrap_log_record(raw_record: Any) -> Any:
    """Unwraps nested invoke_cc_api response envelopes when present."""
    if isinstance(raw_record, dict) and "response" in raw_record:
        return raw_record["response"]
    return raw_record


def _read_record_value(raw_record, *field_names):
    """Reads a field from a dict-like or attribute-based zwave-js record."""
    if isinstance(raw_record, dict):
        for field_name in field_names:
            if field_name in raw_record:
                return raw_record[field_name]

    for field_name in field_names:
        if hasattr(raw_record, field_name):
            return getattr(raw_record, field_name)

    return None


def _coerce_int(value) -> int | None:
    """Parses an integer value when possible."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _summarize_raw_record(raw_record: Any) -> str:
    """Returns a compact debug representation of a raw audit record."""
    if isinstance(raw_record, dict):
        return str({key: raw_record.get(key) for key in sorted(raw_record)})
    return repr(raw_record)
