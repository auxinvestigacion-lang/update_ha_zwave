"""Remembers the last lock_notification published per device for late PIN logs."""

import time

from ..const import UNLOCK_METHOD_UNKNOWN


class LockUnlockPublicationTracker:
    """Tracks the latest unlock notification so a delayed keypad log can follow up."""

    def __init__(self) -> None:
        self._entries: dict[str, tuple[str, str, float]] = {}

    def record(self, device_id: str, entity_id: str, unlock_method: str) -> None:
        """Stores the method and entity of the last notification for this lock."""
        self._entries[device_id] = (unlock_method, entity_id, time.monotonic())

    def take_unknown_for_late_identity(
        self,
        device_id: str,
        window_seconds: float,
    ) -> str | None:
        """Returns entity_id when the last notice was unknown and still in the late window."""
        entry = self._entries.get(device_id)
        if entry is None:
            return None

        unlock_method, entity_id, published_at = entry
        if unlock_method != UNLOCK_METHOD_UNKNOWN:
            return None
        if time.monotonic() - published_at > window_seconds:
            self._entries.pop(device_id, None)
            return None

        self._entries.pop(device_id, None)
        return entity_id
