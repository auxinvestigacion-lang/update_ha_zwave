"""Tracks recent lock.unlock service calls to classify remote openings."""

import time


class PendingRemoteUnlockTracker:
    """Stores entity IDs that received lock.unlock within a short window."""

    def __init__(self, window_seconds: float) -> None:
        self._window_seconds = window_seconds
        self._pending_at: dict[str, float] = {}

    def mark(self, entity_id: str) -> None:
        """Records that a remote unlock command was issued for this lock entity."""
        self._pending_at[entity_id] = time.monotonic()

    def consume(self, entity_id: str) -> bool:
        """Returns True when a remote unlock is still in the correlation window."""
        marked_at = self._pending_at.pop(entity_id, None)
        if marked_at is None:
            return False

        return time.monotonic() - marked_at <= self._window_seconds
