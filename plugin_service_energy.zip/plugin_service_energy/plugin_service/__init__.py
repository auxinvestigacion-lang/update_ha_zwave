"""Plugin Service — Home Assistant custom integration.

Flow:
1. On setup, wait for Z-Wave inventory, then register areas/devices/entities.
2. After a successful server response, connect to the external WebSocket.
3. On auth_ok, push a state_sync snapshot with current entity states.
4. Stream state_changed events to the server; receive call_service commands.
"""

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .const import (
    CONF_ENVIRONMENT,
    CONF_SERVER_URL,
    DATA_CONFIG,
    DATA_REGISTRATION_STATUS,
    DATA_RELEASE_COORDINATOR,
    DOMAIN,
    LOG_PREFIX,
)
from .core.config_entry_migration import migrate_config_entry
from .core.entry_manager import (
    build_entry_config,
    register_and_start_client,
    stop_ws_client,
)
from .core.registration_status import RegistrationStatusStore
from .core.release_coordinator import PluginReleaseCoordinator

_LOGGER = logging.getLogger(__name__)

PLATFORMS = ["button", "select", "sensor", "update"]


async def async_setup(hass: HomeAssistant, config: dict) -> bool:
    """Initializes domain storage."""
    hass.data.setdefault(DOMAIN, {})
    return True


async def async_migrate_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Migrates a config entry to the current schema before setup."""
    return await migrate_config_entry(hass, entry)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Starts platforms immediately and defers register/WS until Z-Wave is ready.

    Registration runs as a background task so setup never deadlocks waiting for
    ``homeassistant_started`` and does not block other integrations.
    """
    hass.data.setdefault(DOMAIN, {})

    entry_config = build_entry_config(entry)
    coordinator = PluginReleaseCoordinator(hass)
    hass.data[DOMAIN][entry.entry_id] = {
        DATA_CONFIG: entry_config,
        DATA_RELEASE_COORDINATOR: coordinator,
        DATA_REGISTRATION_STATUS: RegistrationStatusStore(),
    }
    await coordinator.async_refresh()

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    entry.async_on_unload(entry.add_update_listener(async_reload_entry))
    entry.async_create_background_task(
        hass,
        register_and_start_client(hass, entry.entry_id, entry_config),
        name=f"{DOMAIN}_register_{entry.entry_id}",
    )

    _LOGGER.info(
        "%s entry configured [%s] environment=%s server=%s",
        LOG_PREFIX,
        entry.entry_id,
        entry_config[CONF_ENVIRONMENT],
        entry_config[CONF_SERVER_URL],
    )
    return True


async def async_reload_entry(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Reloads the integration when the config entry options change."""
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Stops the WebSocket client and unloads platforms."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)

    if unload_ok:
        await stop_ws_client(hass, entry.entry_id)

    return unload_ok
