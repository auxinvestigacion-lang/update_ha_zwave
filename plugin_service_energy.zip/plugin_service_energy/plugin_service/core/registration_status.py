"""In-memory last registration result shown on the gateway device page."""

from __future__ import annotations

from collections.abc import Callable

STATUS_UNKNOWN = "unknown"
STATUS_SYNCING = "syncing"
STATUS_OK = "ok"
STATUS_ERROR = "error"

HA_STATE_MAX_LENGTH = 255


class RegistrationStatusStore:
    """Holds the latest registration outcome for the gateway status sensor."""

    def __init__(self) -> None:
        self.status = STATUS_UNKNOWN
        self.state_text = "—"
        self.detail = ""
        self._listeners: list[Callable[[], None]] = []

    def async_listen(self, callback: Callable[[], None]) -> Callable[[], None]:
        """Subscribes to status changes and returns an unsubscribe callback."""
        self._listeners.append(callback)

        def unsubscribe() -> None:
            if callback in self._listeners:
                self._listeners.remove(callback)

        return unsubscribe

    def set_unknown(self, is_spanish: bool) -> None:
        """Sets the initial value before the first synchronization attempt."""
        self.status = STATUS_UNKNOWN
        self.state_text = "Sin sincronizar" if is_spanish else "Not synced yet"
        self.detail = ""
        self._notify()

    def set_syncing(self, is_spanish: bool) -> None:
        """Marks registration as in progress so the installer sees activity."""
        self.status = STATUS_SYNCING
        self.state_text = "Sincronizando…" if is_spanish else "Syncing…"
        self.detail = ""
        self._notify()

    def set_ok(self, is_spanish: bool, warning_summary: str = "", detail: str = "") -> None:
        """Marks registration as accepted; optional warning stays visible on the sensor."""
        self.status = STATUS_OK
        if warning_summary:
            self.state_text = _clip_state_text(warning_summary)
            self.detail = detail or warning_summary
        else:
            self.state_text = "Registro OK" if is_spanish else "Registration OK"
            self.detail = ""
        self._notify()

    def set_error(self, summary: str, detail: str = "") -> None:
        """Stores an installer-visible error; state is clipped to HA limits."""
        self.status = STATUS_ERROR
        self.state_text = _clip_state_text(summary)
        self.detail = detail or summary
        self._notify()

    def _notify(self) -> None:
        """Pushes the new status to every subscribed entity."""
        for listener in list(self._listeners):
            listener()


def _clip_state_text(text: str) -> str:
    """Keeps the sensor state within Home Assistant's 255-character limit."""
    if len(text) <= HA_STATE_MAX_LENGTH:
        return text
    return f"{text[: HA_STATE_MAX_LENGTH - 3]}..."
