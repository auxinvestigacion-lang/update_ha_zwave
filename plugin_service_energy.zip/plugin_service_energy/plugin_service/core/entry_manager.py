"""Runtime config and WebSocket lifecycle management for config entries."""

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from ..api.onboarding import run_onboarding
from ..api.websocket_client import WSClient
from ..const import (
    CONF_ENVIRONMENT,
    CONF_MAC,
    CONF_PROJECT_ID,
    CONF_SERVER_URL,
    CONF_WS_URL,
    DATA_CLIENT,
    DATA_REGISTRATION_STATUS,
    DOMAIN,
    ENV_DEVELOPMENT,
    ENV_PRODUCTION,
    ENVIRONMENT_ENDPOINTS,
    LOG_PREFIX,
    RESP_PROJECT_ID,
)
from .controller_serial import normalize_controller_serial

_LOGGER = logging.getLogger(__name__)


def _option_or_data(entry: ConfigEntry, key: str, default: str = "") -> str:
    """Returns the option value, falling back to entry data then default."""
    if key in entry.options:
        return str(entry.options[key])
    return str(entry.data.get(key, default))


def resolve_environment_endpoints(
    environment: str,
    custom_server_url: str,
    custom_ws_url: str,
) -> tuple[str, str]:
    """Resolves REST and WebSocket URLs for the selected environment."""
    if environment == ENV_DEVELOPMENT:
        return custom_server_url.rstrip("/"), custom_ws_url.rstrip("/")

    endpoints = ENVIRONMENT_ENDPOINTS.get(
        environment, ENVIRONMENT_ENDPOINTS[ENV_PRODUCTION]
    )
    return endpoints[CONF_SERVER_URL], endpoints[CONF_WS_URL]


def build_entry_config(entry: ConfigEntry) -> dict:
    """Builds the runtime config from the config entry and its options."""
    environment = _option_or_data(entry, CONF_ENVIRONMENT, ENV_PRODUCTION)
    server_url, ws_url = resolve_environment_endpoints(
        environment,
        _option_or_data(entry, CONF_SERVER_URL),
        _option_or_data(entry, CONF_WS_URL),
    )
    return {
        CONF_PROJECT_ID: _option_or_data(entry, CONF_PROJECT_ID),
        CONF_MAC: normalize_controller_serial(str(entry.data.get(CONF_MAC, ""))),
        CONF_ENVIRONMENT: environment,
        CONF_SERVER_URL: server_url,
        CONF_WS_URL: ws_url,
    }


def apply_server_response(entry_config: dict, server_response: dict) -> None:
    """Updates local config with values confirmed by the server."""
    confirmed_project_id = server_response.get(RESP_PROJECT_ID)
    if confirmed_project_id:
        entry_config[CONF_PROJECT_ID] = confirmed_project_id


async def register_and_start_client(
    hass: HomeAssistant,
    entry_id: str,
    entry_config: dict,
) -> bool:
    """Waits for Z-Wave readiness, registers with the server, then starts WS."""
    if hass.is_stopping or entry_id not in hass.data.get(DOMAIN, {}):
        return False

    status_store = hass.data[DOMAIN][entry_id].get(DATA_REGISTRATION_STATUS)
    server_response = await run_onboarding(hass, entry_config, status_store)
    if not server_response:
        _LOGGER.error(
            "%s registration failed — WebSocket will not start until "
            "registration succeeds (use the Synchronize devices button)",
            LOG_PREFIX,
        )
        return False

    if hass.is_stopping or entry_id not in hass.data.get(DOMAIN, {}):
        return False

    apply_server_response(entry_config, server_response)
    await start_ws_client(hass, entry_id, entry_config)
    return True


async def start_ws_client(
    hass: HomeAssistant,
    entry_id: str,
    entry_config: dict,
) -> None:
    """Creates or refreshes the WebSocket client for a config entry."""
    entry_data = hass.data[DOMAIN][entry_id]
    existing_client: WSClient | None = entry_data.get(DATA_CLIENT)

    if existing_client:
        if existing_client.is_running:
            await existing_client.refresh_tracked_entities()
            return
        await existing_client.stop()

    client = WSClient(hass, entry_config)
    await client.start()
    entry_data[DATA_CLIENT] = client


async def stop_ws_client(hass: HomeAssistant, entry_id: str) -> None:
    """Stops the WebSocket client for a config entry."""
    entry_data = hass.data[DOMAIN].pop(entry_id, {})
    client: WSClient | None = entry_data.get(DATA_CLIENT)
    if client:
        await client.stop()
