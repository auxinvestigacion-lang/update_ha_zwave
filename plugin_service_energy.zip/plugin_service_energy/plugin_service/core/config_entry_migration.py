"""Migrates stored config entries when the schema version changes."""

from __future__ import annotations

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.entity_registry import async_migrate_entries

from ..const import CONF_MAC, DOMAIN, INTEGRATION_NAME, LOG_PREFIX
from .controller_serial import normalize_controller_serial

_LOGGER = logging.getLogger(__name__)

LEGACY_API_KEY = "api_key"
TARGET_ENTRY_VERSION = 2


async def migrate_config_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Upgrades a config entry to the current schema version."""
    if entry.version >= TARGET_ENTRY_VERSION:
        return True
    if entry.version == 1:
        await _migrate_v1_to_v2(hass, entry)
    return True


async def _migrate_v1_to_v2(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Drops the unused API key and stores an alphanumeric lowercase serial."""
    old_mac = str(entry.data.get(CONF_MAC, ""))
    new_mac = normalize_controller_serial(old_mac) or old_mac
    hass.config_entries.async_update_entry(
        entry,
        data=_without_api_key({**entry.data, CONF_MAC: new_mac}),
        options=_without_api_key(dict(entry.options)),
        unique_id=new_mac or entry.unique_id,
        title=f"{INTEGRATION_NAME} [{new_mac}]" if new_mac else entry.title,
        version=TARGET_ENTRY_VERSION,
    )
    if old_mac and new_mac and old_mac != new_mac:
        await _migrate_mac_identities(hass, entry.entry_id, old_mac, new_mac)
    _LOGGER.info("%s migrated config entry to v2 serial=%s", LOG_PREFIX, new_mac)


def _without_api_key(payload: dict) -> dict:
    """Returns a copy of stored config without the retired API key."""
    return {key: value for key, value in payload.items() if key != LEGACY_API_KEY}


async def _migrate_mac_identities(
    hass: HomeAssistant, entry_id: str, old_mac: str, new_mac: str
) -> None:
    """Keeps gateway device and entity unique_ids aligned with the new serial."""
    prefix = f"{DOMAIN}_{old_mac}_"

    def update_unique_id(entity_entry):
        if not entity_entry.unique_id.startswith(prefix):
            return None
        suffix = entity_entry.unique_id[len(prefix) :]
        return {"new_unique_id": f"{DOMAIN}_{new_mac}_{suffix}"}

    await async_migrate_entries(hass, entry_id, update_unique_id)
    _migrate_gateway_device_identifier(hass, old_mac, new_mac)


def _migrate_gateway_device_identifier(
    hass: HomeAssistant, old_mac: str, new_mac: str
) -> None:
    """Updates the gateway device identifier to the normalized serial."""
    registry = dr.async_get(hass)
    device = registry.async_get_device(identifiers={(DOMAIN, old_mac)})
    if device is None:
        return
    registry.async_update_device(device.id, new_identifiers={(DOMAIN, new_mac)})
