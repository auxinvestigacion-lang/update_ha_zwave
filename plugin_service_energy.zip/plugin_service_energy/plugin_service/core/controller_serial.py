"""Normalizes the controller serial stored and sent to the server."""

from __future__ import annotations

import re

# Serials must be ASCII letters and digits only; colons and other marks are dropped.
_NON_SERIAL_CHARS = re.compile(r"[^a-z0-9]")


def normalize_controller_serial(raw: str | None) -> str:
    """Returns an alphanumeric lowercase serial, or empty when none remains."""
    if not raw:
        return ""
    return _NON_SERIAL_CHARS.sub("", raw.lower())
