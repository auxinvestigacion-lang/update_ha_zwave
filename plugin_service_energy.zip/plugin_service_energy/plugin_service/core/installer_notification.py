"""Persistent notifications so installers see registration success or plugin errors."""

from __future__ import annotations

from homeassistant.core import HomeAssistant

from ..const import DOMAIN, INTEGRATION_NAME
from ..registry.plugin_issue import (
    KIND_PHYSICAL,
    KIND_VIRTUAL,
    REASON_INVALID_ENTITY_ID,
    REASON_MISSING_AREA,
    REASON_MISSING_CONTRACT_HELPERS,
    REASON_MOTEL_AMBIGUOUS_AREA,
    REASON_MULTIPLE_HELPER_INSTANCES,
    REASON_ROOM_MISMATCH,
    PluginValidationIssue,
)
from ..registry.plugin_off_automation import PluginOffWarning

REGISTRATION_NOTIFICATION_ID = f"{DOMAIN}_registration_status"
PERSISTENT_NOTIFICATION_DOMAIN = "persistent_notification"

_INVALID_ENTITY_ID_HINT_ES = (
    "Debe ser automation.plugin_hotel_<sitio>, "
    "automation.plugin_ocupacion_<sitio>, automation.plugin_aula_<sitio>, "
    "automation.bp_plugin_hotel_* o automation.plugin_motel_*."
)
_INVALID_ENTITY_ID_HINT_EN = (
    "It must be automation.plugin_hotel_<site>, "
    "automation.plugin_ocupacion_<site>, automation.plugin_aula_<site>, "
    "automation.bp_plugin_hotel_* or automation.plugin_motel_*."
)


async def notify_plugin_validation_errors(
    hass: HomeAssistant, issues: list[PluginValidationIssue]
) -> None:
    """Shows each inventory validation issue and states that register was blocked."""
    is_spanish = is_installer_language_spanish(hass)
    header = (
        "No se registró el inventario. Corrige estos elementos:"
        if is_spanish
        else "Inventory was not registered. Fix these items:"
    )
    lines = [header, ""]
    lines.extend(format_plugin_validation_issue(issue, is_spanish) for issue in issues)
    await _create_notification(hass, "\n".join(lines))


async def notify_registration_success(
    hass: HomeAssistant,
    off_warnings: list[PluginOffWarning] | None = None,
) -> None:
    """Tells the installer that registration reached the server, plus any off plugins."""
    is_spanish = is_installer_language_spanish(hass)
    message = (
        "Registro completado. El inventario se envió al servidor."
        if is_spanish
        else "Registration completed. Inventory was sent to the server."
    )
    if off_warnings:
        message = f"{message}\n\n{_format_off_warning_block(off_warnings, is_spanish)}"
    await _create_notification(hass, message)


async def notify_registration_failure(hass: HomeAssistant, error_message: str) -> None:
    """Shows a server or connection failure so the installer knows register did not run."""
    is_spanish = is_installer_language_spanish(hass)
    header = (
        "No se registró el inventario."
        if is_spanish
        else "Inventory was not registered."
    )
    await _create_notification(hass, f"{header}\n\n{error_message}")


def is_installer_language_spanish(hass: HomeAssistant) -> bool:
    """Returns True when Home Assistant is configured in Spanish."""
    language = (hass.config.language or "en").lower()
    return language.startswith("es")


def format_plugin_off_issue(warning: PluginOffWarning, is_spanish: bool) -> str:
    """Builds one installer-facing bullet for a plugin automation that is off."""
    body = (
        "está en off y no se envió. Actívala si debe registrarse."
        if is_spanish
        else "is off and was not sent. Turn it on if it should be registered."
    )
    if warning.display_name and warning.display_name != warning.entity_id:
        return f"• {warning.display_name} ({warning.entity_id}): {body}"
    return f"• {warning.entity_id}: {body}"


def _format_off_warning_block(
    off_warnings: list[PluginOffWarning], is_spanish: bool
) -> str:
    """Builds the success-notification section listing off plugin automations."""
    header = (
        "Estas automatizaciones plugin están en off y no se enviaron:"
        if is_spanish
        else "These plugin automations are off and were not sent:"
    )
    bullets = [format_plugin_off_issue(warning, is_spanish) for warning in off_warnings]
    return "\n".join([header, *bullets])


def format_plugin_validation_issue(
    issue: PluginValidationIssue, is_spanish: bool
) -> str:
    """Builds one installer-facing bullet for a registration validation issue."""
    body = _issue_body(issue, is_spanish)
    return f"• {_issue_label(issue)}: {body}"


def _issue_label(issue: PluginValidationIssue) -> str:
    """Returns the name the installer sees for a plugin or device issue."""
    if issue.display_name:
        return issue.display_name
    return issue.entity_id


def _issue_body(issue: PluginValidationIssue, is_spanish: bool) -> str:
    """Returns the reason text for one issue, without the subject prefix."""
    if issue.reason == REASON_INVALID_ENTITY_ID:
        return _invalid_entity_id_body(issue, is_spanish)
    if issue.reason == REASON_MISSING_AREA:
        return _missing_area_body(issue, is_spanish)
    if issue.reason == REASON_MISSING_CONTRACT_HELPERS:
        return (
            "debe referenciar ayudantes {tipo}_{familia}_{sitio} "
            "(state_hotel_hab_202 o state_motel_motel_89; hotel/aula también "
            "mode_ y action_). "
            "Ejemplo: input_select.state_hotel_hab_202."
            if is_spanish
            else "must reference {type}_{family}_{site} helpers "
            "(state_hotel_hab_202 or state_motel_motel_89; hotel/aula also "
            "mode_ and action_). "
            "Example: input_select.state_hotel_hab_202."
        )
    if issue.reason == REASON_MULTIPLE_HELPER_INSTANCES:
        return (
            "referencia ayudantes de más de una habitación o instancia."
            if is_spanish
            else "references helpers from more than one room or instance."
        )
    if issue.reason == REASON_ROOM_MISMATCH:
        return _room_mismatch_body(issue, is_spanish)
    if issue.reason == REASON_MOTEL_AMBIGUOUS_AREA:
        return (
            "hay más de un grupo de plugin en el área; las satélites motel "
            "(_ext/_semaforo) necesitan un único grupo."
            if is_spanish
            else "the area has more than one plugin group; motel satellites "
            "(_ext/_semaforo) need a single group."
        )
    return issue.reason


def _missing_area_body(issue: PluginValidationIssue, is_spanish: bool) -> str:
    """Explains that a plugin or device must be assigned to an area."""
    if issue.subject_kind == KIND_PHYSICAL:
        return (
            "el dispositivo físico no tiene un área asignada."
            if is_spanish
            else "the physical device is not assigned to an area."
        )
    if issue.subject_kind == KIND_VIRTUAL:
        return (
            "el dispositivo virtual no tiene un área asignada."
            if is_spanish
            else "the virtual device is not assigned to an area."
        )
    return (
        "debe estar asignada a un área."
        if is_spanish
        else "must be assigned to an area."
    )


def _invalid_entity_id_body(issue: PluginValidationIssue, is_spanish: bool) -> str:
    """Explains the entity_id contract and optional name-based suggestion."""
    hint = _INVALID_ENTITY_ID_HINT_ES if is_spanish else _INVALID_ENTITY_ID_HINT_EN
    prefix = (
        "el entity_id no cumple el contrato. "
        if is_spanish
        else "the entity_id does not follow the contract. "
    )
    if not issue.expected_entity_id:
        return f"{prefix}{hint}"
    suggestion = (
        f" Según el nombre, debería ser {issue.expected_entity_id}."
        if is_spanish
        else f" Based on the name, it should be {issue.expected_entity_id}."
    )
    return f"{prefix}{hint}{suggestion}"


def _room_mismatch_body(issue: PluginValidationIssue, is_spanish: bool) -> str:
    """Explains that the entity_id site does not match the helper room."""
    room = issue.helper_room_key or "?"
    if is_spanish:
        return f"el sitio del entity_id no coincide con los ayudantes ({room})."
    return f"the entity_id site does not match the helpers ({room})."


async def _create_notification(hass: HomeAssistant, message: str) -> None:
    """Creates or replaces the registration status persistent notification."""
    await hass.services.async_call(
        PERSISTENT_NOTIFICATION_DOMAIN,
        "create",
        {
            "title": INTEGRATION_NAME,
            "message": message,
            "notification_id": REGISTRATION_NOTIFICATION_ID,
        },
    )
