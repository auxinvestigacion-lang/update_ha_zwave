"""Unit tests for controller serial normalization."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from core.controller_serial import normalize_controller_serial


class TestNormalizeControllerSerial_AlphanumericLower_ExpectedResult(unittest.TestCase):
    """The server only accepts lowercase letters and digits as the serial."""

    def test_normalize_controller_serial_ColonMac_StripsAndLowercases(self) -> None:
        self.assertEqual(
            normalize_controller_serial("AA:BB:CC:11:22:33"),
            "aabbcc112233",
        )

    def test_normalize_controller_serial_HyphenAndSpace_Strips(self) -> None:
        self.assertEqual(
            normalize_controller_serial(" SN-12 34 "),
            "sn1234",
        )

    def test_normalize_controller_serial_AlreadyClean_ReturnsSame(self) -> None:
        self.assertEqual(normalize_controller_serial("abc123"), "abc123")

    def test_normalize_controller_serial_SymbolsOnly_ReturnsEmpty(self) -> None:
        self.assertEqual(normalize_controller_serial(":::---"), "")
        self.assertEqual(normalize_controller_serial(None), "")
        self.assertEqual(normalize_controller_serial(""), "")


if __name__ == "__main__":
    unittest.main()
