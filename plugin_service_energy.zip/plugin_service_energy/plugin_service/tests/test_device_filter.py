"""Unit tests for WiFi Module / integration-hub name detection."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from registry.device_hub_names import is_wifi_module_device_name


class TestIsWifiModuleDeviceName_IntegrationHub_ExpectedResult(unittest.TestCase):
    """The WiFi Module integration must not be treated as room hardware."""

    def test_is_wifi_module_device_name_ExactName_ReturnsTrue(self) -> None:
        self.assertTrue(is_wifi_module_device_name("WiFi Module"))

    def test_is_wifi_module_device_name_Hyphenated_ReturnsTrue(self) -> None:
        self.assertTrue(is_wifi_module_device_name("Wi-Fi Module"))

    def test_is_wifi_module_device_name_Thermostat_ReturnsFalse(self) -> None:
        self.assertFalse(is_wifi_module_device_name("Thermostat"))

    def test_is_wifi_module_device_name_Empty_ReturnsFalse(self) -> None:
        self.assertFalse(is_wifi_module_device_name(None))
        self.assertFalse(is_wifi_module_device_name(""))


if __name__ == "__main__":
    unittest.main()
