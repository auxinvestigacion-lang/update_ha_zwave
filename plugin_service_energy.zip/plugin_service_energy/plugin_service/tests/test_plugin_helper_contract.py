"""Unit tests for {type}_{family}_{site} plugin helper entity_ids."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from registry.plugin_helper_contract import (
    PLUGIN_HELPER_FAMILY_AULA,
    PLUGIN_HELPER_FAMILY_HOTEL,
    PLUGIN_HELPER_FAMILY_MOTEL,
    helper_site_token,
    parse_plugin_helper_identity,
)


class TestParsePluginHelperIdentity_FamilySite_ExpectedResult(unittest.TestCase):
    """Helpers must encode type, family and site; the old stem-only form is rejected."""

    def test_parse_plugin_helper_identity_HotelTrio_ReturnsHotelHab(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_hotel_hab_302")
        self.assertIsNotNone(identity)
        self.assertEqual(identity.helper_type, "state")
        self.assertEqual(identity.family, PLUGIN_HELPER_FAMILY_HOTEL)
        self.assertEqual(identity.room_key, "hab_302")
        self.assertEqual(identity.instance, 1)

        mode = parse_plugin_helper_identity("input_select.mode_hotel_hab_302")
        self.assertEqual(mode.helper_type, "mode")
        action = parse_plugin_helper_identity("input_select.action_hotel_hab_302")
        self.assertEqual(action.helper_type, "action")

    def test_parse_plugin_helper_identity_HotelInstanceTwo_ReturnsInstance(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_hotel_hab_302_2")
        self.assertIsNotNone(identity)
        self.assertEqual(identity.room_key, "hab_302")
        self.assertEqual(identity.instance, 2)
        self.assertEqual(helper_site_token(identity), "hab_302_2")

    def test_parse_plugin_helper_identity_Aula_ReturnsAulaLab(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_aula_lab_3")
        self.assertIsNotNone(identity)
        self.assertEqual(identity.family, PLUGIN_HELPER_FAMILY_AULA)
        self.assertEqual(identity.room_key, "lab_3")

    def test_parse_plugin_helper_identity_MotelState_ReturnsMotelSite(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_motel_motel_89")
        self.assertIsNotNone(identity)
        self.assertEqual(identity.helper_type, "state")
        self.assertEqual(identity.family, PLUGIN_HELPER_FAMILY_MOTEL)
        self.assertEqual(identity.room_key, "motel_89")
        self.assertEqual(identity.instance, 1)
        self.assertEqual(helper_site_token(identity), "motel_89")

    def test_parse_plugin_helper_identity_SpanishEstadoHotel_ReturnsHotel(self) -> None:
        identity = parse_plugin_helper_identity("input_select.estado_hotel_hab_302")
        self.assertIsNotNone(identity)
        self.assertEqual(identity.helper_type, "estado")
        self.assertEqual(identity.family, PLUGIN_HELPER_FAMILY_HOTEL)

    def test_parse_plugin_helper_identity_LegacyWithoutFamily_ReturnsNone(self) -> None:
        self.assertIsNone(parse_plugin_helper_identity("input_select.state_hab_302"))
        self.assertIsNone(parse_plugin_helper_identity("input_select.modo_motel"))
        self.assertIsNone(parse_plugin_helper_identity("input_select.estado_texto"))


if __name__ == "__main__":
    unittest.main()
