"""Unit tests for the short registration-status sensor summary."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from registry.plugin_error_summary import (
    format_plugin_off_summary,
    format_plugin_status_summary,
)
from registry.plugin_issue import (
    KIND_PHYSICAL,
    REASON_INVALID_ENTITY_ID,
    REASON_MISSING_AREA,
    REASON_MISSING_CONTRACT_HELPERS,
    PluginValidationIssue,
)


class TestFormatPluginStatusSummary_InstallerText_ExpectedResult(unittest.TestCase):
    """The gateway sensor must name the plugin and point to notifications."""

    def test_format_plugin_status_summary_MissingHelpersSpanish_IncludesEntityAndHint(
        self,
    ) -> None:
        issues = [
            PluginValidationIssue(
                "automation.bp_plugin_hotel_v1_3_4_1",
                REASON_MISSING_CONTRACT_HELPERS,
            )
        ]
        summary = format_plugin_status_summary(issues, is_spanish=True)
        self.assertIn("automation.bp_plugin_hotel_v1_3_4_1", summary)
        self.assertIn("ayudantes {tipo}_{familia}_{sitio}", summary)
        self.assertIn("Revisa las notificaciones para más detalle", summary)
        self.assertLessEqual(len(summary), 255)

    def test_format_plugin_status_summary_MultipleIssues_IncludesCount(
        self,
    ) -> None:
        issues = [
            PluginValidationIssue(
                "automation.luces_hab_202", REASON_INVALID_ENTITY_ID
            ),
            PluginValidationIssue(
                "automation.plugin_aula_lab", REASON_MISSING_CONTRACT_HELPERS
            ),
        ]
        summary = format_plugin_status_summary(issues, is_spanish=True)
        self.assertTrue(summary.startswith("Error: 2 elementos."))
        self.assertIn("automation.luces_hab_202", summary)
        self.assertIn("Revisa las notificaciones para más detalle", summary)

    def test_format_plugin_status_summary_PhysicalMissingArea_UsesDeviceName(
        self,
    ) -> None:
        issues = [
            PluginValidationIssue(
                entity_id="device-abc",
                reason=REASON_MISSING_AREA,
                subject_kind=KIND_PHYSICAL,
                display_name="Thermostat",
            )
        ]
        summary = format_plugin_status_summary(issues, is_spanish=True)
        self.assertIn("Thermostat", summary)
        self.assertIn("no tiene un área asignada", summary)
        self.assertIn("Revisa las notificaciones para más detalle", summary)

    def test_format_plugin_status_summary_English_PointsToNotifications(self) -> None:
        issues = [
            PluginValidationIssue(
                "automation.plugin_hotel_hab_202",
                REASON_MISSING_CONTRACT_HELPERS,
            )
        ]
        summary = format_plugin_status_summary(issues, is_spanish=False)
        self.assertIn("Check notifications for more detail", summary)


class TestFormatPluginOffSummary_InstallerText_ExpectedResult(unittest.TestCase):
    """Successful register still names off plugin automations on the sensor."""

    def test_format_plugin_off_summary_SingleSpanish_IncludesEntityAndHint(self) -> None:
        summary = format_plugin_off_summary(
            ["automation.plugin_hotel_hab_202"], is_spanish=True
        )
        self.assertTrue(summary.startswith("Registro OK."))
        self.assertIn("automation.plugin_hotel_hab_202", summary)
        self.assertIn("está en off", summary)
        self.assertIn("Revisa las notificaciones para más detalle", summary)
        self.assertLessEqual(len(summary), 255)

    def test_format_plugin_off_summary_Multiple_IncludesCount(self) -> None:
        summary = format_plugin_off_summary(
            [
                "automation.plugin_hotel_hab_201",
                "automation.plugin_aula_lab",
            ],
            is_spanish=True,
        )
        self.assertTrue(summary.startswith("Registro OK. 2 automatizaciones en off."))
        self.assertIn("automation.plugin_hotel_hab_201", summary)

    def test_format_plugin_off_summary_English_PointsToNotifications(self) -> None:
        summary = format_plugin_off_summary(
            ["automation.plugin_hotel_hab_202"], is_spanish=False
        )
        self.assertTrue(summary.startswith("Registration OK."))
        self.assertIn("is off and was not sent", summary)
        self.assertIn("Check notifications for more detail", summary)


if __name__ == "__main__":
    unittest.main()
