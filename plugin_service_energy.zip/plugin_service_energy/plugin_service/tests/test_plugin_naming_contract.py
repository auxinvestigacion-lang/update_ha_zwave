"""Unit tests for plugin entity_id and friendly-name contracts."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from registry.plugin_helper_contract import (
    PLUGIN_HELPER_FAMILY_HOTEL,
    PLUGIN_HELPER_FAMILY_MOTEL,
    parse_plugin_helper_identity,
)
from registry.plugin_naming_contract import (
    extract_motel_site,
    extract_occupancy_site,
    extract_plugin_helper_family,
    is_plugin_automation_candidate,
    is_scene_automation_candidate,
    is_scene_automation_entity_id,
    is_valid_plugin_entity_id,
    looks_like_plugin_friendly_name,
    looks_like_scene_friendly_name,
    occupancy_site_matches_helper_room,
    plugin_automation_matches_helper,
    plugin_group_has_valid_entity_ids,
    suggest_plugin_entity_id_from_name,
)


class TestIsValidPluginEntityId_Occupancy_ExpectedResult(unittest.TestCase):
    """Occupancy/aula entity_ids are accepted; incomplete prefixes are not."""

    def test_is_valid_plugin_entity_id_HotelHab_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_valid_plugin_entity_id("automation.plugin_hotel_hab_202")
        )

    def test_is_valid_plugin_entity_id_OcupacionHab_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_valid_plugin_entity_id("automation.plugin_ocupacion_hab_202")
        )

    def test_is_valid_plugin_entity_id_AulaSite_ReturnsTrue(self) -> None:
        self.assertTrue(is_valid_plugin_entity_id("automation.plugin_aula_lab_3"))

    def test_is_valid_plugin_entity_id_LegacyHotel_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_valid_plugin_entity_id("automation.bp_plugin_hotel_v1_3_2_8")
        )

    def test_is_valid_plugin_entity_id_HotelWithoutSite_ReturnsFalse(self) -> None:
        self.assertFalse(is_valid_plugin_entity_id("automation.plugin_hotel"))
        self.assertFalse(is_valid_plugin_entity_id("automation.plugin_hotel_"))

    def test_is_valid_plugin_entity_id_UnrelatedAutomation_ReturnsFalse(self) -> None:
        self.assertFalse(is_valid_plugin_entity_id("automation.luces_hab_202"))

    def test_is_valid_plugin_entity_id_EnglishOccupancyPrefix_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_valid_plugin_entity_id("automation.plugin_occupancy_hab_202")
        )


class TestIsValidPluginEntityId_Motel_ExpectedResult(unittest.TestCase):
    """Motel role automations keep the existing plugin_motel_* contract."""

    def test_is_valid_plugin_entity_id_MotelRoles_ReturnsTrue(self) -> None:
        self.assertTrue(is_valid_plugin_entity_id("automation.plugin_motel_main"))
        self.assertTrue(is_valid_plugin_entity_id("automation.plugin_motel_ext"))
        self.assertTrue(
            is_valid_plugin_entity_id("automation.plugin_motel_semaforo")
        )

    def test_is_valid_plugin_entity_id_MotelInstance_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_valid_plugin_entity_id("automation.plugin_motel_2_main")
        )

    def test_is_valid_plugin_entity_id_MotelRoleThenArea_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_valid_plugin_entity_id("automation.plugin_motel_main_motel_89")
        )
        self.assertTrue(
            is_valid_plugin_entity_id("automation.plugin_motel_ext_motel_89")
        )


class TestLooksLikePluginFriendlyName_Priority_ExpectedResult(unittest.TestCase):
    """A correct name is not enough; it only identifies a misconfigured plugin."""

    def test_looks_like_plugin_friendly_name_OcupacionWithAccent_ReturnsTrue(self) -> None:
        self.assertTrue(looks_like_plugin_friendly_name("Plugin Ocupación Hab 202"))

    def test_looks_like_plugin_friendly_name_Aula_ReturnsTrue(self) -> None:
        self.assertTrue(looks_like_plugin_friendly_name("Plugin Aula Lab 3"))

    def test_looks_like_plugin_friendly_name_LegacyBpPlugin_ReturnsFalse(self) -> None:
        self.assertFalse(looks_like_plugin_friendly_name("Bp Plugin v1.2.3.4"))

    def test_suggest_plugin_entity_id_from_name_OcupacionHab_ReturnsContractId(self) -> None:
        self.assertEqual(
            suggest_plugin_entity_id_from_name("Plugin Ocupacion Hab 202"),
            "automation.plugin_ocupacion_hab_202",
        )

    def test_is_valid_plugin_entity_id_NameOnlyDoesNotValidateId_ReturnsFalse(self) -> None:
        self.assertTrue(looks_like_plugin_friendly_name("Plugin Ocupacion Hab 202"))
        self.assertFalse(is_valid_plugin_entity_id("automation.luces_hab_202"))


class TestIsPluginAutomationCandidate_NameOrEntityId_ExpectedResult(unittest.TestCase):
    """Off-plugin warnings and validation share the same candidate rule."""

    def test_is_plugin_automation_candidate_ValidEntityId_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_plugin_automation_candidate("automation.plugin_hotel_hab_202")
        )

    def test_is_plugin_automation_candidate_NameOnly_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_plugin_automation_candidate(
                "automation.luces_hab_202", "Plugin Ocupación Hab 202"
            )
        )

    def test_is_plugin_automation_candidate_Unrelated_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_plugin_automation_candidate("automation.luces_pasillo", "Luces pasillo")
        )

    def test_is_plugin_automation_candidate_SceneEntityId_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_plugin_automation_candidate(
                "automation.escena_hab_202", "Escena Hab 202"
            )
        )

    def test_is_plugin_automation_candidate_SceneNameOnly_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_plugin_automation_candidate(
                "automation.luces_hab_202", "Escena Hab 202"
            )
        )


class TestIsSceneAutomation_NamingContract_ExpectedResult(unittest.TestCase):
    """Scene automations are recognized by entity_id or Escena|Scene name."""

    def test_is_scene_automation_entity_id_SpanishSite_ReturnsTrue(self) -> None:
        self.assertTrue(is_scene_automation_entity_id("automation.escena_hab_202"))

    def test_is_scene_automation_entity_id_EnglishSite_ReturnsTrue(self) -> None:
        self.assertTrue(is_scene_automation_entity_id("automation.scene_living"))

    def test_is_scene_automation_entity_id_PrefixOnly_ReturnsTrue(self) -> None:
        self.assertTrue(is_scene_automation_entity_id("automation.escena"))
        self.assertTrue(is_scene_automation_entity_id("automation.scene"))

    def test_is_scene_automation_entity_id_Plugin_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_scene_automation_entity_id("automation.plugin_hotel_hab_202")
        )

    def test_is_scene_automation_entity_id_Escenario_ReturnsFalse(self) -> None:
        self.assertFalse(is_scene_automation_entity_id("automation.escenario_teatro"))

    def test_looks_like_scene_friendly_name_Spanish_ReturnsTrue(self) -> None:
        self.assertTrue(looks_like_scene_friendly_name("Escena Hab 202"))

    def test_looks_like_scene_friendly_name_English_ReturnsTrue(self) -> None:
        self.assertTrue(looks_like_scene_friendly_name("Scene living"))

    def test_looks_like_scene_friendly_name_Escenario_ReturnsFalse(self) -> None:
        self.assertFalse(looks_like_scene_friendly_name("Escenario teatro"))

    def test_is_scene_automation_candidate_PluginEntityId_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_scene_automation_candidate(
                "automation.plugin_hotel_hab_202", "Escena Hab 202"
            )
        )

    def test_is_scene_automation_candidate_SceneIdPluginName_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_scene_automation_candidate(
                "automation.escena_hab_202", "Plugin Ocupación Hab 202"
            )
        )


class TestOccupancySiteMatchesHelperRoom_LegacyAndNew_ExpectedResult(unittest.TestCase):
    """New occupancy ids must match helper room; legacy hotel does not."""

    def test_extract_occupancy_site_HotelHab_ReturnsNormalizedSite(self) -> None:
        self.assertEqual(
            extract_occupancy_site("automation.plugin_hotel_hab_202"), "hab_202"
        )

    def test_occupancy_site_matches_helper_room_SameSite_ReturnsTrue(self) -> None:
        self.assertTrue(
            occupancy_site_matches_helper_room(
                "automation.plugin_ocupacion_hab_202", "hab_202"
            )
        )

    def test_occupancy_site_matches_helper_room_DifferentSite_ReturnsFalse(self) -> None:
        self.assertFalse(
            occupancy_site_matches_helper_room(
                "automation.plugin_hotel_hab_202", "hab_201"
            )
        )

    def test_occupancy_site_matches_helper_room_LegacyHotel_ReturnsTrue(self) -> None:
        self.assertTrue(
            occupancy_site_matches_helper_room(
                "automation.bp_plugin_hotel_v1_3_2_8", "hab_202"
            )
        )

    def test_extract_motel_site_RoleThenSite_ReturnsMotelSite(self) -> None:
        self.assertEqual(
            extract_motel_site("automation.plugin_motel_main_motel_89"),
            "motel_89",
        )
        self.assertEqual(
            extract_motel_site("automation.plugin_motel_ext_motel_89"),
            "motel_89",
        )

    def test_extract_motel_site_LegacyMainOnly_ReturnsNone(self) -> None:
        self.assertIsNone(extract_motel_site("automation.plugin_motel_main"))

    def test_occupancy_site_matches_helper_room_MotelSite_ReturnsTrue(self) -> None:
        self.assertTrue(
            occupancy_site_matches_helper_room(
                "automation.plugin_motel_main_motel_89", "motel_89"
            )
        )

    def test_plugin_automation_matches_helper_Hotel_ReturnsTrue(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_hotel_hab_202")
        self.assertTrue(
            plugin_automation_matches_helper(
                "automation.plugin_hotel_hab_202", identity
            )
        )

    def test_plugin_automation_matches_helper_HotelWrongRoom_ReturnsFalse(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_hotel_hab_201")
        self.assertFalse(
            plugin_automation_matches_helper(
                "automation.plugin_hotel_hab_202", identity
            )
        )

    def test_plugin_automation_matches_helper_Motel_ReturnsTrue(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_motel_motel_89")
        self.assertTrue(
            plugin_automation_matches_helper(
                "automation.plugin_motel_main_motel_89", identity
            )
        )
        self.assertEqual(extract_plugin_helper_family(
            "automation.plugin_motel_main_motel_89"
        ), PLUGIN_HELPER_FAMILY_MOTEL)

    def test_plugin_automation_matches_helper_HotelVsMotelFamily_ReturnsFalse(self) -> None:
        identity = parse_plugin_helper_identity("input_select.state_motel_motel_89")
        self.assertFalse(
            plugin_automation_matches_helper(
                "automation.plugin_hotel_hab_202", identity
            )
        )
        self.assertEqual(
            extract_plugin_helper_family("automation.plugin_hotel_hab_202"),
            PLUGIN_HELPER_FAMILY_HOTEL,
        )

    def test_plugin_group_has_valid_entity_ids_MixedGroup_ReturnsFalse(self) -> None:
        self.assertFalse(
            plugin_group_has_valid_entity_ids(
                [
                    "automation.plugin_hotel_hab_202",
                    "automation.luces_hab_202",
                    "input_select.state_hotel_hab_202",
                ]
            )
        )

    def test_plugin_group_has_valid_entity_ids_SceneInGroup_ReturnsFalse(self) -> None:
        self.assertFalse(
            plugin_group_has_valid_entity_ids(
                [
                    "automation.plugin_hotel_hab_202",
                    "automation.escena_hab_202",
                    "input_select.state_hotel_hab_202",
                ]
            )
        )

    def test_plugin_group_has_valid_entity_ids_LegacyAndHelpers_ReturnsTrue(self) -> None:
        self.assertTrue(
            plugin_group_has_valid_entity_ids(
                [
                    "automation.bp_plugin_hotel_v1_3_2_8",
                    "input_select.state_hotel_hab_202",
                ]
            )
        )


if __name__ == "__main__":
    unittest.main()
