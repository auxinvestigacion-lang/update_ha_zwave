"""Unit tests for motel role tokens and logical-device primary selection."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from registry.plugin_family import (
    PLUGIN_ROLE_EXT,
    PLUGIN_ROLE_MAIN,
    PLUGIN_ROLE_SEMAFORO,
    get_plugin_role,
    is_plugin_primary_automation,
    is_plugin_satellite_automation,
    select_primary_plugin_automation,
)


class _Automation:
    def __init__(self, entity_id: str) -> None:
        self.entity_id = entity_id


class TestGetPluginRole_TokenNotSuffix_ExpectedResult(unittest.TestCase):
    """Roles stay valid when the area is appended after main/ext/semaforo."""

    def test_get_plugin_role_LegacySuffix_ReturnsRole(self) -> None:
        self.assertEqual(get_plugin_role("automation.plugin_motel_main"), PLUGIN_ROLE_MAIN)
        self.assertEqual(get_plugin_role("automation.plugin_motel_ext"), PLUGIN_ROLE_EXT)
        self.assertEqual(
            get_plugin_role("automation.plugin_motel_semaforo"), PLUGIN_ROLE_SEMAFORO
        )

    def test_get_plugin_role_RoleThenArea_ReturnsRole(self) -> None:
        self.assertEqual(
            get_plugin_role("automation.plugin_motel_main_motel_89"),
            PLUGIN_ROLE_MAIN,
        )
        self.assertEqual(
            get_plugin_role("automation.plugin_motel_ext_motel_89"),
            PLUGIN_ROLE_EXT,
        )
        self.assertEqual(
            get_plugin_role("automation.plugin_motel_semaforo_motel_89"),
            PLUGIN_ROLE_SEMAFORO,
        )

    def test_get_plugin_role_InstanceThenMain_ReturnsMain(self) -> None:
        self.assertEqual(
            get_plugin_role("automation.plugin_motel_2_main"), PLUGIN_ROLE_MAIN
        )

    def test_get_plugin_role_OccupancyHotel_ReturnsNone(self) -> None:
        self.assertIsNone(get_plugin_role("automation.plugin_hotel_hab_202"))


class TestSelectPrimaryPluginAutomation_MotelWithArea_ExpectedResult(unittest.TestCase):
    """The logical device must be owned by main, not by ext alphabetically."""

    def test_select_primary_plugin_automation_AreaSuffix_PicksMain(self) -> None:
        chosen = select_primary_plugin_automation(
            [
                _Automation("automation.plugin_motel_ext_motel_89"),
                _Automation("automation.plugin_motel_main_motel_89"),
                _Automation("automation.plugin_motel_semaforo_motel_89"),
            ]
        )
        self.assertEqual(chosen.entity_id, "automation.plugin_motel_main_motel_89")

    def test_is_plugin_satellite_automation_ExtWithArea_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_plugin_satellite_automation("automation.plugin_motel_ext_motel_89")
        )
        self.assertFalse(
            is_plugin_primary_automation("automation.plugin_motel_ext_motel_89")
        )

    def test_is_plugin_primary_automation_MainWithArea_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_plugin_primary_automation("automation.plugin_motel_main_motel_89")
        )


if __name__ == "__main__":
    unittest.main()
