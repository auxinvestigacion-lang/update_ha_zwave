"""Unit tests for off plugin-automation detection (non-blocking warnings)."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from registry.plugin_off_match import is_off_plugin_automation


class TestIsOffPluginAutomation_ToggleOff_ExpectedResult(unittest.TestCase):
    """Only plugin-candidate automations that are off should be announced."""

    def test_is_off_plugin_automation_ValidIdOff_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_off_plugin_automation(
                "automation.plugin_hotel_hab_202",
                "automation",
                "off",
                "Plugin Hotel Hab 202",
            )
        )

    def test_is_off_plugin_automation_ValidIdOn_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_off_plugin_automation(
                "automation.plugin_hotel_hab_202",
                "automation",
                "on",
                "Plugin Hotel Hab 202",
            )
        )

    def test_is_off_plugin_automation_UnrelatedOff_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_off_plugin_automation(
                "automation.luces_pasillo",
                "automation",
                "off",
                "Luces pasillo",
            )
        )

    def test_is_off_plugin_automation_NameOnlyOff_ReturnsTrue(self) -> None:
        self.assertTrue(
            is_off_plugin_automation(
                "automation.luces_hab_202",
                "automation",
                "off",
                "Plugin Ocupación Hab 202",
            )
        )

    def test_is_off_plugin_automation_SceneOff_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_off_plugin_automation(
                "automation.escena_hab_202",
                "automation",
                "off",
                "Escena Hab 202",
            )
        )

    def test_is_off_plugin_automation_MissingState_ReturnsFalse(self) -> None:
        self.assertFalse(
            is_off_plugin_automation(
                "automation.plugin_hotel_hab_202",
                "automation",
                None,
                "Plugin Hotel Hab 202",
            )
        )


if __name__ == "__main__":
    unittest.main()
