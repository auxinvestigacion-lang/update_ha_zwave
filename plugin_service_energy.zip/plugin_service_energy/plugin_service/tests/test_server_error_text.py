"""Unit tests for registration HTTP error text extraction."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from api.server_error_text import extract_server_error_text, format_registration_http_error


class TestFormatRegistrationHttpError_ServerBody_ExpectedResult(unittest.TestCase):
    """Installers must see the server message, not only a silent HTTP failure."""

    def test_format_registration_http_error_JsonMessage_IncludesStatusAndText(self) -> None:
        formatted = format_registration_http_error(
            422, '{"message": "serial already registered"}'
        )
        self.assertEqual(formatted, "HTTP 422: serial already registered")

    def test_format_registration_http_error_NestedError_UsesDetail(self) -> None:
        formatted = format_registration_http_error(
            400, '{"error": {"detail": "invalid project"}}'
        )
        self.assertEqual(formatted, "HTTP 400: invalid project")

    def test_format_registration_http_error_PlainText_UsesSnippet(self) -> None:
        formatted = format_registration_http_error(500, "  Internal boom  ")
        self.assertEqual(formatted, "HTTP 500: Internal boom")

    def test_format_registration_http_error_EmptyBody_StatusOnly(self) -> None:
        self.assertEqual(format_registration_http_error(401, ""), "HTTP 401")

    def test_extract_server_error_text_ErrorsList_JoinsEntries(self) -> None:
        extracted = extract_server_error_text(
            '{"errors": ["missing serial", "bad mac"]}'
        )
        self.assertEqual(extracted, "missing serial; bad mac")


if __name__ == "__main__":
    unittest.main()
