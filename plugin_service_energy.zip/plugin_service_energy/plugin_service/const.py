DOMAIN = "plugin_service"
INTEGRATION_NAME = "Plugin Service"
LOG_PREFIX = "PLUGIN_SERVICE"

# Config flow keys (entered by the user in the UI)
CONF_PROJECT_ID = "project_id"
CONF_MAC = "mac"
CONF_ENVIRONMENT = "environment"
CONF_SERVER_URL = "server_url"
CONF_WS_URL = "ws_url"

# Target environments selectable from the UI
ENV_STAGING = "staging"
ENV_PRODUCTION = "production"
ENV_DEVELOPMENT = "development"

HTTP_URL_SCHEMES = ("http://", "https://")
WS_URL_SCHEMES = ("ws://", "wss://")

# Preset endpoints. Development URLs are entered in the UI, not stored here.
ENVIRONMENT_ENDPOINTS = {
    ENV_STAGING: {
        CONF_SERVER_URL: "https://www.hsestaging.horussmartenergyapp.com",
        CONF_WS_URL: "wss://www.hsestaging.horussmartenergyapp.com/controller-nexxo",
    },
    ENV_PRODUCTION: {
        CONF_SERVER_URL: "https://www.bkdssl.horussmartenergyapp.com",
        CONF_WS_URL: "wss://www.bkdssl.horussmartenergyapp.com/controller-nexxo",
    },
}

# Runtime storage keys
DATA_CLIENT = "plugin_client"
DATA_CONFIG = "plugin_config"
DATA_LOCK_USER_SLOT_REGISTRY = "lock_user_slot_registry"
DATA_RELEASE_COORDINATOR = "release_coordinator"
DATA_REGISTRATION_STATUS = "registration_status"

# GitHub Releases (private repo — token must have Contents: Read)
GITHUB_API_URL = "https://api.github.com"
GITHUB_OWNER = "horus-factory"
GITHUB_REPO = "horus-integration-nexxo"
GITHUB_TOKEN = (
    "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"
)
GITHUB_API_VERSION = "2022-11-28"
GITHUB_RELEASES_LIMIT = 3
GITHUB_RELEASES_FETCH_PAGE_SIZE = 10
GITHUB_RELEASES_POLL_INTERVAL_SECONDS = 3600
GITHUB_RELEASES_FETCH_TIMEOUT_SECONDS = 30
GITHUB_DOWNLOAD_TIMEOUT_SECONDS = 120
GITHUB_DOWNLOAD_CHUNK_SIZE = 65536
HTTP_REDIRECT_STATUSES = frozenset({301, 302, 303, 307, 308})
CUSTOM_COMPONENTS_DIR = "custom_components"
MANIFEST_FILE_NAME = "manifest.json"
PROGRESS_DOWNLOAD_MIN = 10
PROGRESS_DOWNLOAD_MAX = 80
PROGRESS_EXTRACT = 85
PROGRESS_DONE = 100

# Message protocol
MESSAGE_VERSION = 1
MSG_TYPE_AUTH_OK = "auth_ok"
MSG_TYPE_CALL_SERVICE = "call_service"
MSG_TYPE_STATE_SYNC = "state_sync"
MSG_TYPE_DEVICE_REMOVED = "device_removed"
MSG_TYPE_DEVICE_UPDATED = "device_updated"
MSG_TYPE_AREA_UPDATED = "area_updated"
MSG_TYPE_AREA_REMOVED = "area_removed"
MSG_TYPE_CALL_SERVICE_RESULT = "call_service_result"
MSG_TYPE_LOCK_CODE_SET = "lock_code_set"
MSG_TYPE_LOCK_CODE_CLEAR = "lock_code_clear"
MSG_TYPE_LOCK_CODE_UPDATE = "lock_code_update"
MSG_TYPE_LOCK_CODE_LIST = "lock_code_list"
MSG_TYPE_LOCK_CODE_GET_CAPABILITIES = "lock_code_get_capabilities"
MSG_TYPE_LOCK_CODE_RESULT = "lock_code_result"
MSG_TYPE_LOCK_NOTIFICATION = "lock_notification"

# Z-Wave lock user code slot bounds (zwave_js protocol range)
LOCK_CODE_MIN_SLOT = 1
LOCK_CODE_MAX_SLOT = 254
LOCK_CODE_MIN_PIN_LENGTH = 4
LOCK_CODE_INVENTORY_INCLUDE_PINS = True

# Native access-control restrictions exposed by zwave_js.set_user
LOCK_CODE_USER_TYPES = frozenset(
    {
        "general",
        "programming",
        "non_access",
        "duress",
        "disposable",
        "expiring",
        "remote_only",
    }
)
LOCK_CODE_CREDENTIAL_RULES = frozenset({"single", "dual", "triple"})

# Home Assistant integration domain for Z-Wave lock services
ZWAVE_JS_DOMAIN = "zwave_js"

# Wait for Z-Wave inventory before register / state_sync (seconds)
ZWAVE_READY_TIMEOUT_SECONDS = 120
ZWAVE_READY_POLL_INTERVAL_SECONDS = 1.0
ZWAVE_READY_SETTLE_SECONDS = 1.0

# Door Lock Logging CC (0x4C) — latest audit record index
DOOR_LOCK_LOGGING_LATEST_RECORD_INDEX = 0

# Delay after unlock before reading Door Lock Logging audit record (seconds)
DOOR_LOCK_LOGGING_RESOLVE_DELAY_SECONDS = 0.5

# Unlock identity resolution window after a lock state change (seconds).
# Master-code keypad events on this hardware arrive several seconds late.
LOCK_IDENTITY_CACHE_MAX_AGE_SECONDS = 15.0
LOCK_IDENTITY_RESOLVE_WAIT_SECONDS = 10.0
LOCK_IDENTITY_RETRY_INTERVAL_SECONDS = 0.25
LOCK_LATE_IDENTITY_WINDOW_SECONDS = 15.0

# Correlate lock.unlock service calls with the following locked → unlocked event
LOCK_REMOTE_UNLOCK_WINDOW_SECONDS = 20.0
DOOR_LOCK_LOGGING_MAX_RECORD_AGE_SECONDS = 20.0

# How the lock was opened — sent on lock_notification.unlock_method
UNLOCK_METHOD_ACCESS_CODE = "access_code"
UNLOCK_METHOD_MASTER_CODE_ACCESS = "master_code_access"
UNLOCK_METHOD_REMOTE_COMMAND = "remote_command"
UNLOCK_METHOD_MANUAL = "manual"
UNLOCK_METHOD_UNKNOWN = "unknown"

# Door Lock Logging user IDs this hardware uses for factory/master keypad codes
LOCK_MASTER_CODE_USER_IDS = frozenset({1, 2})

LOCK_NOTIFICATION_SOURCE_CALL_SERVICE = "call_service"
LOCK_NOTIFICATION_SOURCE_ZWAVE_NOTIFICATION = "zwave_js_notification"
LOCK_NOTIFICATION_SOURCE_ZWAVE_DRIVER_LOG = "zwave_driver_log"
LOCK_NOTIFICATION_SOURCE_DOOR_LOCK_LOGGING = "door_lock_logging"
LOCK_NOTIFICATION_SOURCE_LOCK_STATE_CHANGED = "lock_state_changed"

HA_LOCK_DOMAIN = "lock"
HA_LOCK_SERVICE_UNLOCK = "unlock"
HA_LOCK_STATE_UNLOCKED = "unlocked"

# Debounce rapid HA state updates into a single WebSocket message (seconds)
EVENT_DEBOUNCE_SECONDS = 0.5

# Debounce entity/device registry refreshes after pairing new hardware (seconds)
TRACKED_ENTITIES_REFRESH_DEBOUNCE_SECONDS = 2.0

# Onboarding
ONBOARDING_ENDPOINT = "/api/v1/controllers"

# Server response keys
RESP_PROJECT_ID = "project_id"

# WS reconnection
WS_RECONNECT_DELAY_INITIAL = 5
WS_RECONNECT_DELAY_MAX = 60
WS_RECONNECT_BACKOFF_FACTOR = 2
