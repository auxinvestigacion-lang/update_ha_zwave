"""Resolves plugin groups from contract helpers and same-area automations."""

import logging

from homeassistant.components.automation import entities_in_automation
from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from ..const import LOG_PREFIX
from .plugin_family import is_plugin_role_automation, select_primary_plugin_automation
from .plugin_helper_contract import (
    PLUGIN_HELPER_FAMILY_MOTEL,
    PluginHelperGroupKey,
    parse_plugin_helper_identity,
)
from .plugin_naming_contract import is_motel_plugin_entity_id, is_valid_plugin_entity_id
from .standalone_filter import is_plugin_helper, is_standalone_entity

_LOGGER = logging.getLogger(__name__)

AUTOMATION_OFF_STATE = "off"


def build_plugin_group_assignments(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
) -> dict[str, list[er.RegistryEntry]]:
    """Maps each primary plugin automation to its instance group.

    Groups are keyed by area + helper family + room + instance
    (``hotel``/``hab_302`` vs ``hotel``/``hab_302_2``, ``motel``/``motel_89``).
    Scene automations and any automation whose entity_id is not a plugin
    contract id are omitted. Automations without an area, turned off, or that
    reference helpers from more than one instance are excluded.
    """
    standalone_entries = [
        entry for entry in entity_reg.entities.values() if is_standalone_entity(entry)
    ]
    contract_helpers = [
        entry
        for entry in standalone_entries
        if is_plugin_helper(entry) and parse_plugin_helper_identity(entry.entity_id)
    ]
    if not contract_helpers:
        return {}

    automations = [
        entry
        for entry in standalone_entries
        if _is_plugin_grouping_automation(hass, entry)
    ]
    groups = _collect_groups_from_referenced_helpers(hass, automations, contract_helpers)
    _attach_unreferenced_role_automations(automations, groups)

    return _build_assignments(hass, groups, contract_helpers, standalone_entries)


def _collect_groups_from_referenced_helpers(
    hass: HomeAssistant,
    automations: list[er.RegistryEntry],
    contract_helpers: list[er.RegistryEntry],
) -> dict[PluginHelperGroupKey, list[er.RegistryEntry]]:
    """Assigns automations that exclusively reference one helper instance group."""
    groups: dict[PluginHelperGroupKey, list[er.RegistryEntry]] = {}
    for automation in automations:
        group_key = _resolve_exclusive_group_key(hass, automation, contract_helpers)
        if group_key is None:
            continue
        groups.setdefault(group_key, []).append(automation)
    return groups


def _resolve_exclusive_group_key(
    hass: HomeAssistant,
    automation: er.RegistryEntry,
    contract_helpers: list[er.RegistryEntry],
) -> PluginHelperGroupKey | None:
    """Returns the helper group when every referenced contract helper matches it."""
    if automation.area_id is None:
        return None

    referenced_ids = _get_referenced_entity_ids(hass, automation)
    if not referenced_ids:
        return None

    instance_keys: set[tuple[str, str, int]] = set()
    for helper in contract_helpers:
        if helper.entity_id not in referenced_ids:
            continue
        if helper.area_id is not None and helper.area_id != automation.area_id:
            continue
        identity = parse_plugin_helper_identity(helper.entity_id)
        if identity is None:
            continue
        instance_keys.add((identity.family, identity.room_key, identity.instance))

    if len(instance_keys) != 1:
        return None

    family, room_key, instance = next(iter(instance_keys))
    return PluginHelperGroupKey(automation.area_id, family, room_key, instance)


def _attach_unreferenced_role_automations(
    automations: list[er.RegistryEntry],
    groups: dict[PluginHelperGroupKey, list[er.RegistryEntry]],
) -> None:
    """Folds motel main/ext/semaforo into the only motel helper group in their area."""
    groups_by_area = _index_motel_group_keys_by_area(groups)
    assigned_ids = {
        entry.entity_id for members in groups.values() for entry in members
    }

    for automation in automations:
        if automation.entity_id in assigned_ids:
            continue
        if automation.area_id is None:
            continue
        if not _is_motel_satellite_automation(automation.entity_id):
            continue
        area_keys = groups_by_area.get(automation.area_id, [])
        if len(area_keys) != 1:
            continue
        groups[area_keys[0]].append(automation)
        assigned_ids.add(automation.entity_id)


def _build_assignments(
    hass: HomeAssistant,
    groups: dict[PluginHelperGroupKey, list[er.RegistryEntry]],
    contract_helpers: list[er.RegistryEntry],
    standalone_entries: list[er.RegistryEntry],
) -> dict[str, list[er.RegistryEntry]]:
    """Builds primary → [automations + instance helpers + extra referenced helpers]."""
    assignments: dict[str, list[er.RegistryEntry]] = {}
    assigned_helper_ids: set[str] = set()

    for group_key in sorted(groups):
        family_automations = sorted(groups[group_key], key=lambda entry: entry.entity_id)
        primary = select_primary_plugin_automation(family_automations)
        instance_helpers = _select_instance_helpers(
            group_key, contract_helpers, assigned_helper_ids
        )
        extra_helpers = _select_referenced_extra_helpers(
            hass, family_automations, standalone_entries, group_key, assigned_helper_ids
        )
        assigned_helper_ids.update(entry.entity_id for entry in instance_helpers)
        assigned_helper_ids.update(entry.entity_id for entry in extra_helpers)
        assignments[primary.entity_id] = [
            *family_automations,
            *instance_helpers,
            *extra_helpers,
        ]

    return assignments


def _select_instance_helpers(
    group_key: PluginHelperGroupKey,
    contract_helpers: list[er.RegistryEntry],
    assigned_helper_ids: set[str],
) -> list[er.RegistryEntry]:
    """Selects contract helpers that belong to this room instance and area."""
    matched: list[er.RegistryEntry] = []
    for entry in contract_helpers:
        if entry.entity_id in assigned_helper_ids:
            continue
        if _helper_belongs_to_group(entry, group_key):
            matched.append(entry)
    return matched


def _select_referenced_extra_helpers(
    hass: HomeAssistant,
    family_automations: list[er.RegistryEntry],
    standalone_entries: list[er.RegistryEntry],
    group_key: PluginHelperGroupKey,
    assigned_helper_ids: set[str],
) -> list[er.RegistryEntry]:
    """Includes non-contract input_* helpers referenced by this instance only."""
    referenced_ids = _get_family_referenced_entity_ids(hass, family_automations)
    extras: list[er.RegistryEntry] = []

    for entry in standalone_entries:
        if not is_plugin_helper(entry) or entry.entity_id in assigned_helper_ids:
            continue
        if entry.entity_id not in referenced_ids:
            continue
        if parse_plugin_helper_identity(entry.entity_id) is not None:
            continue
        if entry.area_id is not None and entry.area_id != group_key.area_id:
            continue
        extras.append(entry)

    return extras


def _helper_belongs_to_group(
    entry: er.RegistryEntry,
    group_key: PluginHelperGroupKey,
) -> bool:
    """Returns True when a helper matches the group family, room, instance and area."""
    identity = parse_plugin_helper_identity(entry.entity_id)
    if identity is None:
        return False
    if identity.family != group_key.family:
        return False
    if identity.room_key != group_key.room_key:
        return False
    if identity.instance != group_key.instance:
        return False
    if entry.area_id is not None and entry.area_id != group_key.area_id:
        return False
    return True


def _index_motel_group_keys_by_area(
    groups: dict[PluginHelperGroupKey, list[er.RegistryEntry]],
) -> dict[str, list[PluginHelperGroupKey]]:
    """Indexes motel helper groups by Home Assistant area id."""
    groups_by_area: dict[str, list[PluginHelperGroupKey]] = {}
    for group_key in groups:
        if group_key.family != PLUGIN_HELPER_FAMILY_MOTEL:
            continue
        groups_by_area.setdefault(group_key.area_id, []).append(group_key)
    return groups_by_area


def _get_family_referenced_entity_ids(
    hass: HomeAssistant,
    family_automations: list[er.RegistryEntry],
) -> set[str]:
    """Unions referenced entity ids from every automation in the group."""
    referenced_ids: set[str] = set()
    for automation in family_automations:
        referenced_ids.update(_get_referenced_entity_ids(hass, automation))
    return referenced_ids


def get_automation_referenced_entity_ids(
    hass: HomeAssistant, automation: er.RegistryEntry
) -> set[str]:
    """Returns entity ids referenced by an automation, skipping malformed configs."""
    return _get_referenced_entity_ids(hass, automation)


def _is_motel_satellite_automation(entity_id: str) -> bool:
    """Returns True for motel role automations that may fold into an area group."""
    return is_plugin_role_automation(entity_id) and is_motel_plugin_entity_id(entity_id)


def _get_referenced_entity_ids(hass: HomeAssistant, automation: er.RegistryEntry) -> set[str]:
    """Returns entity ids referenced by an automation, skipping malformed configs."""
    try:
        referenced_ids = entities_in_automation(hass, automation.entity_id)
    except TypeError as err:
        _LOGGER.warning(
            "%s skipping referenced entities for %s: %s",
            LOG_PREFIX,
            automation.entity_id,
            err,
        )
        return set()

    return {entity_id for entity_id in referenced_ids if isinstance(entity_id, str)}


def _is_plugin_grouping_automation(
    hass: HomeAssistant, entry: er.RegistryEntry
) -> bool:
    """Returns True for enabled plugin-contract automations that may form a group."""
    if entry.domain != "automation":
        return False
    if not _is_enabled_automation(hass, entry):
        return False
    return is_valid_plugin_entity_id(entry.entity_id)


def _is_enabled_automation(hass: HomeAssistant, entry: er.RegistryEntry) -> bool:
    """Returns False when the automation toggle is off so it is not sent."""
    state = hass.states.get(entry.entity_id)
    if state is None:
        return True
    return state.state != AUTOMATION_OFF_STATE
