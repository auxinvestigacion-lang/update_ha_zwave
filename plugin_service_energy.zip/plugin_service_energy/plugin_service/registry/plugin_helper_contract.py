"""Parses occupancy/motel helper entity_ids into family + room + instance groups."""

from __future__ import annotations

import re
from typing import NamedTuple

from .plugin_family import get_plugin_object_id

# English and Spanish prefixes that identify a plugin contract helper.
PLUGIN_HELPER_TYPE_PREFIXES = tuple(
    sorted(
        (
            "accion_",
            "action_",
            "estado_",
            "mode_",
            "modo_",
            "state_",
        ),
        key=len,
        reverse=True,
    )
)

PLUGIN_HELPER_FAMILY_HOTEL = "hotel"
PLUGIN_HELPER_FAMILY_AULA = "aula"
PLUGIN_HELPER_FAMILY_MOTEL = "motel"
PLUGIN_HELPER_FAMILY_OCUPACION = "ocupacion"
PLUGIN_HELPER_FAMILIES = frozenset(
    {
        PLUGIN_HELPER_FAMILY_AULA,
        PLUGIN_HELPER_FAMILY_HOTEL,
        PLUGIN_HELPER_FAMILY_MOTEL,
        PLUGIN_HELPER_FAMILY_OCUPACION,
    }
)

PLUGIN_HELPER_DEFAULT_INSTANCE = 1

_ROOM_TOKEN_PATTERN = re.compile(r"[a-z]+|\d+")


class PluginHelperIdentity(NamedTuple):
    """Family, room and instance extracted from a contract helper entity_id."""

    helper_type: str
    family: str
    room_key: str
    instance: int


class PluginHelperGroupKey(NamedTuple):
    """Stable identity for one plugin instance inside an area."""

    area_id: str
    family: str
    room_key: str
    instance: int


def parse_plugin_helper_identity(entity_id: str) -> PluginHelperIdentity | None:
    """Returns family/room/instance when the helper follows ``{type}_{family}_{site}``.

    ``state_hotel_hab_302`` and ``mode_hotel_hab302`` share instance 1.
    ``state_hotel_hab_302_2`` is a second hotel plugin in the same room.
    Motel uses a single state helper: ``state_motel_motel_89``.
    """
    object_id = get_plugin_object_id(entity_id).lower()
    prefix = _match_helper_type_prefix(object_id)
    if prefix is None:
        return None

    remainder = object_id[len(prefix) :]
    family, site_part = _split_family_and_site(remainder)
    if family is None or not site_part:
        return None

    room_key, instance = _split_room_and_instance(site_part)
    if not room_key:
        return None

    return PluginHelperIdentity(
        helper_type=prefix.rstrip("_"),
        family=family,
        room_key=room_key,
        instance=instance,
    )


def helper_site_token(identity: PluginHelperIdentity) -> str:
    """Returns the site token encoded in a helper, including instance suffix."""
    if identity.instance == PLUGIN_HELPER_DEFAULT_INSTANCE:
        return identity.room_key
    return f"{identity.room_key}_{identity.instance}"


def normalize_room_key(room_key: str) -> str:
    """Normalizes ``hab302`` and ``hab_302`` to the same room token."""
    tokens = _ROOM_TOKEN_PATTERN.findall(room_key.lower())
    if not tokens:
        return room_key.lower()
    return "_".join(tokens)


def _match_helper_type_prefix(object_id: str) -> str | None:
    """Returns the longest matching contract prefix, if any."""
    for prefix in PLUGIN_HELPER_TYPE_PREFIXES:
        if object_id.startswith(prefix):
            return prefix
    return None


def _split_family_and_site(remainder: str) -> tuple[str | None, str]:
    """Splits ``hotel_hab_302`` into family ``hotel`` and site ``hab_302``."""
    tokens = remainder.split("_")
    if not tokens:
        return None, ""
    family = tokens[0]
    if family not in PLUGIN_HELPER_FAMILIES:
        return None, ""
    return family, "_".join(tokens[1:])


def _split_room_and_instance(site_part: str) -> tuple[str, int]:
    """Splits ``hab_302_2`` into room ``hab_302`` and instance ``2``.

    The trailing ``_N`` is an instance flag only when the previous token
    already contains a number (``hab_302_2``). ``motel_89`` stays instance 1.
    """
    tokens = site_part.split("_")
    if (
        len(tokens) >= 2
        and tokens[-1].isdigit()
        and _token_contains_digit(tokens[-2])
    ):
        instance = int(tokens[-1])
        room_key = normalize_room_key("_".join(tokens[:-1]))
        return room_key, instance

    return normalize_room_key(site_part), PLUGIN_HELPER_DEFAULT_INSTANCE


def _token_contains_digit(token: str) -> bool:
    """Returns True when a slug token already encodes a room number."""
    return any(char.isdigit() for char in token)
