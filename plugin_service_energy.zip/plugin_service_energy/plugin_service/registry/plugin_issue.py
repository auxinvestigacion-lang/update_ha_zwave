"""Plugin contract violation codes shared by validation and installer messages."""

from __future__ import annotations

from typing import NamedTuple

REASON_INVALID_ENTITY_ID = "invalid_entity_id"
REASON_MISSING_AREA = "missing_area"
REASON_MISSING_CONTRACT_HELPERS = "missing_contract_helpers"
REASON_MULTIPLE_HELPER_INSTANCES = "multiple_helper_instances"
REASON_ROOM_MISMATCH = "room_mismatch"
REASON_MOTEL_AMBIGUOUS_AREA = "motel_ambiguous_area"

KIND_PLUGIN = "plugin"
KIND_PHYSICAL = "physical"
KIND_VIRTUAL = "virtual"


class PluginValidationIssue(NamedTuple):
    """One inventory contract violation that blocks registration."""

    entity_id: str
    reason: str
    expected_entity_id: str | None = None
    helper_room_key: str | None = None
    subject_kind: str = KIND_PLUGIN
    display_name: str | None = None
