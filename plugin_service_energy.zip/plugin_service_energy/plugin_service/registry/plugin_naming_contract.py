"""Validates plugin and scene automation entity_ids; entity_id is the source of truth."""

from __future__ import annotations

import unicodedata

from .plugin_family import PLUGIN_ROLES, get_plugin_object_id
from .plugin_helper_contract import (
    PLUGIN_HELPER_FAMILY_AULA,
    PLUGIN_HELPER_FAMILY_HOTEL,
    PLUGIN_HELPER_FAMILY_MOTEL,
    PLUGIN_HELPER_FAMILY_OCUPACION,
    PluginHelperIdentity,
    helper_site_token,
    normalize_room_key,
)

AUTOMATION_DOMAIN_PREFIX = "automation."

_OCCUPANCY_PREFIX_TO_FAMILY = (
    ("plugin_hotel_", PLUGIN_HELPER_FAMILY_HOTEL),
    ("plugin_ocupacion_", PLUGIN_HELPER_FAMILY_OCUPACION),
    ("plugin_aula_", PLUGIN_HELPER_FAMILY_AULA),
)
OCCUPANCY_ENTITY_ID_PREFIXES = tuple(
    prefix for prefix, _family in _OCCUPANCY_PREFIX_TO_FAMILY
)

LEGACY_HOTEL_ENTITY_ID_PREFIX = "bp_plugin_hotel"
MOTEL_ENTITY_ID_PREFIX = "plugin_motel"

# Scene automations are omitted from plugin grouping and validation.
SCENE_ENTITY_ID_PREFIXES = (
    "escena_",
    "scene_",
)
SCENE_OBJECT_IDS = frozenset({"escena", "scene"})
SCENE_FRIENDLY_NAME_PREFIXES = (
    "escena",
    "scene",
)

FRIENDLY_NAME_PREFIXES = (
    "plugin ocupacion",
    "plugin aula",
    "plugin motel",
)

_FRIENDLY_NAME_TO_ENTITY_PREFIX = (
    ("plugin ocupacion", "plugin_ocupacion_"),
    ("plugin aula", "plugin_aula_"),
    ("plugin motel", "plugin_motel_"),
)


def is_valid_plugin_entity_id(entity_id: str) -> bool:
    """Returns True when the automation entity_id follows the plugin contract."""
    object_id = _automation_object_id(entity_id)
    if object_id is None:
        return False
    return is_occupancy_plugin_object_id(object_id) or is_motel_plugin_object_id(object_id)


def is_occupancy_plugin_object_id(object_id: str) -> bool:
    """Returns True for hotel/aula/ocupación object_ids, including legacy hotel."""
    if object_id.startswith(LEGACY_HOTEL_ENTITY_ID_PREFIX):
        return True
    return _occupancy_site_from_object_id(object_id) is not None


def is_motel_plugin_object_id(object_id: str) -> bool:
    """Returns True when the object_id is a motel plugin automation."""
    return object_id.startswith(MOTEL_ENTITY_ID_PREFIX)


def is_motel_plugin_entity_id(entity_id: str) -> bool:
    """Returns True when the entity_id is a motel plugin automation."""
    object_id = _automation_object_id(entity_id)
    if object_id is None:
        return False
    return is_motel_plugin_object_id(object_id)


def is_legacy_hotel_plugin_entity_id(entity_id: str) -> bool:
    """Returns True for historical bp_plugin_hotel_* occupancy automations."""
    object_id = _automation_object_id(entity_id)
    if object_id is None:
        return False
    return object_id.startswith(LEGACY_HOTEL_ENTITY_ID_PREFIX)


def extract_occupancy_site(entity_id: str) -> str | None:
    """Returns the normalized site from a non-legacy occupancy entity_id."""
    object_id = _automation_object_id(entity_id)
    if object_id is None:
        return None
    return _occupancy_site_from_object_id(object_id)


def extract_motel_site(entity_id: str) -> str | None:
    """Returns the site after plugin_motel and role tokens, if present."""
    object_id = _automation_object_id(entity_id)
    if object_id is None or not object_id.startswith(MOTEL_ENTITY_ID_PREFIX):
        return None
    remainder = object_id[len(MOTEL_ENTITY_ID_PREFIX) :].lstrip("_")
    tokens = [token for token in remainder.split("_") if token not in PLUGIN_ROLES]
    if not tokens:
        return None
    return normalize_room_key("_".join(tokens))


def extract_plugin_helper_family(entity_id: str) -> str | None:
    """Returns the helper family token encoded in a plugin automation entity_id."""
    if is_motel_plugin_entity_id(entity_id):
        return PLUGIN_HELPER_FAMILY_MOTEL
    if is_legacy_hotel_plugin_entity_id(entity_id):
        return PLUGIN_HELPER_FAMILY_HOTEL
    object_id = _automation_object_id(entity_id)
    if object_id is None:
        return None
    for prefix, family in _OCCUPANCY_PREFIX_TO_FAMILY:
        if object_id.startswith(prefix):
            return family
    return None


def extract_plugin_site(entity_id: str) -> str | None:
    """Returns occupancy or motel site from a plugin automation entity_id."""
    if is_legacy_hotel_plugin_entity_id(entity_id):
        return None
    if is_motel_plugin_entity_id(entity_id):
        return extract_motel_site(entity_id)
    return extract_occupancy_site(entity_id)


def occupancy_site_matches_helper_room(entity_id: str, room_key: str) -> bool:
    """Returns True when helper room matches the site encoded in entity_id.

    Legacy hotel automations and motel automations without a site skip this check.
    """
    if is_legacy_hotel_plugin_entity_id(entity_id):
        return True
    site = extract_plugin_site(entity_id)
    if site is None:
        return is_motel_plugin_entity_id(entity_id)
    return site == normalize_room_key(room_key)


def plugin_automation_matches_helper(
    entity_id: str, identity: PluginHelperIdentity
) -> bool:
    """Returns True when automation family and site match a contract helper."""
    if is_legacy_hotel_plugin_entity_id(entity_id):
        return True
    family = extract_plugin_helper_family(entity_id)
    if family is None or family != identity.family:
        return False
    site = extract_plugin_site(entity_id)
    if site is None:
        return True
    return site == helper_site_token(identity)


def is_scene_automation_entity_id(entity_id: str) -> bool:
    """Returns True when the automation entity_id follows the scene contract."""
    object_id = _automation_object_id(entity_id)
    if object_id is None:
        return False
    if object_id in SCENE_OBJECT_IDS:
        return True
    return object_id.startswith(SCENE_ENTITY_ID_PREFIXES)


def looks_like_scene_friendly_name(name: str) -> bool:
    """Returns True when the display name uses Escena|Scene."""
    normalized = normalize_plugin_text(name)
    for prefix in SCENE_FRIENDLY_NAME_PREFIXES:
        if normalized == prefix or normalized.startswith(f"{prefix} "):
            return True
    return False


def is_scene_automation_candidate(entity_id: str, display_name: str = "") -> bool:
    """Returns True when entity_id or friendly name identifies a scene to omit."""
    if is_valid_plugin_entity_id(entity_id):
        return False
    if is_scene_automation_entity_id(entity_id):
        return True
    return looks_like_scene_friendly_name(display_name)


def is_plugin_automation_candidate(entity_id: str, display_name: str = "") -> bool:
    """Returns True when entity_id or friendly name indicates an intended plugin."""
    if is_scene_automation_candidate(entity_id, display_name):
        return False
    if is_valid_plugin_entity_id(entity_id):
        return True
    return looks_like_plugin_friendly_name(display_name)


def looks_like_plugin_friendly_name(name: str) -> bool:
    """Returns True when the display name uses Plugin Ocupacion|Aula|Motel."""
    normalized = normalize_plugin_text(name)
    for prefix in FRIENDLY_NAME_PREFIXES:
        if normalized == prefix or normalized.startswith(f"{prefix} "):
            return True
    return False


def suggest_plugin_entity_id_from_name(name: str) -> str | None:
    """Suggests a contract entity_id from a well-formed friendly name."""
    normalized = normalize_plugin_text(name)
    for name_prefix, entity_prefix in _FRIENDLY_NAME_TO_ENTITY_PREFIX:
        remainder = _remainder_after_prefix(normalized, name_prefix)
        if remainder is None:
            continue
        if not remainder:
            return f"{AUTOMATION_DOMAIN_PREFIX}{entity_prefix.rstrip('_')}"
        site = normalize_room_key(remainder.replace(" ", "_"))
        return f"{AUTOMATION_DOMAIN_PREFIX}{entity_prefix}{site}"
    return None


def normalize_plugin_text(value: str) -> str:
    """Lowercases, strips accents, and collapses whitespace for comparisons."""
    decomposed = unicodedata.normalize("NFD", value)
    without_accents = "".join(
        char for char in decomposed if unicodedata.category(char) != "Mn"
    )
    return " ".join(without_accents.lower().split())


def plugin_group_has_valid_entity_ids(entity_ids: list[str]) -> bool:
    """Returns True when every automation in the group follows the entity_id contract."""
    automation_ids = [
        entity_id
        for entity_id in entity_ids
        if entity_id.startswith(AUTOMATION_DOMAIN_PREFIX)
    ]
    if not automation_ids:
        return False
    return all(is_valid_plugin_entity_id(entity_id) for entity_id in automation_ids)


def _occupancy_site_from_object_id(object_id: str) -> str | None:
    """Returns the site token after a known occupancy prefix, if present."""
    for prefix in OCCUPANCY_ENTITY_ID_PREFIXES:
        if not object_id.startswith(prefix):
            continue
        site = object_id[len(prefix) :]
        if not site:
            return None
        return normalize_room_key(site)
    return None


def _automation_object_id(entity_id: str) -> str | None:
    """Returns the lowercased object_id for automation entity_ids only."""
    if not entity_id.startswith(AUTOMATION_DOMAIN_PREFIX):
        return None
    return get_plugin_object_id(entity_id).lower()


def _remainder_after_prefix(normalized_name: str, prefix: str) -> str | None:
    """Returns the text after a friendly-name prefix, or None if it does not match."""
    if normalized_name == prefix:
        return ""
    with_space = f"{prefix} "
    if normalized_name.startswith(with_space):
        return normalized_name[len(with_space) :]
    return None
