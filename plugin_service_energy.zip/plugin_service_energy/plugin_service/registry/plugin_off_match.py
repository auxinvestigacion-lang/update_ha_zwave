"""Detects plugin automations whose toggle is off so they are not registered."""

from __future__ import annotations

from .plugin_naming_contract import is_plugin_automation_candidate

AUTOMATION_DOMAIN = "automation"
AUTOMATION_OFF_STATE = "off"


def is_off_plugin_automation(
    entity_id: str,
    domain: str,
    state: str | None,
    display_name: str,
) -> bool:
    """Returns True when a standalone automation looks like a plugin and is off."""
    if domain != AUTOMATION_DOMAIN:
        return False
    if state != AUTOMATION_OFF_STATE:
        return False
    return is_plugin_automation_candidate(entity_id, display_name)
