"""Collects Z-Wave hardware and virtual devices that are missing an assigned area."""

from __future__ import annotations

from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

from .device_filter import is_registrable_hardware_device
from .plugin_issue import (
    KIND_PHYSICAL,
    KIND_VIRTUAL,
    REASON_MISSING_AREA,
    PluginValidationIssue,
)
from .standalone_filter import resolve_virtual_device_name
from .virtual_collector import is_virtual_device_missing_area


def collect_missing_area_issues(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry | None = None,
) -> list[PluginValidationIssue]:
    """Returns Z-Wave hardware and virtual devices that would register if they had an area."""
    if entity_reg is None:
        entity_reg = er.async_get(hass)
    device_reg = dr.async_get(hass)
    issues: list[PluginValidationIssue] = []
    issues.extend(_collect_physical_missing_area_issues(device_reg, entity_reg))
    issues.extend(_collect_virtual_missing_area_issues(device_reg, entity_reg))
    return issues


def _collect_physical_missing_area_issues(
    device_reg: dr.DeviceRegistry,
    entity_reg: er.EntityRegistry,
) -> list[PluginValidationIssue]:
    """Flags Z-Wave room hardware that is otherwise registrable but has no area."""
    issues: list[PluginValidationIssue] = []
    for device in device_reg.devices.values():
        entity_entries = er.async_entries_for_device(entity_reg, device.id)
        if not is_registrable_hardware_device(device, entity_entries):
            continue
        if device.area_id is not None:
            continue
        issues.append(
            PluginValidationIssue(
                entity_id=device.id,
                reason=REASON_MISSING_AREA,
                subject_kind=KIND_PHYSICAL,
                display_name=device.name_by_user or device.name or device.id,
            )
        )
    return issues


def _collect_virtual_missing_area_issues(
    device_reg: dr.DeviceRegistry,
    entity_reg: er.EntityRegistry,
) -> list[PluginValidationIssue]:
    """Flags standalone template helpers that have no area on the entity or device."""
    issues: list[PluginValidationIssue] = []
    for entry in entity_reg.entities.values():
        if not is_virtual_device_missing_area(entry, device_reg, entity_reg):
            continue
        issues.append(
            PluginValidationIssue(
                entity_id=entry.entity_id,
                reason=REASON_MISSING_AREA,
                subject_kind=KIND_VIRTUAL,
                display_name=resolve_virtual_device_name(entry),
            )
        )
    return issues
