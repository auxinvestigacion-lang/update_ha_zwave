"""Collects plugin automations that are toggled off and skipped at register."""

from __future__ import annotations

from typing import NamedTuple

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from .plugin_off_match import is_off_plugin_automation
from .standalone_filter import is_standalone_entity


class PluginOffWarning(NamedTuple):
    """A plugin automation that was not sent because its toggle is off."""

    entity_id: str
    display_name: str | None = None


def collect_plugin_off_warnings(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry | None = None,
) -> list[PluginOffWarning]:
    """Returns plugin-candidate automations that are off and will not be sent."""
    if entity_reg is None:
        entity_reg = er.async_get(hass)

    warnings: list[PluginOffWarning] = []
    for entry in entity_reg.entities.values():
        warning = _warning_for_entry(hass, entry)
        if warning is not None:
            warnings.append(warning)
    return sorted(warnings, key=lambda item: item.entity_id)


def _warning_for_entry(
    hass: HomeAssistant, entry: er.RegistryEntry
) -> PluginOffWarning | None:
    """Returns a warning when the registry entry is an off plugin automation."""
    if entry.disabled_by is not None or not is_standalone_entity(entry):
        return None
    state = hass.states.get(entry.entity_id)
    display_name = _automation_display_name(hass, entry)
    if not is_off_plugin_automation(
        entry.entity_id,
        entry.domain,
        state.state if state is not None else None,
        display_name,
    ):
        return None
    return PluginOffWarning(entry.entity_id, display_name or None)


def _automation_display_name(hass: HomeAssistant, entry: er.RegistryEntry) -> str:
    """Returns the installer-visible automation name used for plugin detection."""
    state = hass.states.get(entry.entity_id)
    if state is not None and state.name:
        return str(state.name)
    return entry.name or entry.original_name or ""
