"""Rules to identify actionable devices and derive their categories."""

from enum import Enum

from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er
from homeassistant.helpers.entity import EntityCategory

from ..const import DOMAIN, ZWAVE_JS_DOMAIN
from .device_hub_names import is_wifi_module_device_name
from .standalone_filter import VIRTUAL_DEVICE_PLATFORM

# Platforms that represent system/infrastructure devices, not user hardware.
EXCLUDED_DEVICE_PLATFORMS = frozenset(
    {"sun", "backup", "homeassistant", "hassio", "mobile_app", DOMAIN}
)

# User-facing domains that can still be a network adapter, not a room device.
CONNECTIVITY_ONLY_DOMAINS = frozenset({"binary_sensor", "sensor", "update"})
CONNECTIVITY_DEVICE_CLASSES = frozenset({"connectivity", "signal_strength"})
CONNECTIVITY_ENTITY_TOKENS = ("ip_address", "rssi", "ssid", "wifi", "wlan")

# Domains that alone do not justify registering a physical device.
NON_REGISTRABLE_DOMAINS = frozenset({"notify", "device_tracker", "scene"})

# Domains that remain trackable when marked config (Z-Wave curtain relays, etc.).
CONFIG_TRACKABLE_CONTROL_DOMAINS = frozenset({"button", "cover", "switch"})

# Sensor device classes that emit live measurement events (including diagnostic).
MEASUREMENT_SENSOR_DEVICE_CLASSES = frozenset(
    {
        "current",
        "energy",
        "power",
        "power_factor",
        "temperature",
        "voltage",
    }
)

# Binary sensor device classes for heat/safety alerts on metering switches.
MEASUREMENT_BINARY_SENSOR_DEVICE_CLASSES = frozenset(
    {
        "cold",
        "heat",
        "problem",
        "safety",
    }
)

# Entity ID suffixes that must never emit WebSocket events.
TRACKABLE_ENTITY_ID_EXCLUDED_SUFFIXES = (
    "_identify",
    "_firmware",
    "_estado_del_nodo",
)

# Domains used to infer the primary category of an actionable device.
PRIMARY_DOMAIN_PRIORITY = (
    "climate",
    "lock",
    "cover",
    "light",
    "switch",
    "fan",
    "media_player",
    "vacuum",
    "humidifier",
    "water_heater",
    "binary_sensor",
    "sensor",
)


def is_integration_device(device: dr.DeviceEntry) -> bool:
    """Returns True when the device belongs to this integration."""
    return any(identifier[0] == DOMAIN for identifier in device.identifiers)


def is_actionable_device(
    device: dr.DeviceEntry,
    entity_entries: list[er.RegistryEntry],
) -> bool:
    """Returns True when the device is registrable hardware assigned to an area."""
    if not is_registrable_hardware_device(device, entity_entries):
        return False
    return device.area_id is not None


def is_registrable_hardware_device(
    device: dr.DeviceEntry,
    entity_entries: list[er.RegistryEntry],
) -> bool:
    """Returns True for Z-Wave room hardware, ignoring whether an area is assigned."""
    if device.disabled_by is not None:
        return False

    if is_integration_device(device):
        return False

    if device.entry_type is not None and device.entry_type.value == "service":
        return False

    enabled_entries = [
        entry for entry in entity_entries if entry.disabled_by is None
    ]
    if not enabled_entries:
        return False

    if not _has_zwave_hardware_entities(enabled_entries):
        return False

    if all(entry.platform in EXCLUDED_DEVICE_PLATFORMS for entry in enabled_entries):
        return False

    user_facing_entries = [
        entry for entry in enabled_entries if _is_user_facing_entity(entry)
    ]
    if not user_facing_entries:
        return False

    if not _has_registrable_domain(user_facing_entries):
        return False

    if _is_zwave_controller(user_facing_entries):
        return False

    if _is_integration_hub_device(device, user_facing_entries):
        return False

    return True


def is_non_template_ha_device(
    device: dr.DeviceEntry,
    entity_entries: list[er.RegistryEntry],
) -> bool:
    """Returns True when the HA device is not a template-only helper container."""
    if device.disabled_by is not None:
        return False

    enabled_entries = [
        entry for entry in entity_entries if entry.disabled_by is None
    ]
    if not enabled_entries:
        return False

    return not _is_template_only_device(enabled_entries)


def is_trackable_entity(entry: er.RegistryEntry) -> bool:
    """Returns True when an entity should emit WebSocket state_changed events."""
    return _is_user_facing_entity(entry)


def is_trackable_entity_on_device(
    hass: HomeAssistant,
    entry: er.RegistryEntry,
    device_entity_entries: list[er.RegistryEntry],
) -> bool:
    """Returns True when an entity on a physical device should emit events.

    Primary/control entities are always tracked. Diagnostic measurement
    sensors (electric meters, temperature, heat alerts) are also tracked so
    switches with metering (e.g. Heavy Duty) forward live values to the server.
    """
    _ = device_entity_entries

    if _is_user_facing_entity(entry):
        return True

    if entry.entity_category != EntityCategory.DIAGNOSTIC:
        return False

    return _is_measurement_entity(hass, entry)


def get_primary_domain(entity_entries: list[er.RegistryEntry]) -> str | None:
    """Derives the main domain/category for a device from its primary entities."""
    primary_domains = {
        entry.domain
        for entry in entity_entries
        if _is_user_facing_entity(entry)
    }

    for domain in PRIMARY_DOMAIN_PRIORITY:
        if domain in primary_domains:
            return domain

    return next(iter(primary_domains), None)


def serialize_entity_category(category: EntityCategory | None) -> str | None:
    """Serializes an EntityCategory enum value for the external server."""
    return category.value if category is not None else None


def resolve_entity_device_class(
    entry: er.RegistryEntry,
    attributes: dict,
) -> str | None:
    """Resolves device_class from live state, then entity registry fallbacks.

    Live attributes can be empty while a Z-Wave node is dead or still
    bootstrapping; the registry keeps the stable class (e.g. motion).
    """
    raw_device_class = attributes.get("device_class")
    if raw_device_class is None:
        raw_device_class = entry.device_class or entry.original_device_class

    if raw_device_class is None:
        return None

    if isinstance(raw_device_class, Enum):
        return raw_device_class.value

    return str(raw_device_class)


def _is_integration_hub_device(
    device: dr.DeviceEntry,
    user_facing_entries: list[er.RegistryEntry],
) -> bool:
    """Returns True for integration/network hubs that are not room hardware."""
    if any(
        is_wifi_module_device_name(value)
        for value in (device.name_by_user, device.name, device.model)
    ):
        return True
    return _is_connectivity_only_device(user_facing_entries)


def _is_connectivity_only_device(entity_entries: list[er.RegistryEntry]) -> bool:
    """Returns True when every user-facing entity is a WiFi/network status sensor."""
    if not entity_entries:
        return False
    return all(_is_connectivity_entity(entry) for entry in entity_entries)


def _is_connectivity_entity(entry: er.RegistryEntry) -> bool:
    """Returns True for sensors that only expose network/WiFi status."""
    if entry.domain not in CONNECTIVITY_ONLY_DOMAINS:
        return False
    device_class = entry.device_class or entry.original_device_class
    if device_class in CONNECTIVITY_DEVICE_CLASSES:
        return True
    blob = f"{entry.entity_id} {entry.original_name or ''} {entry.name or ''}".lower()
    return any(token in blob for token in CONNECTIVITY_ENTITY_TOKENS)


def _has_zwave_hardware_entities(entity_entries: list[er.RegistryEntry]) -> bool:
    """Returns True when at least one entity belongs to the Z-Wave integration."""
    return any(entry.platform == ZWAVE_JS_DOMAIN for entry in entity_entries)


def _is_template_only_device(entity_entries: list[er.RegistryEntry]) -> bool:
    """Returns True when the device only exposes template helpers, not hardware."""
    return bool(entity_entries) and all(
        entry.platform == VIRTUAL_DEVICE_PLATFORM for entry in entity_entries
    )


def _has_registrable_domain(entity_entries: list[er.RegistryEntry]) -> bool:
    """Returns True when at least one user-facing entity is not notify/tracker/scene."""
    return any(entry.domain not in NON_REGISTRABLE_DOMAINS for entry in entity_entries)


def _is_zwave_controller(entity_entries: list[er.RegistryEntry]) -> bool:
    """Detects Z-Wave USB controllers that only expose status/firmware entities."""
    zwave_entries = [
        entry
        for entry in entity_entries
        if entry.platform == ZWAVE_JS_DOMAIN and entry.entity_category is None
    ]
    if not zwave_entries:
        return False

    domains = {entry.domain for entry in zwave_entries}
    if domains - {"sensor", "update", "button"}:
        return False

    return any("controller" in entry.entity_id for entry in zwave_entries)


def _is_excluded_trackable_entity_id(entity_id: str) -> bool:
    """Excludes diagnostic and maintenance entities from WebSocket tracking."""
    return entity_id.endswith(TRACKABLE_ENTITY_ID_EXCLUDED_SUFFIXES)


def _is_user_facing_entity(entry: er.RegistryEntry) -> bool:
    """Returns True for primary or control entities that should be tracked."""
    if entry.disabled_by is not None:
        return False

    if entry.platform in EXCLUDED_DEVICE_PLATFORMS:
        return False

    if _is_excluded_trackable_entity_id(entry.entity_id):
        return False

    if entry.entity_category is None:
        return True

    if (
        entry.entity_category == EntityCategory.CONFIG
        and entry.domain in CONFIG_TRACKABLE_CONTROL_DOMAINS
    ):
        return True

    return False


def _is_measurement_entity(hass: HomeAssistant, entry: er.RegistryEntry) -> bool:
    """Returns True for sensors/binary_sensors that expose live measurement values."""
    if entry.disabled_by is not None:
        return False

    if entry.platform in EXCLUDED_DEVICE_PLATFORMS:
        return False

    if _is_excluded_trackable_entity_id(entry.entity_id):
        return False

    if entry.domain == "sensor":
        allowed_device_classes = MEASUREMENT_SENSOR_DEVICE_CLASSES
    elif entry.domain == "binary_sensor":
        allowed_device_classes = MEASUREMENT_BINARY_SENSOR_DEVICE_CLASSES
    else:
        return False

    state = hass.states.get(entry.entity_id)
    attributes = dict(state.attributes) if state else {}
    device_class = resolve_entity_device_class(entry, attributes)
    return device_class in allowed_device_classes
