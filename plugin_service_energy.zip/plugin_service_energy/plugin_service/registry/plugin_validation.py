"""Collects installer-facing plugin contract violations before registration."""

from __future__ import annotations

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from .missing_area_validation import collect_missing_area_issues
from .plugin_family import is_plugin_role_automation
from .plugin_group_resolver import (
    AUTOMATION_OFF_STATE,
    build_plugin_group_assignments,
    get_automation_referenced_entity_ids,
)
from .plugin_helper_contract import (
    PLUGIN_HELPER_FAMILY_MOTEL,
    PluginHelperIdentity,
    helper_site_token,
    parse_plugin_helper_identity,
)
from .plugin_issue import (
    REASON_INVALID_ENTITY_ID,
    REASON_MISSING_AREA,
    REASON_MISSING_CONTRACT_HELPERS,
    REASON_MOTEL_AMBIGUOUS_AREA,
    REASON_MULTIPLE_HELPER_INSTANCES,
    REASON_ROOM_MISMATCH,
    PluginValidationIssue,
)
from .plugin_naming_contract import (
    is_motel_plugin_entity_id,
    is_plugin_automation_candidate,
    is_valid_plugin_entity_id,
    plugin_automation_matches_helper,
    suggest_plugin_entity_id_from_name,
)
from .standalone_filter import is_plugin_helper, is_standalone_entity

AUTOMATION_DOMAIN = "automation"


def collect_registration_validation_issues(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry | None = None,
) -> list[PluginValidationIssue]:
    """Returns plugin contract issues plus Z-Wave/virtual devices missing an area."""
    if entity_reg is None:
        entity_reg = er.async_get(hass)

    issues_by_id = {
        issue.entity_id: issue
        for issue in collect_plugin_validation_issues(hass, entity_reg)
    }
    for issue in collect_missing_area_issues(hass, entity_reg):
        issues_by_id.setdefault(issue.entity_id, issue)
    return [issues_by_id[subject_id] for subject_id in sorted(issues_by_id)]


def collect_plugin_validation_issues(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry | None = None,
) -> list[PluginValidationIssue]:
    """Returns plugin contract issues that must be fixed before register."""
    if entity_reg is None:
        entity_reg = er.async_get(hass)

    standalone_entries = [
        entry for entry in entity_reg.entities.values() if is_standalone_entity(entry)
    ]
    automations = [
        entry
        for entry in standalone_entries
        if entry.domain == AUTOMATION_DOMAIN and _is_enabled_automation(hass, entry)
    ]
    assignments = build_plugin_group_assignments(hass, entity_reg)
    issues: dict[str, PluginValidationIssue] = {}
    _collect_grouped_automation_issues(hass, assignments, issues)
    _collect_ungrouped_automation_issues(
        hass, automations, assignments, standalone_entries, issues
    )
    return [issues[entity_id] for entity_id in sorted(issues)]


def _collect_grouped_automation_issues(
    hass: HomeAssistant,
    assignments: dict[str, list[er.RegistryEntry]],
    issues: dict[str, PluginValidationIssue],
) -> None:
    """Records entity_id and room mismatches for automations already grouped."""
    for members in assignments.values():
        helper_identity = _helper_identity_from_members(members)
        for automation in _automation_members(members):
            issue = _issue_for_grouped_automation(hass, automation, helper_identity)
            if issue is not None:
                issues[issue.entity_id] = issue


def _issue_for_grouped_automation(
    hass: HomeAssistant,
    automation: er.RegistryEntry,
    helper_identity: PluginHelperIdentity | None,
) -> PluginValidationIssue | None:
    """Returns the highest-priority issue for a grouped plugin automation."""
    if not is_valid_plugin_entity_id(automation.entity_id):
        return _build_invalid_entity_id_issue(hass, automation)
    if helper_identity is None:
        return None
    if plugin_automation_matches_helper(automation.entity_id, helper_identity):
        return None
    return PluginValidationIssue(
        entity_id=automation.entity_id,
        reason=REASON_ROOM_MISMATCH,
        helper_room_key=helper_site_token(helper_identity),
    )


def _collect_ungrouped_automation_issues(
    hass: HomeAssistant,
    automations: list[er.RegistryEntry],
    assignments: dict[str, list[er.RegistryEntry]],
    standalone_entries: list[er.RegistryEntry],
    issues: dict[str, PluginValidationIssue],
) -> None:
    """Records issues for plugin-like automations that did not form a group."""
    assigned_ids = {
        entry.entity_id
        for members in assignments.values()
        for entry in _automation_members(members)
    }
    contract_helpers = [
        entry
        for entry in standalone_entries
        if is_plugin_helper(entry) and parse_plugin_helper_identity(entry.entity_id)
    ]
    for automation in automations:
        if automation.entity_id in assigned_ids or automation.entity_id in issues:
            continue
        if not _is_plugin_candidate(hass, automation):
            continue
        issue = _issue_for_ungrouped_automation(
            hass, automation, contract_helpers, assignments
        )
        if issue is not None:
            issues[issue.entity_id] = issue


def _issue_for_ungrouped_automation(
    hass: HomeAssistant,
    automation: er.RegistryEntry,
    contract_helpers: list[er.RegistryEntry],
    assignments: dict[str, list[er.RegistryEntry]],
) -> PluginValidationIssue:
    """Explains why a plugin candidate was not grouped, prioritizing entity_id."""
    if not is_valid_plugin_entity_id(automation.entity_id):
        return _build_invalid_entity_id_issue(hass, automation)
    if automation.area_id is None:
        return PluginValidationIssue(automation.entity_id, REASON_MISSING_AREA)
    motel_issue = _motel_satellite_area_issue(automation, assignments)
    if motel_issue is not None:
        return motel_issue
    return _helper_reference_issue(hass, automation, contract_helpers)


def _helper_reference_issue(
    hass: HomeAssistant,
    automation: er.RegistryEntry,
    contract_helpers: list[er.RegistryEntry],
) -> PluginValidationIssue:
    """Returns the helper-contract issue when an occupancy plugin cannot group."""
    instance_keys = _referenced_helper_instance_keys(
        hass, automation, contract_helpers
    )
    if len(instance_keys) > 1:
        return PluginValidationIssue(
            automation.entity_id, REASON_MULTIPLE_HELPER_INSTANCES
        )
    return PluginValidationIssue(automation.entity_id, REASON_MISSING_CONTRACT_HELPERS)


def _motel_satellite_area_issue(
    automation: er.RegistryEntry,
    assignments: dict[str, list[er.RegistryEntry]],
) -> PluginValidationIssue | None:
    """Returns an issue when a motel satellite cannot fold into a unique area group."""
    if not is_motel_plugin_entity_id(automation.entity_id):
        return None
    if not is_plugin_role_automation(automation.entity_id):
        return None
    area_group_count = _assignment_count_for_motel_area(
        assignments, automation.area_id
    )
    if area_group_count == 1:
        return None
    if area_group_count > 1:
        return PluginValidationIssue(automation.entity_id, REASON_MOTEL_AMBIGUOUS_AREA)
    return PluginValidationIssue(automation.entity_id, REASON_MISSING_CONTRACT_HELPERS)


def _is_plugin_candidate(hass: HomeAssistant, automation: er.RegistryEntry) -> bool:
    """Returns True when name or entity_id indicates an intended plugin.

    Scene automations are never candidates, even if they reference helpers.
    """
    return is_plugin_automation_candidate(
        automation.entity_id,
        _automation_display_name(hass, automation),
    )


def _build_invalid_entity_id_issue(
    hass: HomeAssistant, automation: er.RegistryEntry
) -> PluginValidationIssue:
    """Builds the entity_id contract issue, with a name-based suggestion when possible."""
    return PluginValidationIssue(
        entity_id=automation.entity_id,
        reason=REASON_INVALID_ENTITY_ID,
        expected_entity_id=suggest_plugin_entity_id_from_name(
            _automation_display_name(hass, automation)
        ),
    )


def _referenced_helper_instance_keys(
    hass: HomeAssistant,
    automation: er.RegistryEntry,
    contract_helpers: list[er.RegistryEntry],
) -> set[tuple[str, str, int]]:
    """Returns helper family/room/instance keys referenced in the same area."""
    referenced_ids = get_automation_referenced_entity_ids(hass, automation)
    instance_keys: set[tuple[str, str, int]] = set()
    for helper in contract_helpers:
        if helper.entity_id not in referenced_ids:
            continue
        if helper.area_id is not None and helper.area_id != automation.area_id:
            continue
        identity = parse_plugin_helper_identity(helper.entity_id)
        if identity is None:
            continue
        instance_keys.add((identity.family, identity.room_key, identity.instance))
    return instance_keys


def _helper_identity_from_members(
    members: list[er.RegistryEntry],
) -> PluginHelperIdentity | None:
    """Returns the first contract helper identity in a plugin group, if any."""
    for entry in members:
        identity = parse_plugin_helper_identity(entry.entity_id)
        if identity is not None:
            return identity
    return None


def _automation_members(members: list[er.RegistryEntry]) -> list[er.RegistryEntry]:
    """Returns automation entries from a plugin group."""
    return [entry for entry in members if entry.domain == AUTOMATION_DOMAIN]


def _assignment_count_for_motel_area(
    assignments: dict[str, list[er.RegistryEntry]], area_id: str | None
) -> int:
    """Counts grouped motel plugins that live in the given area."""
    if area_id is None:
        return 0
    count = 0
    for members in assignments.values():
        if not any(entry.area_id == area_id for entry in _automation_members(members)):
            continue
        identity = _helper_identity_from_members(members)
        if identity is not None and identity.family == PLUGIN_HELPER_FAMILY_MOTEL:
            count += 1
    return count


def _automation_display_name(hass: HomeAssistant, entry: er.RegistryEntry) -> str:
    """Returns the installer-visible automation name used for suggestions."""
    state = hass.states.get(entry.entity_id)
    if state is not None and state.name:
        return str(state.name)
    return entry.name or entry.original_name or ""


def _is_enabled_automation(hass: HomeAssistant, entry: er.RegistryEntry) -> bool:
    """Returns False when the automation toggle is off."""
    state = hass.states.get(entry.entity_id)
    if state is None:
        return True
    return state.state != AUTOMATION_OFF_STATE
