"""Detects integration-hub device names that are not room hardware."""

from __future__ import annotations

WIFI_MODULE_NAME_MARKER = "wifi module"


def is_wifi_module_device_name(name: str | None) -> bool:
    """Returns True when a device name is the WiFi Module integration hub."""
    if not name:
        return False
    normalized = " ".join(name.lower().replace("-", " ").split())
    normalized = normalized.replace("wi fi", "wifi")
    return WIFI_MODULE_NAME_MARKER in normalized
