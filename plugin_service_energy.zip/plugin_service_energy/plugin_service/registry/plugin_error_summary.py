"""Short gateway-sensor text for plugin contract failures and off automations."""

from __future__ import annotations

from .plugin_issue import (
    REASON_INVALID_ENTITY_ID,
    REASON_MISSING_AREA,
    REASON_MISSING_CONTRACT_HELPERS,
    REASON_MOTEL_AMBIGUOUS_AREA,
    REASON_MULTIPLE_HELPER_INSTANCES,
    REASON_ROOM_MISMATCH,
    PluginValidationIssue,
)

_SHORT_REASON_ES = {
    REASON_INVALID_ENTITY_ID: "el entity_id no cumple el contrato",
    REASON_MISSING_AREA: "no tiene un área asignada",
    REASON_MISSING_CONTRACT_HELPERS: (
        "no referencia ayudantes {tipo}_{familia}_{sitio} del mismo sitio y área"
    ),
    REASON_MULTIPLE_HELPER_INSTANCES: (
        "referencia ayudantes de más de una habitación o instancia"
    ),
    REASON_ROOM_MISMATCH: "el sitio del entity_id no coincide con los ayudantes",
    REASON_MOTEL_AMBIGUOUS_AREA: "satélite motel en un área con varios grupos",
}

_SHORT_REASON_EN = {
    REASON_INVALID_ENTITY_ID: "the entity_id does not follow the contract",
    REASON_MISSING_AREA: "is not assigned to an area",
    REASON_MISSING_CONTRACT_HELPERS: (
        "does not reference {type}_{family}_{site} helpers in the same site and area"
    ),
    REASON_MULTIPLE_HELPER_INSTANCES: (
        "references helpers from more than one room or instance"
    ),
    REASON_ROOM_MISMATCH: "the entity_id site does not match the helpers",
    REASON_MOTEL_AMBIGUOUS_AREA: "motel satellite in an area with multiple plugin groups",
}


def format_plugin_status_summary(
    issues: list[PluginValidationIssue], is_spanish: bool
) -> str:
    """Builds a short sensor line plus a pointer to the notifications panel."""
    if not issues:
        raise ValueError("issues must not be empty")

    first = issues[0]
    subject = first.display_name or first.entity_id
    problem = f"{subject} {_short_reason_text(first, is_spanish)}"
    check_notes = (
        "Revisa las notificaciones para más detalle."
        if is_spanish
        else "Check notifications for more detail."
    )
    if len(issues) == 1:
        return f"Error: {problem}. {check_notes}"
    count_label = "elementos" if is_spanish else "items"
    return f"Error: {len(issues)} {count_label}. {problem}. {check_notes}"


def format_plugin_off_summary(entity_ids: list[str], is_spanish: bool) -> str:
    """Builds a short sensor line for off plugin automations after a successful register."""
    if not entity_ids:
        raise ValueError("entity_ids must not be empty")

    first = entity_ids[0]
    check_notes = (
        "Revisa las notificaciones para más detalle."
        if is_spanish
        else "Check notifications for more detail."
    )
    if len(entity_ids) == 1:
        if is_spanish:
            return f"Registro OK. {first} está en off y no se envió. {check_notes}"
        return f"Registration OK. {first} is off and was not sent. {check_notes}"
    count_label = "automatizaciones" if is_spanish else "automations"
    if is_spanish:
        return (
            f"Registro OK. {len(entity_ids)} {count_label} en off. {first}. {check_notes}"
        )
    return f"Registration OK. {len(entity_ids)} {count_label} are off. {first}. {check_notes}"


def _short_reason_text(issue: PluginValidationIssue, is_spanish: bool) -> str:
    """Returns a one-line cause without the full notification example."""
    catalog = _SHORT_REASON_ES if is_spanish else _SHORT_REASON_EN
    text = catalog.get(issue.reason, issue.reason)
    if issue.reason == REASON_ROOM_MISMATCH and issue.helper_room_key:
        return f"{text} ({issue.helper_room_key})"
    return text
