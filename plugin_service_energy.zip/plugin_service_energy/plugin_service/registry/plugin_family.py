"""Resolves plugin automation families, roles, and logical primary selection."""

from __future__ import annotations

from typing import Protocol

PLUGIN_ROLE_MAIN = "main"
PLUGIN_ROLE_EXT = "ext"
PLUGIN_ROLE_SEMAFORO = "semaforo"
PLUGIN_ROLES = frozenset(
    {PLUGIN_ROLE_MAIN, PLUGIN_ROLE_EXT, PLUGIN_ROLE_SEMAFORO}
)
PLUGIN_SATELLITE_ROLES = frozenset({PLUGIN_ROLE_EXT, PLUGIN_ROLE_SEMAFORO})

PLUGIN_FAMILY_OCCUPANCY = "occupancy"
PLUGIN_FAMILY_MOTEL = "motel"
PLUGIN_FAMILY_UNKNOWN = "unknown"

# Marker tokens inside the object_id → exported plugin_family value.
_PLUGIN_FAMILY_MARKERS: tuple[tuple[tuple[str, ...], str], ...] = (
    (("motel",), PLUGIN_FAMILY_MOTEL),
    (
        ("aula", "bp_plugin", "hotel", "occupancy", "ocupacion"),
        PLUGIN_FAMILY_OCCUPANCY,
    ),
)


class _HasEntityId(Protocol):
    """Minimal protocol for registry entries used in family selection."""

    entity_id: str


def get_plugin_object_id(entity_id: str) -> str:
    """Returns the object_id portion of a Home Assistant entity_id."""
    return entity_id.split(".", 1)[1]


def get_plugin_role(entity_id: str) -> str | None:
    """Returns main/ext/semaforo when that token appears in the object_id.

    Roles may sit at the end (``plugin_motel_main``) or before a site
    (``plugin_motel_main_motel_89``). Matching uses tokens, not suffixes.
    """
    for token in get_plugin_object_id(entity_id).lower().split("_"):
        if token in PLUGIN_ROLES:
            return token
    return None


def resolve_plugin_family(entity_id: str) -> str:
    """Maps an automation entity_id to a stable plugin_family label for the payload."""
    object_id = get_plugin_object_id(entity_id).lower()
    for markers, family in _PLUGIN_FAMILY_MARKERS:
        if any(marker in object_id for marker in markers):
            return family
    return PLUGIN_FAMILY_UNKNOWN


def resolve_plugin_family_from_entries(entries: list[_HasEntityId]) -> str:
    """Resolves occupancy vs motel from grouped automations and helpers.

    Helper groups without motel/aula/hotel tokens default to occupancy because
    the contract helpers already proved this is a plugin instance.
    """
    for entry in entries:
        family = resolve_plugin_family(entry.entity_id)
        if family != PLUGIN_FAMILY_UNKNOWN:
            return family

    joined_entity_ids = " ".join(entry.entity_id for entry in entries).lower()
    if "motel" in joined_entity_ids:
        return PLUGIN_FAMILY_MOTEL

    return PLUGIN_FAMILY_OCCUPANCY


def is_plugin_role_automation(entity_id: str) -> bool:
    """Returns True for motel-style role automations (main, ext, semaforo)."""
    return get_plugin_role(entity_id) is not None


def is_plugin_satellite_automation(entity_id: str) -> bool:
    """Returns True when the automation is a satellite role of a plugin family."""
    return get_plugin_role(entity_id) in PLUGIN_SATELLITE_ROLES


def is_plugin_primary_automation(entity_id: str) -> bool:
    """Returns True when the automation should own the logical plugin device id."""
    if get_plugin_role(entity_id) == PLUGIN_ROLE_MAIN:
        return True
    return not is_plugin_satellite_automation(entity_id)


def select_primary_plugin_automation(
    family_automations: list[_HasEntityId],
) -> _HasEntityId:
    """Picks the primary automation that owns the logical device for a family."""
    if not family_automations:
        raise ValueError("family_automations must not be empty")

    sorted_automations = sorted(family_automations, key=lambda entry: entry.entity_id)

    for entry in sorted_automations:
        if get_plugin_role(entry.entity_id) == PLUGIN_ROLE_MAIN:
            return entry

    for entry in sorted_automations:
        if is_plugin_primary_automation(entry.entity_id):
            return entry

    return sorted_automations[0]


