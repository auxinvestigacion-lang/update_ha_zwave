"""Collects plugin groups and virtual template helpers as logical devices."""

import logging

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from ..const import LOG_PREFIX

from .plugin_grouper import collect_grouped_plugin_devices
from .standalone_filter import is_standalone_entity
from .virtual_collector import collect_virtual_devices

_LOGGER = logging.getLogger(__name__)


def collect_standalone_devices(
    hass: HomeAssistant,
    entity_reg: er.EntityRegistry,
    area_name_map: dict[str, str],
) -> list[dict]:
    """Collects plugin groups and virtual template helpers as logical devices.

    Plugin automations are grouped from contract helpers (state/mode/action)
    in the same area. Scene automations (``escena_`` / ``scene_``) are omitted.
    Template helpers (virtual devices) are registered separately. Other
    standalone automations, scripts, HA scenes and orphan input helpers are
    intentionally excluded.
    """
    standalone_entries = [
        entry for entry in entity_reg.entities.values() if is_standalone_entity(entry)
    ]

    plugin_devices, grouped_entity_ids = collect_grouped_plugin_devices(
        hass,
        entity_reg,
        area_name_map,
        standalone_entries,
    )
    virtual_devices = collect_virtual_devices(hass, entity_reg, area_name_map)

    excluded_count = len(standalone_entries) - len(grouped_entity_ids)
    if excluded_count:
        _LOGGER.debug(
            "%s excluded %d standalone entities outside plugin groups",
            LOG_PREFIX,
            excluded_count,
        )

    _LOGGER.debug(
        "%s collected %d plugin and %d virtual logical device(s)",
        LOG_PREFIX,
        len(plugin_devices),
        len(virtual_devices),
    )
    return plugin_devices + virtual_devices
