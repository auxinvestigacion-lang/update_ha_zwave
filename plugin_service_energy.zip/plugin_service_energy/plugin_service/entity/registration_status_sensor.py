"""Diagnostic sensor for the latest inventory registration outcome."""

from homeassistant.components.sensor import SensorEntity
from homeassistant.const import EntityCategory

from ..const import DOMAIN
from ..core.installed_version import read_installed_version_tag
from ..core.registration_status import (
    STATUS_ERROR,
    STATUS_OK,
    STATUS_SYNCING,
    STATUS_UNKNOWN,
    RegistrationStatusStore,
)
from .gateway_device import build_gateway_device_info


class RegistrationStatusSensor(SensorEntity):
    """Shows OK/error on the gateway device so installers do not miss the result."""

    _attr_has_entity_name = True
    _attr_translation_key = "registration_status"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, store: RegistrationStatusStore, mac: str) -> None:
        self._store = store
        self._mac = mac
        self._unsub = None
        self._sw_version = read_installed_version_tag()
        self._attr_unique_id = f"{DOMAIN}_{mac}_registration_status"

    @property
    def device_info(self) -> dict:
        return build_gateway_device_info(self._mac, self._sw_version)

    @property
    def available(self) -> bool:
        return True

    @property
    def icon(self) -> str:
        if self._store.status == STATUS_ERROR:
            return "mdi:cloud-alert"
        if self._store.status == STATUS_OK:
            return "mdi:cloud-check"
        if self._store.status == STATUS_SYNCING:
            return "mdi:cloud-sync"
        return "mdi:cloud-question"

    @property
    def native_value(self) -> str:
        return self._store.state_text

    @property
    def extra_state_attributes(self) -> dict[str, str]:
        return {
            "status": self._store.status,
            "detail": self._store.detail,
        }

    async def async_added_to_hass(self) -> None:
        """Seeds the pending label and refreshes when registration finishes."""
        language = (self.hass.config.language or "en").lower()
        if self._store.status == STATUS_UNKNOWN and self._store.state_text == "—":
            self._store.set_unknown(language.startswith("es"))
        self._unsub = self._store.async_listen(self._handle_status_change)

    async def async_will_remove_from_hass(self) -> None:
        """Drops the store subscription when the entity is removed."""
        if self._unsub is not None:
            self._unsub()
            self._unsub = None

    def _handle_status_change(self) -> None:
        """Writes the new status to Home Assistant from the event loop."""
        self.async_write_ha_state()
