"""Clears entity-registry names that freeze a translation in one language."""

from __future__ import annotations

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

# Names written when the entity was first added; they block later language changes.
STOCK_ENTITY_NAMES = frozenset(
    {
        "Sincronizar dispositivos",
        "Synchronize devices",
        "Instalar versión de GitHub",
        "Instalar versión desde GitHub",
        "Install GitHub version",
        "Instalar nueva versión",
        "Install new version",
    }
)


def clear_stock_entity_name(hass: HomeAssistant, entity_id: str) -> None:
    """Removes a stock translated name so Home Assistant can apply the current language."""
    registry = er.async_get(hass)
    entry = registry.async_get(entity_id)
    if entry is None or entry.name is None:
        return
    if entry.name not in STOCK_ENTITY_NAMES:
        return
    registry.async_update_entity(entity_id, name=None)
