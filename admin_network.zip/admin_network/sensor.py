"""Sensor platform for Admin Network."""

from __future__ import annotations

from typing import Any

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import ATTR_LAST_CHECK, ATTR_MESSAGE, DOMAIN
from .coordinator import AdminNetworkCoordinator


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Admin Network sensors."""
    coordinator: AdminNetworkCoordinator = hass.data[DOMAIN][entry.entry_id]
    
    # Base online sensor
    entities: list[SensorEntity] = [NetworkOnlineSensor(coordinator, entry)]
    
    # We will discover devices from the coordinator data
    if coordinator.data and "devices" in coordinator.data:
        for device in coordinator.data["devices"]:
            dev_name = device["device"]
            dev_type = device["type"]
            entities.append(NetworkStateSensor(coordinator, entry, dev_name, dev_type))
            entities.append(NetworkIpSensor(coordinator, entry, dev_name, dev_type))
            entities.append(NetworkMacSensor(coordinator, entry, dev_name, dev_type))
            
            # If it's the active device with a gateway, add a gateway sensor
            if device.get("gateway"):
                entities.append(NetworkGatewaySensor(coordinator, entry, dev_name))
            
    async_add_entities(entities)


class NetworkModuleBaseSensor(CoordinatorEntity[AdminNetworkCoordinator], SensorEntity):
    """Base sensor for Network Module."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: AdminNetworkCoordinator, entry: ConfigEntry) -> None:
        """Initialize the base sensor."""
        super().__init__(coordinator)
        self._entry = entry
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="Admin Network",
            manufacturer="BND",
            model="Host NetworkManager",
        )

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return common attributes."""
        attrs: dict[str, Any] = {}
        if self.coordinator.last_message:
            attrs[ATTR_MESSAGE] = self.coordinator.last_message
        if self.coordinator.last_check is not None:
            attrs[ATTR_LAST_CHECK] = self.coordinator.last_check
        return attrs


class NetworkOnlineSensor(NetworkModuleBaseSensor):
    """Sensor for internet connectivity."""

    _attr_name = "Internet Online"
    _attr_icon = "mdi:web"

    def __init__(self, coordinator: AdminNetworkCoordinator, entry: ConfigEntry) -> None:
        """Initialize the online sensor."""
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.entry_id}_online"

    @property
    def native_value(self) -> str:
        """Return online status."""
        if not self.coordinator.data:
            return "unknown"
        return "online" if self.coordinator.data.get("online") else "offline"


class NetworkStateSensor(NetworkModuleBaseSensor):
    """Sensor for a network device state."""

    def __init__(
        self, 
        coordinator: AdminNetworkCoordinator, 
        entry: ConfigEntry, 
        device: str, 
        dev_type: str
    ) -> None:
        """Initialize the state sensor."""
        super().__init__(coordinator, entry)
        self._device = device
        self._dev_type = dev_type
        self._attr_name = f"{device} State"
        self._attr_unique_id = f"{entry.entry_id}_{device}_state"
        self._attr_icon = "mdi:wifi" if dev_type == "wifi" else "mdi:lan-connect"

    @property
    def native_value(self) -> str | None:
        """Return device state."""
        if not self.coordinator.data or "devices" not in self.coordinator.data:
            return None
        for dev in self.coordinator.data["devices"]:
            if dev["device"] == self._device:
                return dev["state"]
        return None


class NetworkIpSensor(NetworkModuleBaseSensor):
    """Sensor for a network device IP."""

    def __init__(
        self, 
        coordinator: AdminNetworkCoordinator, 
        entry: ConfigEntry, 
        device: str, 
        dev_type: str
    ) -> None:
        """Initialize the IP sensor."""
        super().__init__(coordinator, entry)
        self._device = device
        self._dev_type = dev_type
        self._attr_name = f"{device} IP"
        self._attr_unique_id = f"{entry.entry_id}_{device}_ip"
        self._attr_icon = "mdi:ip-network"

    @property
    def native_value(self) -> str | None:
        """Return device IP."""
        if not self.coordinator.data or "devices" not in self.coordinator.data:
            return None
        for dev in self.coordinator.data["devices"]:
            if dev["device"] == self._device:
                ips = dev.get("ip_addresses")
                return ips[0] if ips else "no ip"
        return None


class NetworkMacSensor(NetworkModuleBaseSensor):
    """Sensor for a network device MAC address."""

    def __init__(
        self, 
        coordinator: AdminNetworkCoordinator, 
        entry: ConfigEntry, 
        device: str, 
        dev_type: str
    ) -> None:
        """Initialize the MAC sensor."""
        super().__init__(coordinator, entry)
        self._device = device
        self._dev_type = dev_type
        self._attr_name = f"{device} MAC"
        self._attr_unique_id = f"{entry.entry_id}_{device}_mac"
        self._attr_icon = "mdi:ethernet"

    @property
    def native_value(self) -> str | None:
        """Return device MAC address."""
        if not self.coordinator.data or "devices" not in self.coordinator.data:
            return None
        for dev in self.coordinator.data["devices"]:
            if dev["device"] == self._device:
                return dev.get("mac")
        return None


class NetworkGatewaySensor(NetworkModuleBaseSensor):
    """Sensor for the network gateway."""

    def __init__(
        self, 
        coordinator: AdminNetworkCoordinator, 
        entry: ConfigEntry, 
        device: str
    ) -> None:
        """Initialize the Gateway sensor."""
        super().__init__(coordinator, entry)
        self._device = device
        self._attr_name = f"{device} Gateway"
        self._attr_unique_id = f"{entry.entry_id}_{device}_gateway"
        self._attr_icon = "mdi:router-wireless"

    @property
    def native_value(self) -> str | None:
        """Return the gateway."""
        if not self.coordinator.data or "devices" not in self.coordinator.data:
            return None
        for dev in self.coordinator.data["devices"]:
            if dev["device"] == self._device:
                return dev.get("gateway")
        return None
