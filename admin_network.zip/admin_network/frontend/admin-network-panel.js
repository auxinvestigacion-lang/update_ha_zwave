const DOMAIN = "admin_network";

class AdminNetworkPanel extends HTMLElement {
  constructor() {
    super();
    this._hass = null;
    this._tab = "networks";
    this._networks = [];
    this._saved = [];
    this._status = null;
    this._check = null;
    this._loading = false;
    this._error = null;
    this._info = null;
    this._selectedSsid = null;
    this._password = "";
    this.attachShadow({ mode: "open" });
  }

  set hass(hass) {
    const first = !this._hass;
    this._hass = hass;
    if (first) {
      this._render();
      this._refreshStatus();
    }
  }

  connectedCallback() {
    this._render();
  }

  async _call(service, data = {}) {
    if (!this._hass) {
      throw new Error("Home Assistant no está listo");
    }
    const result = await this._hass.connection.sendMessagePromise({
      type: "call_service",
      domain: DOMAIN,
      service,
      service_data: data,
      return_response: true,
    });
    return result.response || {};
  }

  async _withBusy(fn) {
    this._loading = true;
    this._error = null;
    this._info = null;
    this._render();
    try {
      await fn();
    } catch (err) {
      this._error = err?.message || String(err);
    } finally {
      this._loading = false;
      this._render();
    }
  }

  async _refreshStatus() {
    await this._withBusy(async () => {
      this._status = await this._call("status");
    });
  }

  async _scan() {
    await this._withBusy(async () => {
      const result = await this._call("scan");
      this._networks = result.networks || [];
      this._info = `${this._networks.length} redes encontradas`;
      this._status = await this._call("status");
    });
  }

  async _loadSaved() {
    await this._withBusy(async () => {
      const result = await this._call("list_all_connections");
      this._saved = result.connections || [];
      this._info = `${this._saved.length} conexiones guardadas`;
    });
  }

  async _connect() {
    if (!this._selectedSsid) {
      return;
    }
    const ssid = this._selectedSsid;
    const password = this._password;
    await this._withBusy(async () => {
      const result = await this._call("connect", {
        ssid,
        ...(password ? { password } : {}),
      });
      this._selectedSsid = null;
      this._password = "";
      this._status = result.status || (await this._call("status"));
      this._info = result.message || `Conectado a ${ssid}`;
      const scan = await this._call("scan");
      this._networks = scan.networks || [];
    });
  }

  async _forget(ssid) {
    if (!window.confirm(`¿Olvidar la conexión "${ssid}"?`)) {
      return;
    }
    await this._withBusy(async () => {
      const result = await this._call("forget", { ssid });
      this._info = result.message || `Conexión ${ssid} olvidada`;
      this._status = result.status || (await this._call("status"));
      const saved = await this._call("list_all_connections");
      this._saved = saved.connections || [];
    });
  }

  async _checkConnectivity() {
    await this._withBusy(async () => {
      this._check = await this._call("check");
      this._info = this._check.message || null;
    });
  }

  _setTab(tab) {
    this._tab = tab;
    this._selectedSsid = null;
    this._password = "";
    this._error = null;
    this._render();
    if (tab === "saved" && !this._saved.length) {
      this._loadSaved();
    }
  }

  _signalBars(signal) {
    const level = signal >= 75 ? 4 : signal >= 50 ? 3 : signal >= 25 ? 2 : 1;
    return "▂▄▆█".slice(0, level).padEnd(4, "·");
  }

  _render() {
    if (!this.shadowRoot) {
      return;
    }

    const interfaces = this._status?.devices || [];

    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          padding: 16px;
          color: var(--primary-text-color);
          background: var(--primary-background-color);
          font-family: var(--paper-font-body1_-_font-family, Roboto, Noto, sans-serif);
          box-sizing: border-box;
          min-height: 100%;
        }
        * { box-sizing: border-box; }
        .wrap {
          max-width: 560px;
          margin: 0 auto;
        }
        h1 {
          font-size: 1.5rem;
          margin: 0 0 12px;
          font-weight: 600;
        }
        .card {
          background: var(--card-background-color, var(--ha-card-background, #fff));
          border-radius: 16px;
          padding: 16px;
          margin-bottom: 14px;
          box-shadow: var(--ha-card-box-shadow, none);
          border: 1px solid var(--divider-color, transparent);
        }
        .status-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          align-items: flex-start;
          border-bottom: 1px solid var(--divider-color);
          padding-bottom: 12px;
          margin-bottom: 12px;
        }
        .status-row:last-child { border-bottom: 0; padding-bottom: 0; margin-bottom: 0; }
        .muted { opacity: 0.7; font-size: 0.85rem; }
        .tabs {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
          margin-bottom: 14px;
        }
        button, .btn {
          appearance: none;
          border: none;
          border-radius: 12px;
          padding: 12px 14px;
          font: inherit;
          cursor: pointer;
          background: var(--primary-color);
          color: var(--text-primary-color, #fff);
        }
        button:disabled { opacity: 0.55; cursor: default; }
        button.secondary, .tab {
          background: var(--secondary-background-color, #eee);
          color: var(--primary-text-color);
        }
        .tab.active {
          background: var(--primary-color);
          color: var(--text-primary-color, #fff);
        }
        .list { display: grid; gap: 8px; }
        .item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
          padding: 12px;
          border-radius: 12px;
          background: var(--secondary-background-color, #f5f5f5);
          cursor: pointer;
          text-align: left;
          width: 100%;
          color: inherit;
        }
        .item:hover { filter: brightness(0.98); }
        .item .meta { opacity: 0.7; font-size: 0.85rem; }
        .badge {
          display: inline-block;
          padding: 2px 8px;
          border-radius: 999px;
          font-size: 0.75rem;
          background: var(--primary-color);
          color: var(--text-primary-color, #fff);
        }
        .banner {
          padding: 12px 14px;
          border-radius: 12px;
          margin-bottom: 12px;
        }
        .banner.error {
          background: rgba(244, 67, 54, 0.15);
          color: var(--error-color, #f44336);
        }
        .banner.info {
          background: rgba(33, 150, 243, 0.12);
          color: var(--primary-text-color);
        }
        .banner.ok {
          background: rgba(76, 175, 80, 0.15);
          color: var(--success-color, #4caf50);
        }
        .banner.fail {
          background: rgba(244, 67, 54, 0.15);
          color: var(--error-color, #f44336);
        }
        .dialog {
          margin-top: 12px;
          display: grid;
          gap: 10px;
        }
        input[type="password"], input[type="text"] {
          width: 100%;
          padding: 12px;
          border-radius: 12px;
          border: 1px solid var(--divider-color, #ccc);
          background: var(--card-background-color, #fff);
          color: var(--primary-text-color);
          font: inherit;
        }
        .actions { display: flex; gap: 8px; flex-wrap: wrap; }
        .actions button { flex: 1; min-width: 120px; }
        .empty { opacity: 0.7; padding: 8px 0; }
        .check-detail { margin-top: 8px; font-size: 0.9rem; opacity: 0.85; white-space: pre-wrap; }
      </style>
      <div class="wrap">
        <h1>Admin Network</h1>

        <div class="card">
          ${interfaces.map(dev => `
            <div class="status-row">
              <div>
                <div><strong>${this._escape(dev.device)}</strong> <span class="badge" style="background:${dev.state === 'connected' ? 'var(--success-color)' : ''}">${this._escape(dev.state)}</span></div>
                <div class="muted">Tipo: ${this._escape(dev.type)}</div>
                <div class="muted">IP: ${this._escape(dev.ip_addresses?.join(', ') || '—')}</div>
                <div class="muted">MAC: <span style="font-family:monospace">${this._escape(dev.mac)}</span></div>
                ${dev.gateway ? `<div class="muted">Gateway: ${this._escape(dev.gateway)}</div>` : ''}
              </div>
            </div>
          `).join("")}
          <div class="actions" style="margin-top:12px">
            <button class="secondary" id="refreshStatus" ${this._loading ? "disabled" : ""} style="width:100%">Actualizar Estado</button>
          </div>
        </div>

        <div class="tabs">
          <button class="tab ${this._tab === "networks" ? "active" : ""}" data-tab="networks">WiFi</button>
          <button class="tab ${this._tab === "saved" ? "active" : ""}" data-tab="saved">Guardadas</button>
          <button class="tab ${this._tab === "check" ? "active" : ""}" data-tab="check">Test</button>
        </div>

        ${this._error ? `<div class="banner error">${this._escape(this._error)}</div>` : ""}
        ${this._info ? `<div class="banner info">${this._escape(this._info)}</div>` : ""}

        ${this._tab === "networks" ? this._renderNetworks() : ""}
        ${this._tab === "saved" ? this._renderSaved() : ""}
        ${this._tab === "check" ? this._renderCheck() : ""}
      </div>
    `;

    this.shadowRoot.getElementById("refreshStatus")?.addEventListener("click", () =>
      this._refreshStatus()
    );
    this.shadowRoot.querySelectorAll("[data-tab]").forEach((el) => {
      el.addEventListener("click", () => this._setTab(el.getAttribute("data-tab")));
    });
    this.shadowRoot.getElementById("scanBtn")?.addEventListener("click", () => this._scan());
    this.shadowRoot.getElementById("loadSavedBtn")?.addEventListener("click", () =>
      this._loadSaved()
    );
    this.shadowRoot.getElementById("checkBtn")?.addEventListener("click", () =>
      this._checkConnectivity()
    );
    this.shadowRoot.getElementById("connectBtn")?.addEventListener("click", () =>
      this._connect()
    );
    this.shadowRoot.getElementById("cancelConnect")?.addEventListener("click", () => {
      this._selectedSsid = null;
      this._password = "";
      this._render();
    });
    this.shadowRoot.getElementById("passwordInput")?.addEventListener("input", (e) => {
      this._password = e.target.value;
    });
    this.shadowRoot.querySelectorAll("[data-ssid]").forEach((el) => {
      el.addEventListener("click", () => {
        this._selectedSsid = el.getAttribute("data-ssid");
        this._password = "";
        this._render();
      });
    });
    this.shadowRoot.querySelectorAll("[data-forget]").forEach((el) => {
      el.addEventListener("click", () => this._forget(el.getAttribute("data-forget")));
    });
  }

  _renderNetworks() {
    const list =
      this._networks.length === 0
        ? `<div class="empty">Pulsa "Buscar redes" para escanear WiFi cercanas.</div>`
        : `<div class="list">${this._networks
            .map((net) => {
              const active = net.in_use
                ? `<span class="badge">Conectada</span>`
                : "";
              return `
                <button class="item" data-ssid="${this._escape(net.ssid)}">
                  <div>
                    <div><strong>${this._escape(net.ssid)}</strong> ${active}</div>
                    <div class="meta">${this._escape(net.security || "Abierta")} · señal ${net.signal ?? "?"}%</div>
                  </div>
                  <div class="meta">${this._signalBars(net.signal || 0)}</div>
                </button>`;
            })
            .join("")}</div>`;

    const dialog = this._selectedSsid
      ? `
        <div class="card dialog">
          <div><strong>Conectar a ${this._escape(this._selectedSsid)}</strong></div>
          <input id="passwordInput" type="password" placeholder="Contraseña (vacío si es abierta)" value="${this._escape(this._password)}" />
          <div class="actions">
            <button id="connectBtn" ${this._loading ? "disabled" : ""}>Conectar</button>
            <button class="secondary" id="cancelConnect">Cancelar</button>
          </div>
        </div>`
      : "";

    return `
      <div class="card">
        <div class="actions" style="margin-bottom:12px">
          <button id="scanBtn" ${this._loading ? "disabled" : ""}>Buscar WiFi</button>
        </div>
        ${list}
      </div>
      ${dialog}
    `;
  }

  _renderSaved() {
    const list =
      this._saved.length === 0
        ? `<div class="empty">No hay redes guardadas o aún no las has cargado.</div>`
        : `<div class="list">${this._saved
            .map((conn) => {
              const active = conn.active
                ? `<span class="badge">Activa</span>`
                : "";
              return `
                <div class="item" style="cursor:default">
                  <div>
                    <div><strong>${this._escape(conn.name)}</strong> ${active}</div>
                    <div class="meta">${this._escape(conn.type)}</div>
                  </div>
                  <button class="secondary" data-forget="${this._escape(conn.name)}" ${this._loading ? "disabled" : ""}>Olvidar</button>
                </div>`;
            })
            .join("")}</div>`;

    return `
      <div class="card">
        <div class="actions" style="margin-bottom:12px">
          <button id="loadSavedBtn" ${this._loading ? "disabled" : ""}>Listar guardadas</button>
        </div>
        ${list}
      </div>
    `;
  }

  _renderCheck() {
    let result = `<div class="empty">Pulsa "Verificar" para comprobar si hay Internet.</div>`;
    if (this._check) {
      const online = !!this._check.online;
      const cls = online ? "ok" : "fail";
      const dns = this._check.ping_dns?.success ? "OK" : "Fallo";
      const http = this._check.ping_http?.success ? "OK" : "Fallo";
      result = `
        <div class="banner ${cls}">
          <strong>${this._escape(this._check.message || (online ? "Conectividad OK" : "Sin conectividad"))}</strong>
          <div class="check-detail">Ping 8.8.8.8: ${dns}
Ping google.com: ${http}</div>
        </div>`;
    }

    return `
      <div class="card">
        <div class="actions" style="margin-bottom:12px">
          <button id="checkBtn" ${this._loading ? "disabled" : ""}>Verificar conectividad</button>
        </div>
        ${result}
      </div>
    `;
  }

  _escape(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }
}

customElements.define("admin-network-panel", AdminNetworkPanel);
