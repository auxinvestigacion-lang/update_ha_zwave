/**
 * Sidebar loader: embeds the Admin Network UI and passes the HA access token.
 */
class AdminNetworkPanel extends HTMLElement {
  set hass(hass) {
    if (!hass?.auth?.data?.access_token) {
      return;
    }
    const token = hass.auth.data.access_token;
    if (!this._initialized) {
      this._initialized = true;
      this.style.display = "block";
      this.style.width = "100%";
      this.style.height = "100%";
      this.style.overflow = "hidden";

      const iframe = document.createElement("iframe");
      iframe.title = "Redes";
      iframe.src = `/admin_network_panel/index.html?v=1.0.2#token=${encodeURIComponent(token)}`;
      iframe.style.border = "0";
      iframe.style.width = "100%";
      iframe.style.height = "100%";
      iframe.style.minHeight = "calc(100vh - 56px)";
      iframe.allow = "fullscreen";
      this._iframe = iframe;
      this.replaceChildren(iframe);
    } else if (this._token !== token && this._iframe?.contentWindow) {
      this._iframe.contentWindow.postMessage(
        { type: "ha-token", token },
        window.location.origin
      );
    }
    this._token = token;
  }

  set narrow(_value) {}
  set route(_value) {}
  set panel(_value) {}
}

customElements.define("admin-network-panel", AdminNetworkPanel);
