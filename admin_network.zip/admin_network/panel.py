"""Register the Admin Network sidebar panel inside Home Assistant."""

from __future__ import annotations

import logging
from pathlib import Path

from homeassistant.components import frontend, panel_custom
from homeassistant.components.http import StaticPathConfig
from homeassistant.core import HomeAssistant

from .const import DOMAIN, PANEL_ICON, PANEL_TITLE, PANEL_URL_PATH
from .views import AdminNetworkProxyView

_LOGGER = logging.getLogger(__name__)

_STATIC_URL = f"/{DOMAIN}_panel"
_PANEL_REGISTERED = False
_VIEWS_REGISTERED = False


async def async_setup_panel(hass: HomeAssistant) -> None:
    """Serve UI assets, API proxy and sidebar entry once."""
    global _PANEL_REGISTERED, _VIEWS_REGISTERED

    if not _VIEWS_REGISTERED:
        hass.http.register_view(AdminNetworkProxyView)
        _VIEWS_REGISTERED = True

    if _PANEL_REGISTERED:
        return

    frontend_dir = Path(__file__).parent / "frontend"
    await hass.http.async_register_static_paths(
        [StaticPathConfig(_STATIC_URL, str(frontend_dir), False)]
    )

    # Tiny loader panel: embeds the Admin Network UI with the user's HA token.
    await panel_custom.async_register_panel(
        hass=hass,
        frontend_url_path=PANEL_URL_PATH,
        webcomponent_name="admin-network-panel",
        sidebar_title=PANEL_TITLE,
        sidebar_icon=PANEL_ICON,
        module_url=f"{_STATIC_URL}/panel.js?v=1.0.2",
        embed_iframe=False,
        require_admin=False,
    )
    _PANEL_REGISTERED = True
    _LOGGER.info("Panel Admin Network registrado en el menú lateral (/%s)", PANEL_URL_PATH)


async def async_unload_panel(hass: HomeAssistant) -> None:
    """Remove the sidebar panel when the last entry is unloaded."""
    global _PANEL_REGISTERED
    if not _PANEL_REGISTERED:
        return
    try:
        frontend.async_remove_panel(hass, PANEL_URL_PATH)
    except Exception:  # noqa: BLE001
        _LOGGER.debug("Panel %s ya estaba eliminado", PANEL_URL_PATH)
    _PANEL_REGISTERED = False
