"""Wrappers around NetworkManager CLI (nmcli) and connectivity checks."""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

_LOGGER = logging.getLogger(__name__)

# Cooldown between NetworkManager restarts (AIC8800 recovery).
_RECOVER_COOLDOWN_SEC = 900
_RECOVER_STAMP = Path("/run/admin_network_wifi_recover")


class NmcliError(RuntimeError):
    """Raised when an nmcli or network command fails."""


def _run(command: list[str], timeout: int = 60) -> str:
    """Run a shell command and return stdout, or raise NmcliError."""
    try:
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise NmcliError(f"Command not found: {command[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise NmcliError(f"Command timed out: {' '.join(command)}") from exc

    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "").strip()
        raise NmcliError(detail or f"Command failed: {' '.join(command)}")

    return completed.stdout


def _run_ok(command: list[str], timeout: int = 60) -> tuple[bool, str]:
    """Run a command; return (ok, stdout_or_stderr) without raising."""
    try:
        return True, _run(command, timeout=timeout)
    except NmcliError as exc:
        return False, str(exc)


def ensure_nmcli() -> None:
    """Ensure nmcli is available on the host."""
    if shutil.which("nmcli") is None:
        raise NmcliError("nmcli is not installed or not in PATH")


def device_status() -> list[dict[str, str]]:
    """List NetworkManager devices (nmcli device status)."""
    ensure_nmcli()
    output = _run(
        [
            "nmcli",
            "-t",
            "-f",
            "DEVICE,TYPE,STATE,CONNECTION",
            "device",
            "status",
        ]
    )
    devices: list[dict[str, str]] = []
    for line in output.splitlines():
        if not line.strip():
            continue
        parts = line.split(":")
        if len(parts) < 4:
            continue
        devices.append(
            {
                "device": parts[0],
                "type": parts[1],
                "state": parts[2],
                "connection": parts[3],
            }
        )
    return devices


def wifi_devices() -> list[dict[str, str]]:
    """Return WiFi NetworkManager devices."""
    return [d for d in device_status() if d["type"] == "wifi"]


def unavailable_wifi_devices() -> list[dict[str, str]]:
    """WiFi devices in unavailable / unmanaged / disconnected-broken states."""
    bad = {"unavailable", "unmanaged"}
    return [d for d in wifi_devices() if d["state"] in bad]


def _cooldown_remaining() -> int:
    """Seconds left before another NM restart is allowed."""
    try:
        mtime = _RECOVER_STAMP.stat().st_mtime
    except FileNotFoundError:
        return 0
    elapsed = time.time() - mtime
    left = int(_RECOVER_COOLDOWN_SEC - elapsed)
    return max(0, left)


def _mark_recover() -> None:
    try:
        _RECOVER_STAMP.parent.mkdir(parents=True, exist_ok=True)
        _RECOVER_STAMP.write_text(str(int(time.time())), encoding="utf-8")
    except OSError as exc:
        _LOGGER.warning("Could not write recover stamp: %s", exc)


def diagnose_wifi() -> dict[str, Any]:
    """Collect WiFi health for API / Horus diagnostics."""
    ensure_nmcli()
    radio_ok, radio_out = _run_ok(["nmcli", "radio", "wifi"])
    rfkill_ok, rfkill_out = _run_ok(["rfkill", "list"])
    devices = wifi_devices()
    unavailable = unavailable_wifi_devices()
    return {
        "radio": (radio_out or "").strip() if radio_ok else "unknown",
        "radio_enabled": radio_ok and "enabled" in (radio_out or "").lower(),
        "rfkill": (rfkill_out or "").strip() if rfkill_ok else "",
        "devices": devices,
        "unavailable": [d["device"] for d in unavailable],
        "healthy": bool(devices) and not unavailable,
        "recover_cooldown_sec": _cooldown_remaining(),
    }


def recover_wifi(force: bool = False) -> dict[str, Any]:
    """Try to bring WiFi back when wlan* is unavailable (AIC8800 / NM)."""
    ensure_nmcli()
    steps: list[str] = []
    before = diagnose_wifi()

    if before["healthy"] and not force:
        return {
            "recovered": True,
            "changed": False,
            "message": "WiFi ya está operativo",
            "steps": steps,
            "before": before,
            "after": before,
        }

    _run_ok(["nmcli", "radio", "wifi", "on"])
    steps.append("nmcli radio wifi on")

    for dev in wifi_devices() or [{"device": "wlan0"}]:
        name = dev["device"]
        _run_ok(["nmcli", "device", "set", name, "managed", "yes"])
        steps.append(f"nmcli device set {name} managed yes")
        ok, detail = _run_ok(["ip", "link", "set", name, "up"])
        steps.append(f"ip link set {name} up: {'ok' if ok else detail}")

    after_soft = diagnose_wifi()
    if after_soft["healthy"]:
        return {
            "recovered": True,
            "changed": True,
            "message": "WiFi recuperado sin reiniciar NetworkManager",
            "steps": steps,
            "before": before,
            "after": after_soft,
        }

    left = _cooldown_remaining()
    if left > 0 and not force:
        steps.append(f"NetworkManager restart skipped (cooldown {left}s)")
        return {
            "recovered": False,
            "changed": True,
            "message": (
                f"WiFi sigue unavailable; cooldown NM {left}s. "
                "Use force=true o espere."
            ),
            "steps": steps,
            "before": before,
            "after": after_soft,
        }

    ok, detail = _run_ok(["systemctl", "restart", "NetworkManager"], timeout=120)
    _mark_recover()
    steps.append(f"systemctl restart NetworkManager: {'ok' if ok else detail}")
    time.sleep(3)
    after = diagnose_wifi()
    return {
        "recovered": after["healthy"],
        "changed": True,
        "message": (
            "WiFi recuperado tras reiniciar NetworkManager"
            if after["healthy"]
            else "WiFi sigue unavailable tras recovery"
        ),
        "steps": steps,
        "before": before,
        "after": after,
    }


def ensure_wifi_ready() -> dict[str, Any] | None:
    """If WiFi is unavailable, attempt recovery. Returns recovery info or None."""
    try:
        if not unavailable_wifi_devices():
            # Also recover when there is a wifi iface DOWN with I/O issues:
            # nmcli may still list it as unavailable; otherwise nothing to do.
            return None
    except NmcliError:
        return None
    _LOGGER.warning("WiFi unavailable — attempting automatic recovery")
    return recover_wifi(force=False)


def wifi_list() -> list[dict[str, Any]]:
    """Scan and list WiFi networks (nmcli dev wifi list)."""
    ensure_nmcli()
    recovery = ensure_wifi_ready()
    if recovery and not recovery.get("recovered"):
        _LOGGER.warning("WiFi recovery incomplete: %s", recovery.get("message"))

    rescan_error = ""
    try:
        _run(["nmcli", "device", "wifi", "rescan"], timeout=30)
    except NmcliError as exc:
        rescan_error = str(exc)
        _LOGGER.warning("wifi rescan failed: %s", rescan_error)
        # One more recovery pass if scan blocked by unavailable.
        if "unavailable" in rescan_error.lower():
            recover_wifi(force=False)
            try:
                _run(["nmcli", "device", "wifi", "rescan"], timeout=30)
                rescan_error = ""
            except NmcliError as exc2:
                rescan_error = str(exc2)

    output = _run(
        [
            "nmcli",
            "-t",
            "-f",
            "IN-USE,SSID,SIGNAL,SECURITY,BSSID,CHAN",
            "device",
            "wifi",
            "list",
        ]
    )
    networks: list[dict[str, Any]] = []
    seen: set[str] = set()
    for line in output.splitlines():
        if not line.strip():
            continue
        fields = re.split(r"(?<!\\):", line)
        fields = [f.replace("\\:", ":") for f in fields]
        if len(fields) < 5:
            continue
        in_use = fields[0] == "*"
        ssid = fields[1]
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        try:
            signal = int(fields[2])
        except ValueError:
            signal = 0
        networks.append(
            {
                "in_use": in_use,
                "ssid": ssid,
                "signal": signal,
                "security": fields[3],
                "bssid": fields[4] if len(fields) > 4 else "",
                "channel": fields[5] if len(fields) > 5 else "",
            }
        )
    networks.sort(key=lambda item: item["signal"], reverse=True)
    if not networks and rescan_error:
        raise NmcliError(
            f"WiFi scan vacío y rescan falló: {rescan_error}. "
            "Revise wlan0 (unavailable) o reinicie NetworkManager."
        )
    return networks


def wifi_connect(ssid: str, password: str | None = None) -> str:
    """Connect to a WiFi network (nmcli dev wifi connect)."""
    ensure_nmcli()
    if not ssid.strip():
        raise NmcliError("SSID is required")

    command = ["nmcli", "device", "wifi", "connect", ssid]
    if password:
        command.extend(["password", password])
    return _run(command, timeout=90).strip() or f"Connected to {ssid}"


def connection_delete(ssid: str | None = None) -> str:
    """Forget a WiFi connection by SSID or the active WiFi connection."""
    ensure_nmcli()
    target = (ssid or "").strip()

    if not target:
        for device in device_status():
            if device["type"] == "wifi" and device["connection"]:
                target = device["connection"]
                break
        if not target:
            raise NmcliError("No active WiFi connection to forget")

    connections = _run(
        ["nmcli", "-t", "-f", "NAME,UUID,TYPE,FILENAME", "connection", "show"]
    )
    to_delete: list[str] = []
    for line in connections.splitlines():
        if not line.strip():
            continue
        parts = line.split(":")
        if len(parts) < 3:
            continue
        name, uuid, conn_type = parts[0], parts[1], parts[2]
        if conn_type != "802-11-wireless":
            continue
        if name == target or name == ssid:
            to_delete.append(uuid)

    if not to_delete:
        try:
            _run(["nmcli", "connection", "delete", "id", target])
            return f"Deleted connection '{target}'"
        except NmcliError as exc:
            raise NmcliError(f"WiFi connection not found: {target}") from exc

    for uuid in to_delete:
        _run(["nmcli", "connection", "delete", "uuid", uuid])

    return f"Deleted {len(to_delete)} connection(s) for '{target}'"


def ip_addresses() -> list[dict[str, str]]:
    """Return IPv4 addresses from `ip -brief addr`."""
    output = _run(["ip", "-brief", "addr"])
    addresses: list[dict[str, str]] = []
    for line in output.splitlines():
        parts = line.split()
        if len(parts) < 3:
            continue
        iface, state = parts[0], parts[1]
        for token in parts[2:]:
            if "/" in token and "." in token:
                addresses.append(
                    {
                        "interface": iface,
                        "state": state,
                        "address": token.split("/")[0],
                        "cidr": token,
                    }
                )
    return addresses


def ping_check(host: str, count: int = 4) -> dict[str, Any]:
    """Ping a host and return a structured result."""
    try:
        output = _run(["ping", "-c", str(count), host], timeout=count * 3 + 5)
        success = True
        detail = output.strip()
    except NmcliError as exc:
        success = False
        detail = str(exc)

    return {"host": host, "success": success, "detail": detail}


def saved_wifi_connections() -> list[dict[str, Any]]:
    """List saved WiFi connections in NetworkManager."""
    ensure_nmcli()
    output = _run(
        [
            "nmcli",
            "-t",
            "-f",
            "NAME,UUID,TYPE,DEVICE,ACTIVE",
            "connection",
            "show",
        ]
    )
    connections: list[dict[str, Any]] = []
    for line in output.splitlines():
        if not line.strip():
            continue
        parts = line.split(":")
        if len(parts) < 5:
            continue
        name, uuid, conn_type, device, active = (
            parts[0],
            parts[1],
            parts[2],
            parts[3],
            parts[4],
        )
        if conn_type != "802-11-wireless":
            continue
        connections.append(
            {
                "name": name,
                "ssid": name,
                "uuid": uuid,
                "device": device or None,
                "active": active == "yes",
            }
        )
    connections.sort(key=lambda item: (not item["active"], item["name"].lower()))
    return connections


def connectivity_check() -> dict[str, Any]:
    """Verify local IPs and basic internet connectivity."""
    ping_dns = ping_check("8.8.8.8")
    ping_http = ping_check("google.com")
    online = bool(ping_dns.get("success") or ping_http.get("success"))
    return {
        "online": online,
        "message": "Hay acceso a Internet" if online else "No hay acceso a Internet",
        "addresses": ip_addresses(),
        "ping_dns": ping_dns,
        "ping_http": ping_http,
    }


def connection_modify_ip(
    conn_name: str,
    method: str,
    address: str | None = None,
    gateway: str | None = None,
    dns: str | None = None,
) -> str:
    """Modify IP configuration for a connection (DHCP or Static)."""
    ensure_nmcli()
    if method not in {"auto", "manual"}:
        raise NmcliError("Method must be 'auto' (DHCP) or 'manual' (Static)")

    command = ["nmcli", "connection", "modify", conn_name, "ipv4.method", method]

    if method == "manual":
        if not address:
            raise NmcliError("IP address is required for manual configuration")
        command.extend(["ipv4.addresses", address])
        if gateway:
            command.extend(["ipv4.gateway", gateway])
        if dns:
            command.extend(["ipv4.dns", dns])
    else:
        command.extend(["ipv4.addresses", "", "ipv4.gateway", "", "ipv4.dns", ""])

    _run(command)
    _run(["nmcli", "connection", "up", conn_name])
    return f"Configuration updated and applied to {conn_name}"


def get_all_connections() -> list[dict[str, Any]]:
    """List all NetworkManager connections (Ethernet and WiFi)."""
    ensure_nmcli()
    output = _run(
        [
            "nmcli",
            "-t",
            "-f",
            "NAME,UUID,TYPE,DEVICE,ACTIVE",
            "connection",
            "show",
        ]
    )
    connections: list[dict[str, Any]] = []
    for line in output.splitlines():
        if not line.strip():
            continue
        parts = line.split(":")
        if len(parts) < 5:
            continue
        name, uuid, conn_type, device, active = parts[:5]
        connections.append(
            {
                "name": name,
                "uuid": uuid,
                "type": conn_type,
                "device": device or None,
                "active": active == "yes",
            }
        )
    return connections


def get_gateway() -> str:
    """Get the default IPv4 gateway."""
    try:
        output = _run(["ip", "route", "show", "default"])
        match = re.search(r"default via (\d+\.\d+\.\d+\.\d+)", output)
        return match.group(1) if match else "Desconocida"
    except:
        return "Desconocida"


def get_mac(interface: str) -> str:
    """Get the MAC address for a given interface."""
    try:
        # On Linux, MAC is in /sys/class/net/<iface>/address
        import os
        path = f"/sys/class/net/{interface}/address"
        if os.path.exists(path):
            with open(path, "r") as f:
                return f.read().strip().upper()
    except:
        pass
    return "00:00:00:00:00:00"


def current_network_summary() -> dict[str, Any]:
    """Summarize all network devices and their active connections."""
    devices = device_status()
    ips = ip_addresses()
    gateway = get_gateway()
    
    summary = []
    for dev in devices:
        dev_name = dev["device"]
        dev_ips = [item["address"] for item in ips if item["interface"] == dev_name]
        summary.append({
            "device": dev_name,
            "type": dev["type"],
            "state": dev["state"],
            "connection": dev["connection"],
            "ip_addresses": dev_ips,
            "mac": get_mac(dev_name),
            "gateway": gateway if dev["state"] == "connected" else None
        })
    
    return {
        "devices": summary,
        "online": connectivity_check()["online"]
    }


def current_wifi_summary() -> dict[str, Any]:
    """Summarize current WiFi device and connection state."""
    wifi_devices = [d for d in device_status() if d["type"] == "wifi"]
    active = next(
        (d for d in wifi_devices if d["state"] in {"connected", "connecting"}),
        wifi_devices[0] if wifi_devices else None,
    )
    ipv4 = []
    if active:
        ipv4 = [
            item["address"]
            for item in ip_addresses()
            if item["interface"] == active["device"]
        ]

    return {
        "device": active["device"] if active else None,
        "state": active["state"] if active else "unavailable",
        "connection": active["connection"] if active else None,
        "ssid": active["connection"] if active else None,
        "ip_addresses": ipv4,
        "devices": wifi_devices,
    }
