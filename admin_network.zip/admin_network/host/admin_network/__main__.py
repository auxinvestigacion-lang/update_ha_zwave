"""Entry point for `python -m admin_network`."""

from __future__ import annotations

import uvicorn

from .api import create_app
from .config import load_settings


def main() -> None:
    """Start the WiFi host service."""
    settings = load_settings()
    app = create_app(settings)
    uvicorn.run(app, host=settings.host, port=settings.port, log_level="info")


if __name__ == "__main__":
    main()
