"""Host-side WiFi configuration service for Home Assistant."""

__version__ = "0.5.0"
