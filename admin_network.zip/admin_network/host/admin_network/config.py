"""Runtime configuration for the Admin Network host service."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    """Service settings loaded from environment variables."""

    host: str
    port: int
    api_key: str


def load_settings() -> Settings:
    """Load settings from environment variables."""
    api_key = os.environ.get("ADMIN_NETWORK_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "ADMIN_NETWORK_API_KEY is required. Set it in /etc/admin_network.env"
        )

    return Settings(
        host=os.environ.get("ADMIN_NETWORK_HOST", "0.0.0.0"),
        port=int(os.environ.get("ADMIN_NETWORK_PORT", "8765")),
        api_key=api_key,
    )
