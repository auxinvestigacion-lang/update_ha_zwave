"""HTTP API and web UI for WiFi management on the controller."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import __version__, nmcli
from .config import Settings

STATIC_DIR = Path(__file__).parent / "static"


class ConnectRequest(BaseModel):
    """Payload to connect to a WiFi network."""

    ssid: str = Field(..., min_length=1)
    password: Optional[str] = None


class ForgetRequest(BaseModel):
    """Payload to forget a WiFi network. Empty SSID forgets the active one."""

    ssid: Optional[str] = None


class IpConfigRequest(BaseModel):
    """Payload to modify IP configuration."""

    connection: str = Field(..., min_length=1)
    method: str = Field(..., pattern="^(auto|manual)$")
    address: Optional[str] = None
    gateway: Optional[str] = None
    dns: Optional[str] = None


def create_app(settings: Settings) -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="WiFi Module Host Service",
        version=__version__,
        docs_url=None,
        redoc_url=None,
    )

    def require_api_key(
        x_api_key: Optional[str] = Header(default=None),
    ) -> None:
        """Validate the API key header."""
        if not x_api_key or x_api_key != settings.api_key:
            raise HTTPException(status_code=401, detail="Invalid API key")

    @app.get("/")
    def root() -> RedirectResponse:
        """Redirect to the WiFi web UI."""
        return RedirectResponse(url="/ui/")

    @app.get("/ui")
    def ui_redirect() -> RedirectResponse:
        """Normalize /ui to /ui/."""
        return RedirectResponse(url="/ui/")

    @app.get("/ui/")
    def ui_index() -> FileResponse:
        """Serve the phone-like WiFi configuration page."""
        return FileResponse(STATIC_DIR / "index.html")

    app.mount("/ui/static", StaticFiles(directory=str(STATIC_DIR)), name="ui-static")

    @app.get("/health")
    def health() -> Dict[str, str]:
        """Liveness probe without authentication."""
        return {"status": "ok", "version": __version__}

    @app.get("/status", dependencies=[Depends(require_api_key)])
    def status() -> Dict[str, Any]:
        """Return current WiFi status."""
        try:
            return nmcli.current_wifi_summary()
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.get("/scan", dependencies=[Depends(require_api_key)])
    def scan() -> Dict[str, Any]:
        """Scan available WiFi networks (auto-recovery if wlan unavailable)."""
        try:
            networks = nmcli.wifi_list()
            return {"networks": networks, "count": len(networks)}
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.get("/wifi/diagnose", dependencies=[Depends(require_api_key)])
    def wifi_diagnose() -> Dict[str, Any]:
        """Diagnose WiFi radio / NetworkManager state."""
        try:
            return nmcli.diagnose_wifi()
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.post("/wifi/repair", dependencies=[Depends(require_api_key)])
    def wifi_repair(force: bool = Query(False)) -> Dict[str, Any]:
        """Recover WiFi when wlan* is unavailable (may restart NetworkManager)."""
        try:
            return nmcli.recover_wifi(force=force)
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.post("/connect", dependencies=[Depends(require_api_key)])
    def connect(body: ConnectRequest) -> Dict[str, Any]:
        """Connect to a WiFi network."""
        try:
            message = nmcli.wifi_connect(body.ssid, body.password)
            summary = nmcli.current_wifi_summary()
            return {"message": message, "status": summary}
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/forget", dependencies=[Depends(require_api_key)])
    def forget(body: ForgetRequest) -> Dict[str, Any]:
        """Forget a saved WiFi connection."""
        try:
            message = nmcli.connection_delete(body.ssid)
            summary = nmcli.current_wifi_summary()
            return {"message": message, "status": summary}
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/connections", dependencies=[Depends(require_api_key)])
    def connections() -> Dict[str, Any]:
        """List saved WiFi connections."""
        try:
            items = nmcli.saved_wifi_connections()
            return {"connections": items, "count": len(items)}
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.get("/check", dependencies=[Depends(require_api_key)])
    def check() -> Dict[str, Any]:
        """Verify IP addressing and connectivity."""
        try:
            return nmcli.connectivity_check()
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.get("/network/status", dependencies=[Depends(require_api_key)])
    def network_status() -> Dict[str, Any]:
        """Return full network status (Ethernet + WiFi)."""
        try:
            return nmcli.current_network_summary()
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.get("/network/connections", dependencies=[Depends(require_api_key)])
    def all_connections() -> Dict[str, Any]:
        """List all saved connections."""
        try:
            items = nmcli.get_all_connections()
            return {"connections": items, "count": len(items)}
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.post("/network/modify", dependencies=[Depends(require_api_key)])
    def modify_ip(body: IpConfigRequest) -> Dict[str, Any]:
        """Modify IP configuration for a connection."""
        try:
            message = nmcli.connection_modify_ip(
                body.connection,
                body.method,
                body.address,
                body.gateway,
                body.dns
            )
            return {"message": message, "status": nmcli.current_network_summary()}
        except nmcli.NmcliError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    return app
