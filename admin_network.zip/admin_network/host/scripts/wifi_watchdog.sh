#!/usr/bin/env bash
# Recover WiFi when NetworkManager reports wlan* as unavailable (AIC8800).
# Installed as admin_network-wifi-watchdog.timer (every 5 minutes).

set -euo pipefail

COOLDOWN_SEC="${ADMIN_NETWORK_WIFI_COOLDOWN:-900}"
STAMP_FILE="${ADMIN_NETWORK_WIFI_STAMP:-/run/admin_network_wifi_recover}"
LOG_TAG="admin_network-wifi-watchdog"

log() {
  logger -t "${LOG_TAG}" -- "$@"
  echo "$(date -Is) $*"
}

if ! command -v nmcli >/dev/null 2>&1; then
  log "nmcli missing; skip"
  exit 0
fi

# Ensure radio on (cheap, idempotent).
nmcli radio wifi on >/dev/null 2>&1 || true

mapfile -t WIFI_LINES < <(nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null | grep ':wifi:' || true)
if [[ ${#WIFI_LINES[@]} -eq 0 ]]; then
  log "no wifi device; skip"
  exit 0
fi

NEED_RECOVERY=0
for line in "${WIFI_LINES[@]}"; do
  IFS=':' read -r dev _type state <<<"${line}"
  if [[ "${state}" == "unavailable" || "${state}" == "unmanaged" ]]; then
    NEED_RECOVERY=1
    log "wifi ${dev} state=${state}"
    nmcli device set "${dev}" managed yes >/dev/null 2>&1 || true
    ip link set "${dev}" up >/dev/null 2>&1 || true
  fi
done

if [[ "${NEED_RECOVERY}" -eq 0 ]]; then
  exit 0
fi

# Re-check after soft recovery.
STILL_BAD=0
while IFS= read -r line; do
  IFS=':' read -r _dev _type state <<<"${line}"
  if [[ "${state}" == "unavailable" || "${state}" == "unmanaged" ]]; then
    STILL_BAD=1
  fi
done < <(nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null | grep ':wifi:' || true)

if [[ "${STILL_BAD}" -eq 0 ]]; then
  log "wifi recovered with soft steps"
  exit 0
fi

NOW="$(date +%s)"
if [[ -f "${STAMP_FILE}" ]]; then
  LAST="$(cat "${STAMP_FILE}" 2>/dev/null || echo 0)"
  AGE=$((NOW - LAST))
  if [[ "${AGE}" -lt "${COOLDOWN_SEC}" ]]; then
    log "NetworkManager restart skipped (cooldown ${AGE}/${COOLDOWN_SEC}s)"
    exit 0
  fi
fi

log "restarting NetworkManager"
systemctl restart NetworkManager
mkdir -p "$(dirname "${STAMP_FILE}")"
echo "${NOW}" >"${STAMP_FILE}"
sleep 3

AFTER="$(nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null | grep ':wifi:' || true)"
log "after restart: ${AFTER}"
exit 0
