#!/usr/bin/env bash
# Install the Admin Network host service on Debian (BND controller).

set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/admin_network}"
ENV_FILE="${ENV_FILE:-/etc/admin_network.env}"
SERVICE_NAME="admin_network"
WATCHDOG_SERVICE="admin_network-wifi-watchdog.service"
WATCHDOG_TIMER="admin_network-wifi-watchdog.timer"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Ejecuta este script como root (sudo)."
  exit 1
fi

if ! command -v nmcli >/dev/null 2>&1; then
  echo "nmcli no está instalado. Instala NetworkManager primero."
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 no está instalado."
  exit 1
fi

ensure_python_venv() {
  if python3 -m venv --help >/dev/null 2>&1; then
    local tmp_venv
    tmp_venv="$(mktemp -d)"
    if python3 -m venv "${tmp_venv}/t" >/dev/null 2>&1; then
      rm -rf "${tmp_venv}"
      return 0
    fi
    rm -rf "${tmp_venv}"
  fi

  echo "Instalando dependencias de Python (python3-venv, python3-pip)..."
  # Mirrors (p. ej. USTC) a veces publican InRelease caducado; no bloquear el install.
  apt-get -o Acquire::Check-Valid-Until=false -o Acquire::Check-Date=false update
  apt-get install -y python3-venv python3-pip
}

install_networkmanager_tweaks() {
  local src="${SCRIPT_DIR}/networkmanager"
  if [[ ! -d "${src}" ]]; then
    echo "Sin carpeta networkmanager/; se omiten tweaks WiFi."
    return 0
  fi
  echo "Aplicando tweaks NetworkManager (powersave / MAC)..."
  mkdir -p /etc/NetworkManager/conf.d
  for conf in \
    10-override-wifi-random-mac-disable.conf \
    20-override-wifi-powersave-disable.conf
  do
    if [[ -f "${src}/${conf}" ]]; then
      install -m 644 "${src}/${conf}" "/etc/NetworkManager/conf.d/${conf}"
      echo "  conf.d/${conf}"
    fi
  done
  if [[ -f "${src}/10-wifi-disable-powermanagement.rules" ]]; then
    mkdir -p /etc/udev/rules.d
    install -m 644 "${src}/10-wifi-disable-powermanagement.rules" \
      /etc/udev/rules.d/10-wifi-disable-powermanagement.rules
    echo "  udev powersave rule"
  fi
  if [[ -f "${src}/99-wifi-powersave-off" ]]; then
    mkdir -p /etc/NetworkManager/dispatcher.d
    install -m 755 "${src}/99-wifi-powersave-off" \
      /etc/NetworkManager/dispatcher.d/99-wifi-powersave-off
    echo "  dispatcher powersave-off"
  fi
}

install_wifi_watchdog() {
  echo "Instalando WiFi watchdog (timer 5 min)..."
  mkdir -p "${INSTALL_DIR}/scripts"
  if [[ -f "${SCRIPT_DIR}/scripts/wifi_watchdog.sh" ]]; then
    install -m 755 "${SCRIPT_DIR}/scripts/wifi_watchdog.sh" \
      "${INSTALL_DIR}/scripts/wifi_watchdog.sh"
  else
    echo "WARN: falta scripts/wifi_watchdog.sh"
    return 0
  fi
  install -m 644 "${SCRIPT_DIR}/systemd/${WATCHDOG_SERVICE}" \
    "/etc/systemd/system/${WATCHDOG_SERVICE}"
  install -m 644 "${SCRIPT_DIR}/systemd/${WATCHDOG_TIMER}" \
    "/etc/systemd/system/${WATCHDOG_TIMER}"
  systemctl daemon-reload
  systemctl enable --now "${WATCHDOG_TIMER}"
  echo "  timer ${WATCHDOG_TIMER} activo"
}

ensure_python_venv

echo "Instalando Admin Network en ${INSTALL_DIR}..."
mkdir -p "${INSTALL_DIR}"
rm -rf "${INSTALL_DIR}/venv"

if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete \
    --exclude 'venv' \
    --exclude '__pycache__' \
    --exclude '*.pyc' \
    "${SCRIPT_DIR}/" "${INSTALL_DIR}/"
else
  find "${INSTALL_DIR}" -mindepth 1 -maxdepth 1 ! -name 'venv' -exec rm -rf {} +
  cp -a "${SCRIPT_DIR}/." "${INSTALL_DIR}/"
  rm -rf "${INSTALL_DIR}/venv"
fi

python3 -m venv "${INSTALL_DIR}/venv"
"${INSTALL_DIR}/venv/bin/pip" install --upgrade pip
"${INSTALL_DIR}/venv/bin/pip" install -r "${INSTALL_DIR}/requirements.txt"

if [[ ! -f "${ENV_FILE}" ]]; then
  API_KEY="$(openssl rand -hex 16 2>/dev/null || python3 -c 'import secrets; print(secrets.token_hex(16))')"
  cat > "${ENV_FILE}" <<EOF
ADMIN_NETWORK_HOST=0.0.0.0
ADMIN_NETWORK_PORT=8765
ADMIN_NETWORK_API_KEY=${API_KEY}
EOF
  chmod 600 "${ENV_FILE}"
  echo "Creado ${ENV_FILE} con una API key nueva."
else
  # shellcheck disable=SC1090
  source "${ENV_FILE}"
  API_KEY="${ADMIN_NETWORK_API_KEY:-}"
  echo "Reutilizando ${ENV_FILE} existente."
fi

install -m 644 "${SCRIPT_DIR}/systemd/admin_network.service" \
  "/etc/systemd/system/${SERVICE_NAME}.service"

install_networkmanager_tweaks
install_wifi_watchdog

systemctl daemon-reload
systemctl enable "${SERVICE_NAME}.service"
systemctl restart "${SERVICE_NAME}.service"
# Apply NM conf.d tweaks without dropping eth if possible.
systemctl reload NetworkManager 2>/dev/null || systemctl restart NetworkManager || true
sleep 1

if ! systemctl is-active --quiet "${SERVICE_NAME}.service"; then
  echo
  echo "ERROR: el servicio no quedó activo. Últimos logs:"
  journalctl -u "${SERVICE_NAME}.service" -n 40 --no-pager || true
  exit 1
fi

# Quick import smoke test.
if ! (
  cd "${INSTALL_DIR}"
  "${INSTALL_DIR}/venv/bin/python" -c "from admin_network.api import create_app; print('ok')"
); then
  echo "ERROR: el módulo no importa correctamente."
  exit 1
fi

open_firewall_port() {
  local port="${1:-8765}"
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi "Status: active"; then
    ufw allow "${port}/tcp" comment "admin_network" || true
    echo "Firewall: ufw allow ${port}/tcp"
    return
  fi
  if command -v iptables >/dev/null 2>&1; then
    if ! iptables -C INPUT -p tcp --dport "${port}" -j ACCEPT 2>/dev/null; then
      iptables -I INPUT -p tcp --dport "${port}" -j ACCEPT
      echo "Firewall: iptables allow ${port}/tcp"
    else
      echo "Firewall: iptables ya permite ${port}/tcp"
    fi
  fi
}

# Ensure the service listens on all interfaces.
if grep -q '^ADMIN_NETWORK_HOST=' "${ENV_FILE}"; then
  sed -i 's/^ADMIN_NETWORK_HOST=.*/ADMIN_NETWORK_HOST=0.0.0.0/' "${ENV_FILE}"
else
  echo "ADMIN_NETWORK_HOST=0.0.0.0" >> "${ENV_FILE}"
fi
# shellcheck disable=SC1090
source "${ENV_FILE}"
API_KEY="${ADMIN_NETWORK_API_KEY:-}"
systemctl restart "${SERVICE_NAME}.service"
sleep 1
open_firewall_port "${ADMIN_NETWORK_PORT:-8765}"

HOST_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
HOST_IP="${HOST_IP:-192.168.1.40}"

echo
echo "Servicio Admin Network instalado y en ejecución."
echo "  En el BND:     curl http://127.0.0.1:8765/health"
echo "  Desde tu PC:   http://${HOST_IP}:8765/"
echo "  Status:        curl -H \"X-API-Key: ${API_KEY}\" http://127.0.0.1:8765/network/status"
echo "  WiFi diagnose: curl -H \"X-API-Key: ${API_KEY}\" http://127.0.0.1:8765/wifi/diagnose"
echo "  Watchdog:      systemctl status ${WATCHDOG_TIMER}"
echo
echo "API key:"
echo "  ${API_KEY}"
echo
echo "Si falla el servicio: journalctl -u ${SERVICE_NAME} -n 50 --no-pager"
