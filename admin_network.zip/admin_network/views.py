"""Authenticated HTTP proxy from Home Assistant to the host Admin Network service."""

from __future__ import annotations

import logging

from aiohttp import web
from homeassistant.components.http import HomeAssistantView
from homeassistant.core import HomeAssistant

from .api import AdminNetworkApiError
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

_GET_ACTIONS = {
    "status",
    "scan",
    "connections",
    "check",
    "network/status",
    "network/connections",
    "wifi/diagnose",
}
_POST_ACTIONS = {"connect", "forget", "network/modify", "wifi/repair"}


def _get_api(hass: HomeAssistant):
    """Return the API client from the first configured entry."""
    entries = hass.data.get(DOMAIN, {})
    if not entries:
        return None
    coordinator = next(iter(entries.values()))
    return coordinator.api


class AdminNetworkProxyView(HomeAssistantView):
    """Proxy Admin Network actions through Home Assistant auth."""

    url = f"/api/{DOMAIN}/{{action:.*}}"
    name = f"api:{DOMAIN}:action"
    requires_auth = True

    async def get(self, request: web.Request, action: str) -> web.Response:
        """Proxy GET actions."""
        if action not in _GET_ACTIONS:
            return self.json_message("Not found", status_code=404)
        return await self._proxy(request, action, method="GET")

    async def post(self, request: web.Request, action: str) -> web.Response:
        """Proxy POST actions."""
        if action not in _POST_ACTIONS:
            return self.json_message("Not found", status_code=404)
        return await self._proxy(request, action, method="POST")

    async def _proxy(
        self, request: web.Request, action: str, method: str
    ) -> web.Response:
        """Forward the request to the host service."""
        hass: HomeAssistant = request.app["hass"]
        api = _get_api(hass)
        if api is None:
            return self.json_message("Admin Network is not configured", status_code=503)

        body = None
        if method == "POST":
            try:
                body = await request.json()
            except Exception:  # noqa: BLE001
                body = {}

        try:
            if action == "status":
                payload = await api.async_status()
            elif action == "scan":
                payload = await api.async_scan()
            elif action == "connections":
                payload = await api.async_connections()
            elif action == "check":
                payload = await api.async_check()
            elif action == "network/status":
                payload = await api.async_network_status()
            elif action == "network/connections":
                payload = await api.async_all_connections()
            elif action == "wifi/diagnose":
                payload = await api.async_wifi_diagnose()
            elif action == "connect":
                payload = await api.async_connect(
                    (body or {}).get("ssid", ""),
                    (body or {}).get("password"),
                )
            elif action == "forget":
                payload = await api.async_forget((body or {}).get("ssid"))
            elif action == "wifi/repair":
                payload = await api.async_wifi_repair(
                    force=bool((body or {}).get("force", False))
                )
            elif action == "network/modify":
                payload = await api.async_modify_ip(
                    connection=(body or {}).get("connection"),
                    method=(body or {}).get("method"),
                    address=(body or {}).get("address"),
                    gateway=(body or {}).get("gateway"),
                    dns=(body or {}).get("dns"),
                )
            else:
                return self.json_message("Not found", status_code=404)
        except AdminNetworkApiError as exc:
            _LOGGER.warning("Admin Network proxy error on %s: %s", action, exc)
            return self.json_message(str(exc), status_code=400)

        return self.json(payload)
