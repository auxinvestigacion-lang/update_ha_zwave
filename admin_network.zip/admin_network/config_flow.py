"""Config flow for Admin Network."""

from __future__ import annotations

from typing import Any

import aiohttp
import voluptuous as vol
from homeassistant import config_entries
from homeassistant.const import CONF_HOST, CONF_PORT
from homeassistant.core import HomeAssistant
from homeassistant.data_entry_flow import FlowResult
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import AdminNetworkApi, AdminNetworkApiError
from .const import CONF_API_KEY, DEFAULT_PORT, DOMAIN


async def _validate_input(hass: HomeAssistant, data: dict[str, Any]) -> dict[str, str]:
    """Validate host connectivity and API key."""
    session = async_get_clientsession(hass)
    api = AdminNetworkApi(
        session=session,
        host=data[CONF_HOST],
        port=int(data[CONF_PORT]),
        api_key=data[CONF_API_KEY],
    )
    try:
        await api.async_health()
        await api.async_network_status()
    except AdminNetworkApiError as exc:
        raise CannotConnect from exc
    return {"title": f"Admin Network ({data[CONF_HOST]})"}


class CannotConnect(Exception):
    """Error to indicate we cannot connect to the host service."""


class AdminNetworkConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for Admin Network."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle the initial step."""
        errors: dict[str, str] = {}

        if user_input is not None:
            self._async_abort_entries_match(
                {CONF_HOST: user_input[CONF_HOST], CONF_PORT: user_input[CONF_PORT]}
            )
            try:
                info = await _validate_input(self.hass, user_input)
            except CannotConnect:
                errors["base"] = "cannot_connect"
            except aiohttp.ClientError:
                errors["base"] = "cannot_connect"
            except Exception:  # noqa: BLE001
                errors["base"] = "unknown"
            else:
                return self.async_create_entry(title=info["title"], data=user_input)

        data_schema = vol.Schema(
            {
                vol.Required(CONF_HOST, default="127.0.0.1"): str,
                vol.Required(CONF_PORT, default=DEFAULT_PORT): int,
                vol.Required(CONF_API_KEY): str,
            }
        )
        return self.async_show_form(
            step_id="user", data_schema=data_schema, errors=errors
        )
