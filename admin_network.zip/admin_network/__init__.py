"""Admin Network Home Assistant integration."""

from __future__ import annotations

import voluptuous as vol
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_PORT, Platform
from homeassistant.core import (
    HomeAssistant,
    ServiceCall,
    ServiceResponse,
    SupportsResponse,
)
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import AdminNetworkApi, AdminNetworkApiError
from .const import (
    CONF_API_KEY,
    DOMAIN,
    SERVICE_CHECK,
    SERVICE_CONNECT,
    SERVICE_FORGET,
    SERVICE_LIST_SAVED,
    SERVICE_SCAN,
    SERVICE_STATUS,
    SERVICE_MODIFY_IP,
    SERVICE_LIST_ALL_CONNECTIONS,
)
from .coordinator import AdminNetworkCoordinator
from .panel import async_setup_panel, async_unload_panel

PLATFORMS: list[Platform] = [Platform.SENSOR, Platform.BUTTON]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up Admin Network from a config entry."""
    session = async_get_clientsession(hass)
    api = AdminNetworkApi(
        session=session,
        host=entry.data[CONF_HOST],
        port=int(entry.data[CONF_PORT]),
        api_key=entry.data[CONF_API_KEY],
    )
    coordinator = AdminNetworkCoordinator(hass, api)
    await coordinator.async_config_entry_first_refresh()

    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = coordinator

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    _async_register_services(hass)
    await async_setup_panel(hass)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id, None)
        if not hass.data[DOMAIN]:
            for service in (
                SERVICE_SCAN,
                SERVICE_CONNECT,
                SERVICE_FORGET,
                SERVICE_CHECK,
                SERVICE_LIST_SAVED,
                SERVICE_STATUS,
                SERVICE_MODIFY_IP,
                SERVICE_LIST_ALL_CONNECTIONS,
            ):
                hass.services.async_remove(DOMAIN, service)
            await async_unload_panel(hass)
            hass.data.pop(DOMAIN, None)
    return unload_ok


def _get_coordinator(hass: HomeAssistant) -> AdminNetworkCoordinator:
    """Return the first configured coordinator."""
    entries = hass.data.get(DOMAIN, {})
    if not entries:
        raise HomeAssistantError("Admin Network is not configured")
    return next(iter(entries.values()))


def _async_register_services(hass: HomeAssistant) -> None:
    """Register integration services once."""
    if hass.services.has_service(DOMAIN, SERVICE_SCAN):
        return

    async def async_status(_call: ServiceCall) -> ServiceResponse:
        """Return current network status."""
        coordinator = _get_coordinator(hass)
        try:
            result = await coordinator.api.async_network_status()
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        await coordinator.async_request_refresh()
        return result

    async def async_scan(_call: ServiceCall) -> ServiceResponse:
        """Scan WiFi networks and return the list."""
        coordinator = _get_coordinator(hass)
        try:
            result = await coordinator.api.async_scan()
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        coordinator.networks = result.get("networks", [])
        coordinator.last_message = f"Found {result.get('count', 0)} networks"
        await coordinator.async_request_refresh()
        return result

    async def async_list_saved(_call: ServiceCall) -> ServiceResponse:
        """List saved WiFi connections."""
        coordinator = _get_coordinator(hass)
        try:
            return await coordinator.api.async_connections()
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc

    async def async_connect(call: ServiceCall) -> ServiceResponse:
        """Connect to a WiFi network."""
        coordinator = _get_coordinator(hass)
        ssid = call.data["ssid"]
        password = call.data.get("password")
        try:
            result = await coordinator.api.async_connect(ssid, password)
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        coordinator.last_message = result.get("message")
        await coordinator.async_request_refresh()
        return result

    async def async_forget(call: ServiceCall) -> ServiceResponse:
        """Forget a WiFi network."""
        coordinator = _get_coordinator(hass)
        ssid = call.data.get("ssid")
        try:
            result = await coordinator.api.async_forget(ssid)
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        coordinator.last_message = result.get("message")
        await coordinator.async_request_refresh()
        return result

    async def async_check(_call: ServiceCall) -> ServiceResponse:
        """Run connectivity verification and return a clear result."""
        coordinator = _get_coordinator(hass)
        try:
            result = await coordinator.api.async_check()
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        coordinator.last_check = result
        coordinator.last_message = result.get("message")
        await coordinator.async_request_refresh()
        return result

    async def async_modify_ip(call: ServiceCall) -> ServiceResponse:
        """Modify IP configuration for a connection."""
        coordinator = _get_coordinator(hass)
        try:
            result = await coordinator.api.async_modify_ip(
                connection=call.data["connection"],
                method=call.data["method"],
                address=call.data.get("address"),
                gateway=call.data.get("gateway"),
                dns=call.data.get("dns"),
            )
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        coordinator.last_message = result.get("message")
        await coordinator.async_request_refresh()
        return result

    async def async_list_all_connections(_call: ServiceCall) -> ServiceResponse:
        """List all NetworkManager connections."""
        coordinator = _get_coordinator(hass)
        try:
            return await coordinator.api.async_all_connections()
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc

    hass.services.async_register(
        DOMAIN,
        SERVICE_STATUS,
        async_status,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_SCAN,
        async_scan,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_LIST_SAVED,
        async_list_saved,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_LIST_ALL_CONNECTIONS,
        async_list_all_connections,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_CONNECT,
        async_connect,
        schema=vol.Schema(
            {
                vol.Required("ssid"): cv.string,
                vol.Optional("password"): cv.string,
            }
        ),
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_FORGET,
        async_forget,
        schema=vol.Schema({vol.Optional("ssid"): cv.string}),
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_CHECK,
        async_check,
        supports_response=SupportsResponse.ONLY,
    )
    hass.services.async_register(
        DOMAIN,
        SERVICE_MODIFY_IP,
        async_modify_ip,
        schema=vol.Schema(
            {
                vol.Required("connection"): cv.string,
                vol.Required("method"): vol.In(["auto", "manual"]),
                vol.Optional("address"): cv.string,
                vol.Optional("gateway"): cv.string,
                vol.Optional("dns"): cv.string,
            }
        ),
        supports_response=SupportsResponse.ONLY,
    )
