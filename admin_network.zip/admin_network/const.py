"""Constants for the Admin Network integration."""

from __future__ import annotations

DOMAIN = "admin_network"
DEFAULT_PORT = 8765
DEFAULT_NAME = "Admin Network"
CONF_API_KEY = "api_key"
CONF_HOST = "host"
CONF_PORT = "port"

ATTR_NETWORKS = "networks"
ATTR_CONNECTIONS = "connections"
ATTR_LAST_CHECK = "last_check"
ATTR_MESSAGE = "message"

SERVICE_SCAN = "scan"
SERVICE_CONNECT = "connect"
SERVICE_FORGET = "forget"
SERVICE_CHECK = "check"
SERVICE_LIST_SAVED = "list_saved"
SERVICE_STATUS = "status"
SERVICE_MODIFY_IP = "modify_ip"
SERVICE_LIST_ALL_CONNECTIONS = "list_all_connections"

PANEL_URL_PATH = "admin-network"
PANEL_TITLE = "Redes"
PANEL_ICON = "mdi:lan"
