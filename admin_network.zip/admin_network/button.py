"""Button platform for Admin Network."""

from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .api import AdminNetworkApiError
from .const import DOMAIN
from .coordinator import AdminNetworkCoordinator


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Admin Network buttons."""
    coordinator: AdminNetworkCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [
            WifiScanButton(coordinator, entry),
            WifiForgetButton(coordinator, entry),
            WifiCheckButton(coordinator, entry),
        ]
    )


class AdminNetworkButton(CoordinatorEntity[AdminNetworkCoordinator], ButtonEntity):
    """Base button for Admin Network."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: AdminNetworkCoordinator, entry: ConfigEntry) -> None:
        """Initialize the button."""
        super().__init__(coordinator)
        self._entry = entry
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="Admin Network",
            manufacturer="BND",
            model="Host NetworkManager",
        )


class WifiScanButton(AdminNetworkButton):
    """Button to scan WiFi networks."""

    _attr_name = "Scan WiFi"
    _attr_icon = "mdi:wifi-sync"

    def __init__(self, coordinator: AdminNetworkCoordinator, entry: ConfigEntry) -> None:
        """Initialize scan button."""
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.entry_id}_scan"

    async def async_press(self) -> None:
        """Trigger a WiFi scan."""
        try:
            result = await self.coordinator.api.async_scan()
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        self.coordinator.networks = result.get("networks", [])
        self.coordinator.last_message = f"Found {result.get('count', 0)} networks"
        await self.coordinator.async_request_refresh()


class WifiForgetButton(AdminNetworkButton):
    """Button to forget the active network."""

    _attr_name = "Forget connection"
    _attr_icon = "mdi:wifi-cancel"

    def __init__(self, coordinator: AdminNetworkCoordinator, entry: ConfigEntry) -> None:
        """Initialize forget button."""
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.entry_id}_forget"

    async def async_press(self) -> None:
        """Forget the currently active connection."""
        try:
            result = await self.coordinator.api.async_forget(None)
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        self.coordinator.last_message = result.get("message")
        await self.coordinator.async_request_refresh()


class WifiCheckButton(AdminNetworkButton):
    """Button to verify connectivity."""

    _attr_name = "Check connectivity"
    _attr_icon = "mdi:lan-check"

    def __init__(self, coordinator: AdminNetworkCoordinator, entry: ConfigEntry) -> None:
        """Initialize check button."""
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.entry_id}_check"

    async def async_press(self) -> None:
        """Run connectivity checks."""
        try:
            result = await self.coordinator.api.async_check()
        except AdminNetworkApiError as exc:
            raise HomeAssistantError(str(exc)) from exc
        self.coordinator.last_check = result
        dns_ok = result.get("ping_dns", {}).get("success")
        http_ok = result.get("ping_http", {}).get("success")
        self.coordinator.last_message = f"Ping DNS={dns_ok}, HTTP={http_ok}"
        await self.coordinator.async_request_refresh()
