"""Async HTTP client for the Admin Network host service."""

from __future__ import annotations

from typing import Any, Dict, Optional

import aiohttp


class AdminNetworkApiError(Exception):
    """Raised when the host API returns an error."""


class AdminNetworkApi:
    """Client for the host-side Admin Network API."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        host: str,
        port: int,
        api_key: str,
    ) -> None:
        """Initialize the API client."""
        self._session = session
        self._base = f"http://{host}:{port}"
        self._headers = {"X-API-Key": api_key}

    async def _request(
        self, method: str, path: str, json: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Perform an authenticated request against the host service."""
        url = f"{self._base}{path}"
        try:
            async with self._session.request(
                method,
                url,
                headers=self._headers,
                json=json,
                timeout=aiohttp.ClientTimeout(total=90),
            ) as response:
                payload = await response.json(content_type=None)
                if response.status >= 400:
                    detail = (
                        payload.get("detail") if isinstance(payload, dict) else payload
                    )
                    raise AdminNetworkApiError(str(detail) or f"HTTP {response.status}")
                return payload
        except aiohttp.ClientError as exc:
            raise AdminNetworkApiError(
                f"Cannot reach Admin Network service: {exc}"
            ) from exc

    async def async_health(self) -> dict[str, Any]:
        """Call /health (no auth required, but useful for connectivity)."""
        url = f"{self._base}/health"
        try:
            async with self._session.get(
                url, timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                if response.status >= 400:
                    raise AdminNetworkApiError(f"HTTP {response.status}")
                return await response.json(content_type=None)
        except aiohttp.ClientError as exc:
            raise AdminNetworkApiError(
                f"Cannot reach Admin Network service: {exc}"
            ) from exc

    async def async_status(self) -> dict[str, Any]:
        """Fetch current WiFi status."""
        return await self._request("GET", "/status")

    async def async_scan(self) -> dict[str, Any]:
        """Scan WiFi networks."""
        return await self._request("GET", "/scan")

    async def async_wifi_diagnose(self) -> dict[str, Any]:
        """Diagnose WiFi / NetworkManager health."""
        return await self._request("GET", "/wifi/diagnose")

    async def async_wifi_repair(self, force: bool = False) -> dict[str, Any]:
        """Recover unavailable WiFi (may restart NetworkManager)."""
        path = "/wifi/repair?force=true" if force else "/wifi/repair"
        return await self._request("POST", path)

    async def async_connections(self) -> dict[str, Any]:
        """List saved WiFi connections."""
        return await self._request("GET", "/connections")

    async def async_connect(
        self, ssid: str, password: Optional[str] = None
    ) -> dict[str, Any]:
        """Connect to a WiFi network."""
        body: Dict[str, Any] = {"ssid": ssid}
        if password is not None:
            body["password"] = password
        return await self._request("POST", "/connect", json=body)

    async def async_forget(self, ssid: Optional[str] = None) -> dict[str, Any]:
        """Forget a WiFi network."""
        return await self._request("POST", "/forget", json={"ssid": ssid})

    async def async_check(self) -> dict[str, Any]:
        """Run connectivity checks."""
        return await self._request("GET", "/check")

    async def async_network_status(self) -> dict[str, Any]:
        """Fetch full network status (Ethernet + WiFi)."""
        return await self._request("GET", "/network/status")

    async def async_all_connections(self) -> dict[str, Any]:
        """List all saved connections (Ethernet and WiFi)."""
        return await self._request("GET", "/network/connections")

    async def async_modify_ip(
        self,
        connection: str,
        method: str,
        address: Optional[str] = None,
        gateway: Optional[str] = None,
        dns: Optional[str] = None,
    ) -> dict[str, Any]:
        """Modify IP configuration for a connection."""
        body = {
            "connection": connection,
            "method": method,
            "address": address,
            "gateway": gateway,
            "dns": dns,
        }
        return await self._request("POST", "/network/modify", json=body)
