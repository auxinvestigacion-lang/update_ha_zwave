"""Data update coordinator for Admin Network."""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import AdminNetworkApi, AdminNetworkApiError
from .const import DOMAIN


class AdminNetworkCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Coordinate polling of network status from the host service."""

    def __init__(self, hass: HomeAssistant, api: AdminNetworkApi) -> None:
        """Initialize the coordinator."""
        super().__init__(
            hass,
            logger=__import__("logging").getLogger(__name__),
            name=DOMAIN,
            update_interval=timedelta(seconds=30),
        )
        self.api = api
        self.networks: list[dict[str, Any]] = []
        self.last_check: dict[str, Any] | None = None
        self.last_message: str | None = None

    async def _async_update_data(self) -> dict[str, Any]:
        """Fetch the latest network status."""
        try:
            return await self.api.async_network_status()
        except AdminNetworkApiError as exc:
            raise UpdateFailed(str(exc)) from exc
