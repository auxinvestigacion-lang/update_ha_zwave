# Admin Network — Gestión de Redes Horus

Exportado del controlador Nexxo/BND (`bnd`, 10.0.0.149) el 2026-08-25.

No incluye `venv`, API keys ni `.storage` de Home Assistant.

## Contenido

| Carpeta | Qué es | Usar para |
|---|---|---|
| `host/` | Servicio host v0.4.0 (FastAPI + UI `/ui/`) | **Base para mejorar** |
| `custom_components/admin_network/` | Integración HA v1.0.0 + panel | Copiar a HA |
| `optional/` | Ejemplo de `.env` y tweaks NetworkManager | Opcional |

## Arquitectura

```
Panel HA / servicios  →  /api/admin_network/{action}  →  host :8765  →  nmcli
```

HA está en Docker con `network_mode: host`. El servicio **debe** correr en el host (systemd), no dentro del contenedor: `nmcli` habla con NetworkManager del BND.

## Características v1.0.0 (Admin Network)

- **Gestión Total:** WiFi y Ethernet en una sola herramienta.
- **Configuración IP:** Soporte para IP Estática y DHCP.
- **Información Detallada:** Muestra IP, Puerta de Enlace (Gateway) y MAC address por interfaz.
- **Sensores HA:** Sensores automáticos para cada puerto físico detectado.
- **Servicios:** Automatiza cambios de red mediante servicios de HA.

## Requisitos en el controlador de pruebas

- Debian/BND con NetworkManager (`nmcli`)
- `python3`, `python3-venv`, root
- Home Assistant en Docker con `network_mode: host`

## 1. Instalar el servicio host

Usa `host/`:

```bash
cd host
sudo ./install.sh
```

Crea `/opt/admin_network`, `/etc/admin_network.env` (API key nueva) y `admin_network.service`.

API (header `X-API-Key` salvo `/health`):

- `GET /health`
- `GET /network/status` `/network/connections` `/scan`
- `POST /network/modify` `{"connection":"...","method":"manual|auto",...}`
- `POST /connect` `{"ssid":"...","password":"..."}`
- `POST /forget` `{"ssid":"..."}`
- UI host: `http://IP:8765/ui/`

## 2. Instalar la integración HA

```bash
cp -a custom_components/admin_network /home/cat/config/custom_components/
```

Reinicia HA. Añade **Admin Network**:

- Host: `127.0.0.1`
- Puerto: `8765`
- API key: la de `/etc/admin_network.env`

Panel lateral **Redes**.
